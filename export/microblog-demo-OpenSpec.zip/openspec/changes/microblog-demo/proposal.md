# Proposal: Microblog Platform

> A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications.

> Original ask: "A Twitter-like social platform where people share short posts (up to 280 characters), reply in threads, like and repost, attach images or short videos, follow other users, and get a real-time personal feed of updates from people they follow. Includes public search and trending topics, private direct messages, multiple separate communities, and basic moderation tools. For creative ppl"

## Why

A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications. This change captures the user-facing behaviour, the supporting architecture, and the rollout plan in an OpenSpec-shaped change folder so an OpenSpec-capable agent can run `/opsx:apply` against it.

## What Changes

- Introduce the **Microblog Platform** feature surface driven by 4 user stories.
- Add an architecture capability describing the supporting layers, non-functional requirements, and operational constraints.
- Ship tasks grouped by user-story priority so the apply phase can verify them in order.

## Capabilities

### New Capabilities

- `microblog-demo`: User-facing behaviour for Microblog Platform.
- `microblog-demo-architecture`: Cross-cutting architecture, layers, and operational constraints.

### Modified Capabilities

_None — this change introduces new capabilities only._

## Impact

- **User stories affected:** 4
- **Functional requirements:** 4
- **Architecture layers:** 5
- **Affected user stories**:
- **US001** — Read a home timeline (P1)
- **US002** — Compose and publish a post (P1)
- **US003** — Send a direct message (P2)
- **US004** — Search public posts (P3)
- **Functional requirements**:
- **FR-001** — The home timeline must render posts in reverse chronological order with cursor pagination.
- **FR-002** — Post publishing must be idempotent on the Idempotency-Key header.
- **FR-003** — Direct messages must be encrypted at rest with envelope encryption.
- **FR-004** — Media uploads must support JPEG, PNG, and MP4 up to 50 MB.
- **Architecture layers**:
- `backend` — Backend (Python)
- `backend-workers` — Backend Workers
- `frontend` — Frontend (Angular)
- `shared` — Shared Contracts
- `infra` — Infrastructure

Generated: 2026-09-15T00:00:00.000Z