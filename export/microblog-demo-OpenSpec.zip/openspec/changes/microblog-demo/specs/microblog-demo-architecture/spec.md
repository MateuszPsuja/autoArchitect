# Capability: Microblog Platform — Architecture

## Purpose

Capture the cross-cutting architecture, layers, and operational constraints that back **Microblog Platform**.

## ADDED Requirements

## Functional requirements

The system shall satisfy every functional requirement captured during planning: 4 item(s) total.

### Requirement: FR-001 Functional requirement FR-001 is satisfied

#### Scenario: FR-001 is verified

- **WHEN** the user exercises the path described by FR-001
- **THEN** the system fulfils: The home timeline must render posts in reverse chronological order with cursor pagination.
- **AND** no contract test against this requirement regresses

### Requirement: FR-002 Functional requirement FR-002 is satisfied

#### Scenario: FR-002 is verified

- **WHEN** the user exercises the path described by FR-002
- **THEN** the system fulfils: Post publishing must be idempotent on the Idempotency-Key header.
- **AND** no contract test against this requirement regresses

### Requirement: FR-003 Functional requirement FR-003 is satisfied

#### Scenario: FR-003 is verified

- **WHEN** the user exercises the path described by FR-003
- **THEN** the system fulfils: Direct messages must be encrypted at rest with envelope encryption.
- **AND** no contract test against this requirement regresses

### Requirement: FR-004 Functional requirement FR-004 is satisfied

#### Scenario: FR-004 is verified

- **WHEN** the user exercises the path described by FR-004
- **THEN** the system fulfils: Media uploads must support JPEG, PNG, and MP4 up to 50 MB.
- **AND** no contract test against this requirement regresses

## Success criteria

Each success criterion defines a measurable outcome: 4 item(s) total.

### Requirement: SC-001 Success criterion SC-001 is measured

#### Scenario: SC-001 is verified

- **WHEN** the operator runs the measurement scenario for SC-001
- **THEN** the system reports: p95 home feed render under 1.5s on a warm cache.

### Requirement: SC-002 Success criterion SC-002 is measured

#### Scenario: SC-002 is verified

- **WHEN** the operator runs the measurement scenario for SC-002
- **THEN** the system reports: Fan-out latency p95 under 1s from publish to follower timeline.

### Requirement: SC-003 Success criterion SC-003 is measured

#### Scenario: SC-003 is verified

- **WHEN** the operator runs the measurement scenario for SC-003
- **THEN** the system reports: 99.9% availability for the read APIs.

### Requirement: SC-004 Success criterion SC-004 is measured

#### Scenario: SC-004 is verified

- **WHEN** the operator runs the measurement scenario for SC-004
- **THEN** the system reports: Zero PII in logs; structured logging with correlation IDs.

## Architecture layers

Each architecture layer ships its own implementation contract: 5 layer(s) total.

### Requirement: layer-backend Layer backend implements its contract

#### Scenario: layer-backend is verified

- **WHEN** the Backend (Python) layer is exercised
- **THEN** it conforms to: FastAPI service exposing REST and WebSocket APIs for the public reader, the personal feed, and the staff moderation console, backed by PostgreSQL, Redis, S3-compatible object storage, and OpenSearch.
- **AND** tech stack honours: Python 3.11, FastAPI 0.111, SQLAlchemy 2 (async), Alembic, Pydantic v2, redis-py async, ARQ (background workers), boto3

### Requirement: layer-backend-workers Layer backend-workers implements its contract

#### Scenario: layer-backend-workers is verified

- **WHEN** the Backend Workers layer is exercised
- **THEN** it conforms to: ARQ-based worker processes for fan-out, notifications, search indexing, media transcoding, and DM delivery. Workers consume domain events from Redis Streams, deduplicate by event id, and write back to PostgreSQL, Redis, S3, OpenSearch, or the realtime push gateway.
- **AND** tech stack honours: Python 3.11, ARQ, redis-py async, FFmpeg, Pillow, OpenSearch client, structlog, OpenTelemetry SDK

### Requirement: layer-frontend Layer frontend implements its contract

#### Scenario: layer-frontend is verified

- **WHEN** the Frontend (Angular) layer is exercised
- **THEN** it conforms to: Angular 17 standalone-component SPA that renders timelines, profiles, threaded replies, DMs, notifications, search/trending, and community views; all I/O is Zod-validated and all client state lives in NgRx signalStores mutated only through patchState.
- **AND** tech stack honours: Angular 17 (standalone components, control flow syntax), PrimeNG 17 (Aura preset), NgRx 17 Signals signalStore, Zod 3 (runtime schema validation), Vitest plus Angular Testing Library, Native WebSocket for live notifications and DMs

### Requirement: layer-shared Layer shared implements its contract

#### Scenario: layer-shared is verified

- **WHEN** the Shared Contracts layer is exercised
- **THEN** it conforms to: Schemas, types, and event catalogs shared between the backend, workers, and the frontend. Single source of truth written in Zod, mirrored in Pydantic, and exposed as TypeScript types, OpenAPI 3.1, and AsyncAPI 2 artefacts.
- **AND** tech stack honours: Zod 3 (TypeScript), Pydantic v2 (Python), OpenAPI 3.1, AsyncAPI 2, openapi-typescript codegen

### Requirement: layer-infra Layer infra implements its contract

#### Scenario: layer-infra is verified

- **WHEN** the Infrastructure layer is exercised
- **THEN** it conforms to: Containerised runtime, IaC, observability, and CI/CD for the whole Microblog Platform stack including media storage, search, WebSocket fan-out, and trending signals.
- **AND** tech stack honours: Terraform 1.6, Kubernetes (EKS 1.29), PostgreSQL 16 (RDS), Redis 7 (ElastiCache), OpenSearch 2 (search and trending), S3 + CloudFront (media bucket and CDN), OpenTelemetry + Prometheus + Grafana, GitHub Actions + Argo CD

