# Capability: Microblog Platform

## Purpose

Capture the user-facing behaviour for **Microblog Platform** as a set of testable requirements. Each requirement maps to a User Story from the source plan; each Scenario to one of that story's acceptance scenarios.

## ADDED Requirements

### Requirement: US001 Read A Home Timeline

As an authenticated reader, I want to open the home feed and see the latest posts from the people I follow so that I can keep up with the conversation.

#### Scenario: FR-001

- **WHEN** the reader opens the home tab
- **THEN** the feed renders the 10 newest posts in reverse chronological order within 1.5s p95
- **AND** given a signed-in reader with 10 followed authors who each posted in the last hour
#### Scenario: FR-002

- **WHEN** they scroll past the 25th post
- **THEN** the next page loads via cursor pagination without full reload
- **AND** given a signed-in reader on the home tab
### Requirement: US002 Compose AND Publish A Post

As an authenticated author, I want to compose a post with optional media and publish it so that my followers see it on their home timeline.

#### Scenario: FR-003

- **WHEN** they tap Publish
- **THEN** the post is persisted with status=published and emitted as post.published.v1
- **AND** given a signed-in author on the composer with a valid 140-char body and one image
#### Scenario: FR-004

- **WHEN** they tap Publish
- **THEN** the publish action is disabled and the body field shows a validation hint
- **AND** given a signed-in author on the composer with an empty body
### Requirement: US003 Send A Direct Message

As an authenticated user, I want to send an encrypted 1:1 direct message to another user so that we can have a private conversation.

#### Scenario: FR-005

- **WHEN** A opens a new conversation with B and sends a message
- **THEN** the message is persisted ciphertext by the notifications outbox and B sees the decrypted plaintext within 1s
- **AND** given two signed-in users A and B with no existing conversation
### Requirement: US004 Search Public Posts

As any visitor, I want to search public posts by keyword so that I can discover content without following the author first.

#### Scenario: FR-006

- **WHEN** they submit the query
- **THEN** the search returns public posts matching "election" ranked by relevance with a relevance score above 0.3
- **AND** given a visitor on the search page with the keyword "election"
