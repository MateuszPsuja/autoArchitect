# Tasks: Microblog Platform

## 1. Phase: 2 task(s)

- [ ] 1.1 Scaffold backend and workers workspaces — verified when: backend contains a runnable FastAPI app with a health endpoint.
- [ ] 1.2 Implement the Moderation Report triage service — verified when: assignNext picks the moderator with the lowest open count among those with capacity.

## 2. US002 — Compose and publish a post

- [ ] 2.1 Implement Post aggregate and repository — verified when: Post aggregate enforces all invariants from the DDD section including 280-char limit.
- [ ] 2.2 Implement Post REST API — verified when: POST /api/posts returns 201 with the persisted PostDTO.
- [ ] 2.3 Build the Angular Post Composer feature — verified when: Submit is disabled when the body is empty or over 280 characters.

## 3. US001 — Read a home timeline

- [ ] 3.1 Implement Fan-out Dispatcher worker — verified when: Dispatcher batches inserts at 500 rows per chunk.
- [ ] 3.2 Build the Angular Home Feed feature — verified when: HomeFeedComponent renders skeletons while the store is loading.

## 4. US004 — Search public posts

- [ ] 4.1 Implement Search Indexer worker — verified when: Indexer flushes at 500 items or 2 seconds, whichever first.

## 5. US003 — Send a direct message

- [ ] 5.1 Implement DM Conversation and Message aggregates — verified when: Conversation reuses an existing pair conversation on a duplicate create.
- [ ] 5.2 Wire the Notifications panel to WSS — verified when: Panel re-renders within 2 seconds of a new notification arriving via WSS.
