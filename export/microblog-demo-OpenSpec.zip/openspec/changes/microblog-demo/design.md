# Design: Microblog Platform

## Context

**Purpose.** Deliver a [TODO: measure], accessible microblog platform with real-time fan-out timelines, threaded conversations, media uploads, search, and direct messages.

**Context.** Replaces a legacy single-server blog with a distributed microblog: a Python FastAPI backend, dedicated fan-out workers, an Angular SPA, and a managed Postgres plus Redis plus OpenSearch stack.

**Key actors.** Anonymous Reader, Authenticated Reader, Author, Moderator (staff), Admin (staff)

**Constraints.** - Public timelines must render in under 2 seconds on 4G.
- Fan-out latency p95 under 1 second from publish to follower timeline.
- Direct messages must be encrypted at rest with envelope encryption.

**System NFRs.** - p95 home feed render under 1.5s on a warm cache.
- 99.9% availability for the read APIs.
- WCAG 2.1 AA compliance for all public pages.
- Zero PII in logs; structured logging with correlation IDs.

## Goals / Non-Goals

**Goals**

- US001 — Read a home timeline
- US002 — Compose and publish a post
- US003 — Send a direct message
- US004 — Search public posts
- Deliver the architecture layers captured under `## Decisions`.

**Non-Goals**

- No explicit non-goals captured.

## Decisions

### Layer: Backend (Python)

FastAPI service exposing REST and WebSocket APIs for the public reader, the personal feed, and the staff moderation console, backed by PostgreSQL, Redis, S3-compatible object storage, and OpenSearch.

- **Tech stack:** Python 3.11, FastAPI 0.111, SQLAlchemy 2 (async), Alembic, Pydantic v2, redis-py async, ARQ (background workers), boto3
- **Patterns:** Domain-Driven Design (aggregates, bounded contexts), Clean Architecture (domain, application, infrastructure, interfaces), Outbox pattern for reliable domain events, Repository pattern with async sessions and Unit of Work, Hexagonal ports and adapters

### Layer: Backend Workers

ARQ-based worker processes for fan-out, notifications, search indexing, media transcoding, and DM delivery. Workers consume domain events from Redis Streams, deduplicate by event id, and write back to PostgreSQL, Redis, S3, OpenSearch, or the realtime push gateway.

- **Tech stack:** Python 3.11, ARQ, redis-py async, FFmpeg, Pillow, OpenSearch client, structlog, OpenTelemetry SDK
- **Patterns:** Idempotent consumers keyed by event id, Stream consumer groups with backoff, Batch processing per chunk, Coalescing for fan-out notifications, Outbox-driven publishing to streams, Dead-letter queue per stream

### Layer: Frontend (Angular)

Angular 17 standalone-component SPA that renders timelines, profiles, threaded replies, DMs, notifications, search/trending, and community views; all I/O is Zod-validated and all client state lives in NgRx signalStores mutated only through patchState.

- **Tech stack:** Angular 17 (standalone components, control flow syntax), PrimeNG 17 (Aura preset), NgRx 17 Signals signalStore, Zod 3 (runtime schema validation), Vitest plus Angular Testing Library, Native WebSocket for live notifications and DMs
- **Patterns:** Standalone components only — no NgModule declarations, Signal-first state via NgRx signalStore; mutate exclusively through patchState inside withMethods, Lazy-loaded feature shells via loadComponent or loadChildren, Route guards for authenticated and staff areas, Strict runtime schema validation with Zod on every HTTP and WebSocket payload

### Layer: Shared Contracts

Schemas, types, and event catalogs shared between the backend, workers, and the frontend. Single source of truth written in Zod, mirrored in Pydantic, and exposed as TypeScript types, OpenAPI 3.1, and AsyncAPI 2 artefacts.

- **Tech stack:** Zod 3 (TypeScript), Pydantic v2 (Python), OpenAPI 3.1, AsyncAPI 2, openapi-typescript codegen
- **Patterns:** Single source of truth per contract (Zod root, Pydantic generated), Generated TypeScript types via z.infer, Versioned event names with semantic suffixes (.v1, .v2), Codegen-on-CI with committed artefacts, Contract-first API design

### Layer: Infrastructure

Containerised runtime, IaC, observability, and CI/CD for the whole Microblog Platform stack including media storage, search, WebSocket fan-out, and trending signals.

- **Tech stack:** Terraform 1.6, Kubernetes (EKS 1.29), PostgreSQL 16 (RDS), Redis 7 (ElastiCache), OpenSearch 2 (search and trending), S3 + CloudFront (media bucket and CDN), OpenTelemetry + Prometheus + Grafana, GitHub Actions + Argo CD
- **Patterns:** 12-factor configuration via environment variables, OpenTelemetry traces and metrics on every request, worker job, and WebSocket frame, Migrations run as a separate one-shot job, not on app start, GitOps via Argo CD with image-digest pinning, Media uploads use pre-signed S3 URLs to keep the API stateless, Infrastructure is immutable: every change goes through git, plan, and apply

### Constitution

Ratified 2026-09-15T00:00:00.000Z; last amended 2026-09-15T00:00:00.000Z (version 1.0.0).

- **Article 1 — Library-First:** Each bounded context ships as a standalone library with a public API and a CLI surface, owned by exactly one team.
- **Article 2 — CLI Interface:** Every library exposes a CLI entry point for ad-hoc operations and integration testing; the CLI is the canonical operator interface.
- **Article 3 — Test-First (TDD):** Tests are written before implementation. Every component ships with a tddSpec that lists BDD Given/When/Then scenarios covering the happy path and the primary failure mode.
- **Article 4 — Integration Testing:** Real dependencies are exercised in integration tests; only repositories and external adapters are stubbed.
- **Article 5 — Observability:** Structured logs with correlation IDs, OpenTelemetry traces, and Prometheus metrics at every cross-process boundary.
- **Article 6 — Versioning & Breaking Changes:** Breaking changes require a major version bump and a migration note. Wire payloads use a `.vN` suffix; consumer is responsible for handling at least N-1.
- **Article 7 — Simplicity:** Prefer the simplest solution that satisfies the constitution checks. Reject premature abstractions and premature optimisation.
- **Article 8 — Anti-Abstraction:** No interface or base class without at least two concrete consumers in the current plan. Repositories do not exist before a second implementation appears.
- **Article 9 — Integration-First Delivery:** Every change ships with at least one integration test that exercises the new path end-to-end. Pure unit-test additions are not a release blocker on their own.


## Risks / Trade-offs

_No non-functional risks captured._

