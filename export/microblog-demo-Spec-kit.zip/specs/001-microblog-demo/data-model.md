# Microblog Platform — Data Model

Cross-layer index of aggregates, value objects, commands, and domain events.

## Domains

| Domain | Layer | Aggregates | Events |
|---|---|---|---|
| [Identity and Access](#identity) | `backend` | 1 | 4 |
| [Posts and Threads](#posts) | `backend` | 2 | 4 |
| [Engagement](#engagement) | `backend` | 3 | 4 |
| [Media](#media) | `backend` | 2 | 4 |
| [Search and Trending](#search) | `backend` | 2 | 3 |
| [Notifications](#notifications) | `backend` | 3 | 4 |

## Identity and Access

Manages user identity lifecycle, authentication credentials, profile attributes, and account state for the microblog platform. Acts as the trusted source of identity used by every other bounded context.

**Layer:** `backend` · **Directory:** `src/identity`

### Aggregates

#### UserAccount

The aggregate root representing a registered member of the platform. It owns credentials, profile attributes, and lifecycle status, and enforces the consistency rules that keep the identity context self-contained.

**Root entity:** `UserAccount`

**Invariants:**

- Username must be unique across the platform and match ^[a-z0-9_]{3,20}$
- Email address must be unique and syntactically valid
- Password is never stored in plaintext; only its hash is persisted
- A deactivated account cannot authenticate, reactivate, or update its profile

**Value objects:**

- `Username`
- `EmailAddress`
- `PasswordHash`
- `DisplayProfile`

**Commands:**

- `Register`
- `VerifyEmail`
- `UpdateProfile`
- `ChangePassword`
- `RequestPasswordReset`
- `Deactivate`

**Domain events emitted:**

- `UserRegistered`
- `EmailVerified`
- `ProfileUpdated`
- `PasswordChanged`
- `PasswordResetRequested`
- `AccountDeactivated`

### Domain Events

#### UserRegistered

Published when a new account successfully completes registration.

**Triggered by:** Register command on UserAccount aggregate

**Handled by:** social-graph, notifications, search

**Payload:**

- `userId`
- `username`
- `email`
- `registeredAt`

#### UserAuthenticated

Published after a successful password-based login. Carries no credentials.

**Triggered by:** AuthenticationService.authenticate

**Handled by:** feed, social-graph, notifications

**Payload:**

- `userId`
- `sessionId`
- `authenticatedAt`

#### ProfileUpdated

Published when a user changes any profile-level attribute such as name, bio, or avatar.

**Triggered by:** UpdateProfile command on UserAccount aggregate

**Handled by:** search, feed

**Payload:**

- `userId`
- `changedFields`
- `updatedAt`

#### PasswordResetRequested

Published when a user requests a password reset, signalling the notifications context to send a reset link.

**Triggered by:** RequestPasswordReset command on UserAccount aggregate

**Handled by:** notifications

**Payload:**

- `userId`
- `resetTokenId`
- `requestedAt`

## Posts and Threads

Bounded context that owns the lifecycle of user-authored short posts and threaded replies, including edits, deletions, and media attachments up to 280 characters.

**Layer:** `backend` · **Directory:** `src/posts`

### Aggregates

#### Post

Owns the lifecycle of a single post or reply, enforcing the 280-character limit, authorship, edit window, and soft-delete semantics.

**Root entity:** `Post`

**Invariants:**

- Post body length is between 1 and 280 characters after trimming
- Only the original author may edit or delete the post
- Edits are not permitted after 24 hours from creation
- A reply must reference an existing non-deleted parent post

**Value objects:**

- `PostId`
- `PostBody`
- `MediaAttachment`
- `AuthorRef`

**Commands:**

- `CreatePost`
- `ReplyToPost`
- `EditPost`
- `DeletePost`
- `AttachMedia`

**Domain events emitted:**

- `PostCreated`
- `PostEdited`
- `PostDeleted`
- `ReplyPosted`

#### Thread

Maintains the structural integrity of reply trees, including parent linkage, orphan handling, and reply count denormalization.

**Root entity:** `Thread`

**Invariants:**

- A thread root is always a top-level (non-reply) post
- Reply count equals the count of non-deleted direct children
- Cyclic reply chains are rejected at write time
- Deleting a thread root soft-cascades to all descendants

**Value objects:**

- `ThreadId`
- `ReplyNode`
- `ThreadStats`

**Commands:**

- `OpenThread`
- `RegisterReply`
- `RecomputeReplyCount`
- `SoftDeleteThread`

**Domain events emitted:**

- `ThreadOpened`
- `ThreadReplyRegistered`
- `ThreadClosed`

### Domain Events

#### PostCreated

Emitted when a new top-level post or reply is successfully persisted.

**Triggered by:** CreatePost or ReplyToPost command

**Handled by:** engagement, feed, notifications, search

**Payload:**

- `postId`
- `authorId`
- `body`
- `parentPostId`
- `createdAt`

#### PostEdited

Emitted when an author updates the body of a post within the edit window.

**Triggered by:** EditPost command

**Handled by:** feed, search

**Payload:**

- `postId`
- `authorId`
- `newBody`
- `editedAt`

#### PostDeleted

Emitted when a post is soft-deleted by its author or by moderation.

**Triggered by:** DeletePost command

**Handled by:** engagement, feed, notifications, search

**Payload:**

- `postId`
- `authorId`
- `deletedAt`
- `reason`

#### ReplyPosted

Emitted when a reply is attached to an existing post, used to thread notifications.

**Triggered by:** ReplyToPost command

**Handled by:** notifications, feed, engagement

**Payload:**

- `replyId`
- `parentPostId`
- `rootPostId`
- `authorId`
- `createdAt`

## Engagement

Tracks user interactions (likes, reposts, bookmarks) on posts, enforces single-action invariants, exposes engagement counters, and publishes engagement events to the feed, posts, and notifications contexts.

**Layer:** `backend` · **Directory:** `src/engagement`

### Aggregates

#### Like

Aggregate representing a single user's like on a target post.

**Root entity:** `Like`

**Invariants:**

- A user can like a given post at most once
- A like must reference an existing post and an existing user
- Unlike is only valid when a like currently exists
- Each state transition emits exactly one domain event

**Value objects:**

- `LikeId`
- `PostId`
- `UserId`
- `LikedAt`

**Commands:**

- `LikePost`
- `UnlikePost`

**Domain events emitted:**

- `PostLiked`
- `PostUnliked`

#### Repost

Aggregate representing a user's simple or quote repost of another post.

**Root entity:** `Repost`

**Invariants:**

- A user cannot repost their own post
- Quote text, if present, must be 1–280 characters
- Repost preserves the original post identifier and author
- Unrepost removes the repost without affecting the original

**Value objects:**

- `RepostId`
- `OriginalPostId`
- `ReposterId`
- `QuoteText`

**Commands:**

- `RepostPost`
- `QuoteRepost`
- `Unrepost`

**Domain events emitted:**

- `PostReposted`
- `PostUnreposted`

#### Bookmark

Aggregate representing a user's private bookmark of a post, optionally grouped into a named collection.

**Root entity:** `Bookmark`

**Invariants:**

- A user can bookmark a given post at most once
- Bookmarks are visible only to the owning user
- Collection name, if present, must be non-empty and ≤ 32 characters
- MoveToCollection requires the bookmark to currently exist

**Value objects:**

- `BookmarkId`
- `PostId`
- `UserId`
- `CollectionName`

**Commands:**

- `BookmarkPost`
- `UnbookmarkPost`
- `MoveToCollection`

**Domain events emitted:**

- `PostBookmarked`
- `PostUnbookmarked`
- `BookmarkMoved`

### Domain Events

#### PostLiked

Emitted when a user likes a post for the first time.

**Triggered by:** Like.LikePost command

**Handled by:** feed, notifications, posts

**Payload:**

- `postId`
- `userId`
- `likedAt`
- `totalLikeCount`

#### PostUnliked

Emitted when a user removes their like from a post.

**Triggered by:** Like.UnlikePost command

**Handled by:** feed, posts

**Payload:**

- `postId`
- `userId`
- `unlikedAt`

#### PostReposted

Emitted when a user reposts or quote-reposts a post.

**Triggered by:** Repost.RepostPost or Repost.QuoteRepost command

**Handled by:** feed, notifications, posts

**Payload:**

- `originalPostId`
- `reposterId`
- `repostId`
- `isQuote`
- `repostedAt`

#### PostBookmarked

Emitted when a user bookmarks a post (used internally by engagement read model).

**Triggered by:** Bookmark.BookmarkPost command

**Handled by:** feed

**Payload:**

- `postId`
- `userId`
- `bookmarkId`
- `collection`

## Media

Manages user-uploaded media assets (images and short videos) including upload lifecycle, asynchronous processing, derivative generation, CDN delivery, attachment linkage, and quota enforcement.

**Layer:** `backend` · **Directory:** `src/media`

### Aggregates

#### MediaAsset

A single uploaded media asset tracked from upload initiation through processing, attachment, and eventual deletion, with ownership and quota invariants.

**Root entity:** `MediaFile`

**Invariants:**

- File size must not exceed the per-type limit (e.g. 5 MB image, 40 MB video)
- MIME type must belong to the platform whitelist; unsupported uploads are rejected
- An asset cannot transition backwards out of Deleted or out of Failed
- Storage key is immutable once CompleteUpload succeeds; only derived URLs change

**Value objects:**

- `MediaType`
- `MediaDimensions`
- `MediaChecksum`
- `StorageLocation`

**Commands:**

- `InitiateUpload`
- `CompleteUpload`
- `MarkProcessing`
- `MarkReady`
- `MarkFailed`
- `Delete`

**Domain events emitted:**

- `MediaUploadCompleted`
- `MediaReady`
- `MediaProcessingFailed`
- `MediaDeleted`

#### MediaAttachment

The linkage between a Ready MediaAsset and the post that references it, tracking role and ordering within a post body.

**Root entity:** `MediaAttachment`

**Invariants:**

- A post may reference at most N media attachments (e.g. 4)
- An attachment cannot exist without a referenced MediaAsset in Ready state
- Attachments are scoped to a single post; cross-post reuse is forbidden
- Detaching an attachment without deleting the asset preserves the asset

**Value objects:**

- `AttachmentRole`
- `AltText`

**Commands:**

- `AttachMedia`
- `ReorderAttachments`
- `DetachMedia`

**Domain events emitted:**

- `MediaAttachedToPost`
- `MediaDetachedFromPost`

### Domain Events

#### MediaReady

Published when an asset finishes transcoding and scanning and is available for delivery.

**Triggered by:** MediaAsset.MarkReady

**Handled by:** posts, feed, moderation

**Payload:**

- `mediaId`
- `ownerId`
- `mediaType`
- `derivedVariants`
- `checksum`

#### MediaProcessingFailed

Published when asynchronous processing cannot produce a deliverable asset.

**Triggered by:** MediaAsset.MarkFailed

**Handled by:** posts, moderation

**Payload:**

- `mediaId`
- `ownerId`
- `reasonCode`

#### MediaAttachedToPost

Published when a Ready media asset is linked to a post.

**Triggered by:** MediaAttachment.AttachMedia

**Handled by:** posts, feed

**Payload:**

- `postId`
- `mediaId`
- `role`

#### MediaDeleted

Published when a media asset is purged from storage after grace period.

**Triggered by:** MediaAsset.Delete

**Handled by:** posts, feed, moderation

**Payload:**

- `mediaId`
- `ownerId`
- `deletedBy`

## Search and Trending

Public full-text search over posts, hashtags, and users plus rolling-window trending topic detection for the microblog platform.

**Layer:** `backend` · **Directory:** `src/search`

### Aggregates

#### Search Index

Projection aggregate holding the searchable view of posts and users consumed by query handlers.

**Root entity:** `IndexedDocument`

**Invariants:**

- Every indexed document references an existing source record id
- Removed sources generate tombstones preventing resurrection by stale replays
- Tokenized fields use the analyzer version active when the document was indexed

**Value objects:**

- `SearchQuery`
- `RelevanceScore`
- `IndexTombstone`

**Commands:**

- `IndexDocument`
- `RemoveDocument`
- `RebuildIndex`

**Domain events emitted:**

- `DocumentIndexed`
- `DocumentRemoved`

#### Trending Topic

Rolling-window aggregate that ranks hashtags by mention velocity and decay-weighted score.

**Root entity:** `TrendingSnapshot`

**Invariants:**

- Snapshot window duration is a positive multiple of the recompute interval
- Ranked topics are always ordered by descending trend score
- Pinned topics persist across recomputes until explicitly unpinned

**Value objects:**

- `TimeWindow`
- `TrendScore`
- `Hashtag`

**Commands:**

- `RecordMention`
- `RecomputeTrends`
- `PinTopic`

**Domain events emitted:**

- `TrendingSnapshotComputed`
- `TrendingTopicPromoted`

### Domain Events

#### Search Index Updated

Emitted when documents are added, updated, or removed from the search index.

**Triggered by:** IndexDocument|RemoveDocument

**Handled by:** posts, engagement, feed

**Payload:**

- `documentId`
- `operation`
- `indexedAt`
- `indexName`

#### Trending Snapshot Computed

Periodic recompute completion carrying the new trending list and window timestamps.

**Triggered by:** RecomputeTrends

**Handled by:** feed, notifications

**Payload:**

- `snapshotId`
- `windowStart`
- `windowEnd`
- `topics`

#### Trending Topic Promoted

A hashtag crossed the promotion threshold and appears on the public trending list.

**Triggered by:** RecomputeTrends

**Handled by:** feed, notifications

**Payload:**

- `hashtag`
- `score`
- `rank`
- `language`

## Notifications

Aggregates, stores, and delivers real-time and historical notifications for users across in-app, push, email, and WebSocket channels, honoring per-user preferences and topic-level mutes.

**Layer:** `backend` · **Directory:** `src/notifications`

### Aggregates

#### NotificationStream

A user's timeline of recorded notifications with read and dismissed lifecycle, subject to aggregation and ordering rules.

**Root entity:** `Notification`

**Invariants:**

- Notification must reference an authenticated userId that owns the stream
- A notification may only transition from UNREAD to READ or DISMISSED
- MarkAllAsRead applies only to UNREAD entries within the same stream
- Aggregation key (type + actor + targetId) prevents duplicate entries within a 1-hour window

**Value objects:**

- `NotificationId`
- `NotificationType`
- `NotificationStatus`
- `NotificationPayload`

**Commands:**

- `RecordNotification`
- `MarkAsRead`
- `MarkAllAsRead`
- `DismissNotification`
- `RehydrateFromSnapshot`

**Domain events emitted:**

- `NotificationRecorded`
- `NotificationRead`
- `NotificationDismissed`
- `NotificationsBulkRead`

#### NotificationPreferences

Per-user settings for which event types fan out to which channels, including quiet hours and topic-level mutes.

**Root entity:** `UserPreferences`

**Invariants:**

- At least one of {inApp, push, email} must remain enabled
- QuietHours start and end must form a valid time range or both be null
- MutedType entries cannot be re-enabled within the same transaction
- EmailDigest cadence must be one of {realtime, hourly, daily, off}

**Value objects:**

- `ChannelPreference`
- `QuietHours`
- `TopicMute`
- `EmailDigest`

**Commands:**

- `SetChannelPreference`
- `SetQuietHours`
- `MuteType`
- `UnmuteType`
- `ResetPreferences`

**Domain events emitted:**

- `NotificationPreferencesUpdated`
- `NotificationTypeMuted`
- `QuietHoursChanged`

#### NotificationDelivery

Tracks per-channel delivery attempts and retries for a recorded notification.

**Root entity:** `DeliveryJob`

**Invariants:**

- DeliveryJob requires a reference to a recorded NotificationId
- Retry count must not exceed the policy-defined maximum (default 5)
- Terminal statuses (DELIVERED, FAILED, EXPIRED) reject further state transitions
- InApp and Push channels enqueue independently and may succeed or fail separately

**Value objects:**

- `DeliveryChannel`
- `DeliveryStatus`
- `RetryPolicy`
- `DeliveryAttempt`

**Commands:**

- `EnqueueDelivery`
- `MarkDelivered`
- `MarkFailed`
- `RetryDelivery`
- `ExpireDelivery`

**Domain events emitted:**

- `DeliveryEnqueued`
- `DeliveryCompleted`
- `DeliveryFailed`
- `DeliveryRetried`

### Domain Events

#### NotificationRecorded

A new notification was added to a user stream after aggregation and preference filtering.

**Triggered by:** NotificationStream.RecordNotification

**Handled by:** notification-dispatcher, notification-feed-projector

**Payload:**

- `notificationId`
- `userId`
- `type`
- `actorId`
- `targetId`
- `createdAt`

#### NotificationRead

A user marked a specific notification as read.

**Triggered by:** NotificationStream.MarkAsRead

**Handled by:** notification-repository, unread-counter-projector

**Payload:**

- `notificationId`
- `userId`
- `readAt`

#### NotificationPreferencesUpdated

User changed channel, mute, or quiet-hour preferences.

**Triggered by:** NotificationPreferences.SetChannelPreference

**Handled by:** notification-dispatcher

**Payload:**

- `userId`
- `changedFields`
- `effectiveAt`

#### DeliveryCompleted

A delivery job reached a terminal success state on its target channel.

**Triggered by:** NotificationDelivery.MarkDelivered

**Handled by:** delivery-analytics, billing-meter

**Payload:**

- `deliveryId`
- `notificationId`
- `channel`
- `completedAt`
