# Implementation Plan: Microblog Platform

> A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications.

**Branch**: `001-microblog-demo` · **Date**: 2026-09-15T00:00:00.000Z · **Spec**: [./spec.md](./spec.md)

**Note**: This template describes the planner's implementation workflow.

## Summary

A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications.

## Technical Context

| Field | Value |
|---|---|
| **Language / Version** | TypeScript 5.x (Angular 17+, Node 20+) |
| **Primary Dependencies** | Python 3.11, FastAPI 0.111, SQLAlchemy 2 (async), Alembic, Pydantic v2, redis-py async, ARQ (background workers), boto3, ARQ, FFmpeg, Pillow, OpenSearch client, structlog, OpenTelemetry SDK, Angular 17 (standalone components, control flow syntax), PrimeNG 17 (Aura preset), NgRx 17 Signals signalStore, Zod 3 (runtime schema validation), Vitest plus Angular Testing Library, Native WebSocket for live notifications and DMs, Zod 3 (TypeScript), Pydantic v2 (Python), OpenAPI 3.1, AsyncAPI 2, openapi-typescript codegen, Terraform 1.6, Kubernetes (EKS 1.29), PostgreSQL 16 (RDS), Redis 7 (ElastiCache), OpenSearch 2 (search and trending), S3 + CloudFront (media bucket and CDN), OpenTelemetry + Prometheus + Grafana, GitHub Actions + Argo CD <br/> _langchain decision: Agent framework: none — deterministic retrieval via the chosen embedding model. See ADR-0001 in `docs/20-decisions/ADR-0001-agent-framework.md`._ |
| **Storage** | PostgreSQL 16 via SQLAlchemy 2 async; Redis 7 for hot caches and timeline fan-out; S3-compatible object storage for media; OpenSearch 2 for search and trending; Redis Streams for input; PostgreSQL, S3, and OpenSearch for output; Browser memory only; no IndexedDB or localStorage; persistence happens via the backend and HttpOnly session cookies; Repo-committed Zod sources + codegen artefacts (Pydantic models, openapi.yaml, asyncapi.yaml); no runtime database; GitHub Actions cache + ECR (tagged by digest) + S3 media bucket (versioned, lifecycle to Glacier) |
| **Testing** | Vitest / Jasmine for frontend, pytest for backend |
| **Target Platform** | Linux server (Python 3.11) containerised via Docker; deployed behind a reverse proxy with TLS termination; Linux containers (amd64 plus arm64); Browser (Chrome 110+, Firefox 110+, Safari 16+, Edge 110+) on desktop and mobile viewports; Node 20 + Python 3.11 codegen runners on CI; artefacts consumed by web SPA and FastAPI backend; Linux containers (amd64 plus arm64) on Kubernetes 1.29 |
| **Project Type** | Multi-layer (backend + backend-workers + frontend + shared + infra) |
| **Performance Goals** | p95 GET home timeline under 200ms; p95 POST post under 400ms; fan-out worker sustains 50k posts per minute at peak; Fan-out dispatcher processes 10k events per minute per replica with p95 latency under 1s; TTI under 3s on a cold cache; LCP under 2s on 4G; main-thread long tasks under 50ms; first feed paint under 1.5s; Full codegen completes in under 30 seconds on CI; schema validation on the client adds under 1 ms per request; CI build under 12 minutes; production deploy under 5 minutes; image pull under 30 seconds on a warm cluster; p95 feed read under 200ms |
| **Constraints** | Domain layer MUST have zero framework imports; every status transition MUST be idempotent and emit exactly one domain event via the outbox; all authorization checks MUST live in the application layer, never in routes; Workers must be idempotent on event id; transient errors retry with exponential backoff up to 5 times; No BehaviorSubject or ReplaySubject — use signals only. Mutate signalStore state only via patchState inside withMethods. All HTTP and WSS payloads must be Zod-validated before reaching components. No NgModules.; No hand-written TypeScript request or response types; every type is z.infer. No breaking changes without a .vN+1 suffix on the event name. openapi.yaml and asyncapi.yaml must be regenerated and committed in the same PR as any schema change.; Pin base image digests, not tags. Migrations run as a separate one-shot job, not on app start. Every alert links to a runbook. Media uploads use pre-signed S3 URLs. Sidecars bind to 127.0.0.1 only. |
| **Scale / Scope** | 1M MAU readers, 50k posts per minute at peak, 200 RPS on read endpoints, 50 RPS on write endpoints; 1k concurrent jobs per replica across 6 worker kinds, 3 replicas each; 1M MAU, 50k posts per minute, 10k signed-in DM sessions per day, ~100k concurrent WebSocket connections; ~80 Zod schemas, ~30 AsyncAPI events across 12 bounded contexts (posts, engagement, identity, dm, communities, search, trends, media, moderation, notifications, feeds, billing); 3 environments (dev, staging, prod), ~80 services, ~20TB PostgreSQL, ~50TB S3, ~10M daily active users |

## Constitution Check

All gates pass at the current draft:

- ✅ Article 1 — Library-First
- ✅ Article 2 — CLI Interface
- ✅ Article 3 — Test-First (TDD)
- ✅ Article 4 — Integration Testing
- ✅ Article 5 — Observability
- ✅ Article 6 — Versioning & Breaking Changes
- ✅ Article 7 — Simplicity
- ✅ Article 8 — Anti-Abstraction
- ✅ Article 9 — Integration-First Delivery

**Per-layer gates:**

- ✅ `backend` — Strict type checking on every Pydantic schema (extra=forbid) and mypy --strict on the application layer
- ✅ `backend` — At least 2 unit tests plus 1 integration test per use case, with the domain layer tested without I/O
- ✅ `backend` — Domain layer has zero framework imports (no FastAPI, SQLAlchemy, Redis, boto3, or OpenSearch client)
- ✅ `backend` — Outbox pattern is used for every domain event; no synchronous cross-context calls from request handlers
- ✅ `backend` — All authorization checks live in the application layer; routes never short-circuit policy decisions
- ✅ `backend` — Background work runs only in ARQ workers; the web process never executes long jobs inline
- ✅ `backend-workers` — Every worker job is idempotent on its event id
- ✅ `backend-workers` — Workers never call the API directly; they consume events from Redis Streams
- ✅ `backend-workers` — Every job emits an OpenTelemetry span with the event id as an attribute
- ✅ `backend-workers` — Failed jobs go to a per-stream DLQ after 5 retries
- ✅ `backend-workers` — Worker processes expose a /healthz endpoint
- ✅ `frontend` — Strict TypeScript with noImplicitAny and strictNullChecks
- ✅ `frontend` — Standalone components only — no NgModule declarations
- ✅ `frontend` — Mutate signalStore state only via patchState inside withMethods
- ✅ `frontend` — All HTTP and WSS payloads validated with a Zod schema before reaching components
- ✅ `frontend` — Lazy-load every top-level feature via loadComponent or loadChildren
- ✅ `frontend` — Route guards (AuthGuard, StaffGuard) wrap every protected route; no client-side trust of auth state
- ✅ `frontend` — Accessibility: WCAG 2.1 AA targets with PrimeNG ARIA primitives and keyboard-navigable timeline
- ✅ `shared` — Zod schema is the source of truth; TypeScript types and Pydantic models are generated, never handwritten
- ✅ `shared` — Every domain event is declared in the AsyncAPI catalogue with a versioned name (.vN)
- ✅ `shared` — OpenAPI 3.1 spec is regenerated on every CI run and committed to the repo
- ✅ `shared` — Breaking payload changes require a new .vN+1 suffix on the event name and a deprecation window
- ✅ `shared` — Schemas live in shared/schemas and are imported by both backend and frontend through the codegen artefacts
- ✅ `shared` — codegen drift (committed artefact != generated artefact) fails CI on both backend and frontend
- ✅ `infra` — All images pinned by digest, not tag
- ✅ `infra` — Migrations run as a separate one-shot job, not on app start
- ✅ `infra` — OpenTelemetry traces and metrics exported on every request, worker job, and WebSocket frame
- ✅ `infra` — Every Prometheus alert links to a runbook in docs/runbooks/
- ✅ `infra` — CI fails on any uncommitted generated artefact (OpenAPI, TS types, Terraform plan)
- ✅ `infra` — Sidecars bind to 127.0.0.1 only; multi-tenant access is enforced at the listen address

## Project Structure

### Documentation (this plan)

```text
specs/
└── 001-microblog-demo/
    ├── README.md
    ├── spec.md
    ├── plan.md
    ├── data-model.md
    ├── contracts/
    ├── quickstart.md
    ├── tasks.md
    ├── checklist.md
    ├── ARCHITECTURE.md
    ├── AGENTS.md
    └── docs/
        ├── 00-system/
        ├── 10-architecture/
        ├── 20-decisions/
        ├── 30-…/ (per layer)
        ├── 50-workflows/
        └── 60-agent-tasks/
```

### Source Code

```text
backend/src/
backend/src/direct_messages/domain/
backend/src/direct_messages/domain/aggregates/
backend/src/moderation/application/
backend/src/moderation/domain/
backend/src/posts/domain/aggregates/
backend/src/posts/infrastructure/repositories/
backend/src/posts/interfaces/
backend/src/search/infrastructure/
frontend/src/app/core/stores/
frontend/src/app/core/ws/
frontend/src/app/features/home/
frontend/src/app/features/notifications/
infra/docker/
shared/python/
workers/src/
workers/src/fan_out/
workers/src/search_index/
```

**Structure Decision**: [Document the selected structure — see the per-layer `projectStructureTree` diagrams in `docs/10-architecture/`]

## Complexity Tracking

> No constitution violations; standard complexity.

## See also

- Data model: [./data-model.md](./data-model.md)
- API contracts: [./contracts/](./contracts/)
- Quickstart: [./quickstart.md](./quickstart.md)
- Checklist: [./checklist.md](./checklist.md)