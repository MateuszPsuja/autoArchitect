# Shared Contracts — Contracts

> Public surface for the **shared** layer. Sourced from each component's `publicApi`, `inputs`, and `outputs`.

## UserAccount Aggregate

**Type:** `aggregate` · **Layer:** `domain` · **File:** `src/identity/domain/user-account.aggregate.ts`

Domain aggregate root for registered users; encapsulates identity, credentials, profile, and lifecycle invariants.

**Public API:**

- `register`
- `verifyEmail`
- `updateProfile`
- `changePassword`
- `requestPasswordReset`
- `deactivate`

**Inputs:**

- RegisterCommand
- VerifyEmailCommand
- UpdateProfileCommand
- ChangePasswordCommand
- RequestPasswordResetCommand
- DeactivateCommand

**Outputs:**

- UserAccount
- DomainEvent[]
- DomainError

## Authentication Service

**Type:** `domain-service` · **Layer:** `domain` · **File:** `src/identity/domain/authentication.service.ts`

Domain service that verifies passwords against stored hashes and mints short-lived bearer tokens for use across the platform.

**Public API:**

- `authenticate`
- `verifyToken`
- `revokeToken`

**Inputs:**

- userId
- presentedPassword
- clockNow

**Outputs:**

- AuthToken
- AuthenticationResult
- DomainError

## UserAccount Repository

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/identity/infrastructure/user-account.repository.ts`

Persistence port and adapter for UserAccount aggregates, exposing lookups by id, username, and email.

**Public API:**

- `save`
- `findById`
- `findByUsername`
- `findByEmail`

**Inputs:**

- UserAccount
- userId
- username
- email

**Outputs:**

- UserAccount
- null
- DomainError

## Register Account Use Case

**Type:** `use-case` · **Layer:** `application` · **File:** `src/identity/application/register-account.use-case.ts`

Application-layer orchestration for new account creation: validates input, hashes the password, calls the aggregate, persists, and triggers verification email delivery.

**Public API:**

- `execute`

**Inputs:**

- RegistrationRequest
- ipAddress
- userAgent

**Outputs:**

- UserAccount
- DomainError

## PostAggregate

**Type:** `aggregate` · **Layer:** `domain` · **File:** `src/posts/domain/post.py`

Domain entity and value objects enforcing post invariants such as length, authorship, and edit window.

**Public API:**

- `Post.create`
- `Post.reply`
- `Post.edit`
- `Post.softDelete`
- `Post.reconstitute`

**Inputs:**

- authorId
- body
- parentPostId
- mediaIds

**Outputs:**

- Post instance
- domain events

## PostRepository

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/posts/infrastructure/post_repository.py`

Persistence port for Post aggregates using the application's chosen datastore.

**Public API:**

- `save`
- `findById`
- `findByAuthor`
- `findReplies`
- `softDelete`

**Inputs:**

- Post
- authorId
- parentPostId
- cursor

**Outputs:**

- Post
- Post list
- page metadata

## CreatePostUseCase

**Type:** `use-case` · **Layer:** `application` · **File:** `src/posts/application/create_post.py`

Application service orchestrating Post creation, persistence, and event publication.

**Public API:**

- `execute`

**Inputs:**

- callerId
- body
- mediaIds
- parentPostId

**Outputs:**

- Post

## PostController

**Type:** `controller` · **Layer:** `infrastructure` · **File:** `src/posts/api/post_controller.py`

HTTP boundary exposing post CRUD and reply endpoints for clients.

**Public API:**

- `POST /posts`
- `POST /posts/{id}/reply`
- `PATCH /posts/{id}`
- `DELETE /posts/{id}`
- `GET /posts/{id}`

**Inputs:**

- HTTP request body
- Authorization header
- path parameters

**Outputs:**

- JSON response
- HTTP status

## Like Aggregate

**Type:** `aggregate` · **Layer:** `domain` · **File:** `src/engagement/like_aggregate.py`

Domain aggregate enforcing single-like-per-user rule and emitting like and unlike events.

**Public API:**

- `LikePost`
- `UnlikePost`
- `IsLikedBy`
- `GetLike`

**Inputs:**

- userId
- postId
- action

**Outputs:**

- Like entity
- domain events

## Repost Aggregate

**Type:** `aggregate` · **Layer:** `domain` · **File:** `src/engagement/repost_aggregate.py`

Domain aggregate handling simple and quote reposts with author-attribution invariants.

**Public API:**

- `RepostPost`
- `QuoteRepost`
- `Unrepost`
- `GetRepost`

**Inputs:**

- reposterId
- originalPostId
- quoteText (optional)

**Outputs:**

- Repost entity
- domain events

## Engagement Controller

**Type:** `controller` · **Layer:** `application` · **File:** `src/engagement/engagement_controller.py`

HTTP controller exposing like, repost, and bookmark endpoints with auth and idempotency.

**Public API:**

- `POST /posts/{id}/like`
- `DELETE /posts/{id}/like`
- `POST /posts/{id}/repost`
- `POST /posts/{id}/quote`
- `DELETE /posts/{id}/bookmark`

**Inputs:**

- HTTP request (auth token, path and body params, idempotency key)

**Outputs:**

- HTTP 200/201/204 with engagement result
- HTTP 4xx with domain error code

## Engagement Read Model

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/engagement/engagement_read_model.py`

Repository-backed query service exposing like and repost counts, projected from domain events.

**Public API:**

- `GetCounts(postId)`
- `GetCountsBatch(postIds)`
- `ProjectEvent(event)`

**Inputs:**

- postId
- batch of postIds
- incoming domain event

**Outputs:**

- EngagementCounts DTO (likes, reposts, quotes)
- projection ack/nack

## MediaAssetAggregate

**Type:** `aggregate` · **Layer:** `domain` · **File:** `src/media/domain/media_asset.py`

Domain aggregate encapsulating state transitions for a media file from initiation through deletion.

**Public API:**

- `MediaAsset.create`
- `MediaAsset.completeUpload`
- `MediaAsset.markProcessing`
- `MediaAsset.markReady`
- `MediaAsset.markFailed`
- `MediaAsset.delete`

**Inputs:**

- InitiateUploadCommand
- CompleteUploadCommand
- MarkProcessingCommand
- MarkReadyCommand
- MarkFailedCommand
- DeleteCommand

**Outputs:**

- MediaUploadCompletedEvent
- MediaReadyEvent
- MediaProcessingFailedEvent
- MediaDeletedEvent

## MediaUploadUseCase

**Type:** `use-case` · **Layer:** `application` · **File:** `src/media/application/media_upload_use_case.py`

Application use case that orchestrates a resumable upload: validate, reserve storage, hand off to processor, persist final state.

**Public API:**

- `MediaUploadUseCase.initiate`
- `MediaUploadUseCase.complete`
- `MediaUploadUseCase.handleProcessorNotification`

**Inputs:**

- InitiateUploadInput
- CompleteUploadInput
- MediaReadyNotification
- MediaFailedNotification

**Outputs:**

- UploadSession
- MediaUploadResult
- MediaAcknowledgment

## MediaStorageRepository

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/media/infrastructure/media_storage_repository.py`

Infrastructure repository implementing MediaRepository and MediaStoragePort against the chosen object store and database.

**Public API:**

- `MediaStorageRepository.save`
- `MediaStorageRepository.find`
- `MediaStorageRepository.reserve`
- `MediaStorageRepository.issueCdnUrl`
- `MediaStorageRepository.deleteObject`

**Inputs:**

- MediaAsset
- StorageReservationRequest
- ObjectKey
- Checksum

**Outputs:**

- MediaAsset (loaded)
- UploadTicket
- CdnUrl
- StorageMetadata

## MediaProcessorWebhookController

**Type:** `controller` · **Layer:** `infrastructure` · **File:** `src/media/infrastructure/media_processor_webhook.py`

Infrastructure controller receiving asynchronous success/failure notifications from the media pipeline and reconciling them with persisted assets.

**Public API:**

- `MediaProcessorWebhookController.handle_success`
- `MediaProcessorWebhookController.handle_failure`
- `MediaProcessorWebhookController.health`

**Inputs:**

- WebhookHeaders
- ProcessingSuccessPayload
- ProcessingFailurePayload

**Outputs:**

- HttpAck
- DomainCommandEnvelope
- RetryHint

## Search Controller

**Type:** `controller` · **Layer:** `application` · **File:** `src/search/search_controller.py`

FastAPI HTTP layer exposing /search and /trending endpoints with auth, rate limiting, and validation.

**Public API:**

- `GET /search/posts`
- `GET /search/users`
- `GET /trending/topics`
- `GET /search/suggest`

**Inputs:**

- query string
- filter params
- auth context
- pagination cursor

**Outputs:**

- result page
- trend list
- request id
- rate-limit headers

## Search Query Service

**Type:** `service` · **Layer:** `application` · **File:** `src/search/search_query_service.py`

Application service that parses queries, applies ranking and filters, and returns paginated result pages.

**Public API:**

- `search(query, ctx)`
- `suggest(prefix, ctx)`
- `countMatches(query, ctx)`

**Inputs:**

- SearchQuery value object
- user context
- filter set
- page size

**Outputs:**

- ranked result page
- total estimate
- next cursor

## Search Indexing Service

**Type:** `service` · **Layer:** `infrastructure` · **File:** `src/search/search_indexing_service.py`

Infrastructure service consuming upstream events to maintain the search index projection.

**Public API:**

- `applyEvent(event)`
- `rebuildFromSnapshot(snapshot)`
- `getLag()`

**Inputs:**

- upstream domain events
- replay cursor
- index settings

**Outputs:**

- indexed documents
- tombstones
- lag metrics

## Trending Computation Service

**Type:** `service` · **Layer:** `domain` · **File:** `src/search/trending_computation_service.py`

Domain service that aggregates hashtag mentions and produces immutable trending snapshots.

**Public API:**

- `recompute(now)`
- `getLatestSnapshot()`
- `pinTopic(hashtag, ttl)`

**Inputs:**

- engagement events
- window configuration
- pin list

**Outputs:**

- TrendingSnapshot
- ranked hashtag list
- compute metadata

## NotificationStreamAggregate

**Type:** `aggregate` · **Layer:** `domain` · **File:** `src/notifications/domain/notification_stream.py`

Domain aggregate governing the lifecycle of a user's notification stream, including aggregation, read and dismissed transitions, and event emission.

**Public API:**

- `record`
- `markAsRead`
- `markAllAsRead`
- `dismiss`
- `rehydrate`

**Inputs:**

- userId
- actorId
- type
- targetId
- payload
- aggregationWindow

**Outputs:**

- Notification entity
- NotificationRecorded event
- NotificationRead event
- NotificationsBulkRead event

## NotificationPreferencesAggregate

**Type:** `aggregate` · **Layer:** `domain` · **File:** `src/notifications/domain/notification_preferences.py`

Domain aggregate holding per-user channel, quiet-hours, mute, and digest preferences, enforcing self-consistency invariants.

**Public API:**

- `setChannelPreference`
- `setQuietHours`
- `muteType`
- `unmuteType`
- `reset`
- `isChannelEnabled`

**Inputs:**

- userId
- channel
- enabled
- quietHoursStart
- quietHoursEnd
- mutedType

**Outputs:**

- UserPreferences entity
- NotificationPreferencesUpdated event
- NotificationTypeMuted event
- QuietHoursChanged event

## NotificationRepository

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/notifications/infrastructure/notification_repository.py`

Infrastructure repository persisting NotificationStream and DeliveryJob state in PostgreSQL with Redis caching for unread counters and recent streams.

**Public API:**

- `saveStream`
- `loadStream`
- `listByUser`
- `markRead`
- `saveDeliveryJob`
- `getUnreadCount`

**Inputs:**

- Notification entity
- DeliveryJob entity
- userId
- pageCursor
- statusFilter

**Outputs:**

- Notification entity
- Notification list
- DeliveryJob entity
- unreadCount integer

## NotificationsController

**Type:** `controller` · **Layer:** `presentation` · **File:** `src/notifications/api/notifications_controller.py`

Presentation layer exposing REST endpoints for inbox management and a WebSocket channel for real-time push of newly recorded notifications.

**Public API:**

- `GET /notifications`
- `POST /notifications/{id}/read`
- `POST /notifications/read-all`
- `DELETE /notifications/{id}`
- `GET /notifications/preferences`
- `WS /ws/notifications`

**Inputs:**

- HTTP request
- WebSocket connection
- JWT bearer token
- cursor query param
- status filter

**Outputs:**

- JSON envelope
- WebSocket frames
- 204 No Content
- 401/403/404 HTTP responses
