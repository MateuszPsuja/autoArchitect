# Microblog Platform — Architecture & Planning Bundle

> A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications.

**Branch:** `001-microblog-demo` · **Export version:** `3` · **Per-feature folder:** `001-microblog-demo/`

This bundle is the planner's standard documentation set. Top-level layout:

| Artefact | Path |
|---|---|
| Project constitution | `.specify/memory/constitution.md` |
| Feature specification | `spec.md` |
| Implementation plan | `plan.md` |
| Data model | `data-model.md` |
| Per-layer contracts | `contracts/<layer>.md` |
| Quickstart / validation scenarios | `quickstart.md` |
| Task list (User Story phases) | `tasks.md` |
| Compliance checklist | `checklist.md` |
| Architecture summary | `ARCHITECTURE.md` |
| Agent implementation guide | `AGENTS.md` |
| Per-layer architecture docs | `docs/10-architecture/` |
| Domain docs | `docs/30-*/<domain>/` (etc.) |
| ADRs | `docs/20-decisions/` |
| Workflows | `docs/50-workflows/` |
| Agent task details | `docs/60-agent-tasks/` |
| Per-directory AGENTS.md | `<directory>/AGENTS.md` |
| Plan JSON (root of bundle, for tools) | `../plan.json` |

> **Note.** `research.md` is **omitted** when no research phase produced notes. Once the planner grows a research step, this README will list it.

Generated: 2026-09-15T00:00:00.000Z