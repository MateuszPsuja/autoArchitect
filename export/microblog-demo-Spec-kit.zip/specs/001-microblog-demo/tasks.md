# Tasks: Microblog Platform

> Tasks organised by User Story priority. Tests are written **before** implementation inside each story phase. Tasks with disjoint files (`fileHints`) AND disjoint user stories (`userStoryIds`) from every other task are marked `[P]` (parallelizable).

## Format

`- [ ] T### [P?] [USn?] Description — files: a, b`

## Path Conventions

- Repo root: this plan's branch (`specs/<NNN>-<slug>/`)
- Per-layer architecture: `docs/10-architecture/<layer>-architecture.md`
- Per-task file: `docs/60-agent-tasks/<NN>-<slug>.md`

## Phase 1: Setup (Shared Infrastructure)

- [ ] T001 Bootstrap repository layout per `docs/10-architecture/overview.md` and per-layer `projectStructureTree`.

## Phase 2: Foundational (Blocking Prerequisites)

- [ ] T002 [PHASE 2] (pack) Article 2 — identity-bootstrap-avatar CLI subcommand
- [ ] T003 [PHASE 2] (pack) Article 2 — identity-replay-transcript CLI subcommand
- [ ] T004 [PHASE 2] (pack) Article 2 — identity-run-harness CLI subcommand
- [ ] T005 [PHASE 2] (pack) Article 2 — social-graph-bootstrap-avatar CLI subcommand
- [ ] T006 [PHASE 2] (pack) Article 2 — social-graph-replay-transcript CLI subcommand
- [ ] T007 [PHASE 2] (pack) Article 2 — social-graph-run-harness CLI subcommand
- [ ] T008 [PHASE 2] (pack) Article 2 — posts-bootstrap-avatar CLI subcommand
- [ ] T009 [PHASE 2] (pack) Article 2 — posts-replay-transcript CLI subcommand
- [ ] T010 [PHASE 2] (pack) Article 2 — posts-run-harness CLI subcommand
- [ ] T011 [PHASE 2] (pack) Article 2 — engagement-bootstrap-avatar CLI subcommand
- [ ] T012 [PHASE 2] (pack) Article 2 — engagement-replay-transcript CLI subcommand
- [ ] T013 [PHASE 2] (pack) Article 2 — engagement-run-harness CLI subcommand
- [ ] T014 [PHASE 2] (pack) Article 2 — media-bootstrap-avatar CLI subcommand
- [ ] T015 [PHASE 2] (pack) Article 2 — media-replay-transcript CLI subcommand
- [ ] T016 [PHASE 2] (pack) Article 2 — media-run-harness CLI subcommand
- [ ] T017 [PHASE 2] (pack) Article 2 — search-bootstrap-avatar CLI subcommand
- [ ] T018 [PHASE 2] (pack) Article 2 — search-replay-transcript CLI subcommand
- [ ] T019 [PHASE 2] (pack) Article 2 — search-run-harness CLI subcommand
- [ ] T020 [PHASE 2] (pack) Article 2 — notifications-bootstrap-avatar CLI subcommand
- [ ] T021 [PHASE 2] (pack) Article 2 — notifications-replay-transcript CLI subcommand
- [ ] T022 [PHASE 2] (pack) Article 2 — notifications-run-harness CLI subcommand
- [ ] T023 [PHASE 2] (pack) Article 2 — messaging-bootstrap-avatar CLI subcommand
- [ ] T024 [PHASE 2] (pack) Article 2 — messaging-replay-transcript CLI subcommand
- [ ] T025 [PHASE 2] (pack) Article 2 — messaging-run-harness CLI subcommand
- [ ] T026 [PHASE 2] (pack) Article 2 — communities-bootstrap-avatar CLI subcommand
- [ ] T027 [PHASE 2] (pack) Article 2 — communities-replay-transcript CLI subcommand
- [ ] T028 [PHASE 2] (pack) Article 2 — communities-run-harness CLI subcommand
- [ ] T029 [PHASE 2] (pack) Article 2 — moderation-bootstrap-avatar CLI subcommand
- [ ] T030 [PHASE 2] (pack) Article 2 — moderation-replay-transcript CLI subcommand
- [ ] T031 [PHASE 2] (pack) Article 2 — moderation-run-harness CLI subcommand
- [ ] T032 [PHASE 2] (pack) Article 2 — feed-bootstrap-avatar CLI subcommand
- [ ] T033 [PHASE 2] (pack) Article 2 — feed-replay-transcript CLI subcommand
- [ ] T034 [PHASE 2] (pack) Article 2 — feed-run-harness CLI subcommand
- [ ] T035 [PHASE 2] (pack) Article 2 — top-level CLI composer
- [ ] T036 [PHASE 2] (pack) Article 4 — Vitest integration spec for minimaxLlm
- [ ] T037 [PHASE 2] (pack) Article 4 — pytest integration spec for minimaxLlm
- [ ] T038 [PHASE 2] (pack) Article 4 — Vitest integration spec for minimaxStt
- [ ] T039 [PHASE 2] (pack) Article 4 — pytest integration spec for minimaxStt
- [ ] T040 [PHASE 2] (pack) Article 4 — Vitest integration spec for minimaxTts
- [ ] T041 [PHASE 2] (pack) Article 4 — pytest integration spec for minimaxTts
- [ ] T042 [PHASE 2] (pack) Article 4 — Vitest integration spec for minimaxImage
- [ ] T043 [PHASE 2] (pack) Article 4 — pytest integration spec for minimaxImage
- [ ] T044 [PHASE 2] (pack) Article 4 — Vitest integration spec for minimaxVoiceClone
- [ ] T045 [PHASE 2] (pack) Article 4 — pytest integration spec for minimaxVoiceClone
- [ ] T046 [PHASE 2] (pack) Article 4 — CI integration gate
- [ ] T047 [PHASE 2] (pack) Article 4 — Integration coverage matrix
- [ ] T048 [PHASE 2] (pack) Article 5 — Structured logging contract
- [ ] T049 [PHASE 2] (pack) Article 5 — Metrics emitter for turn_latency_ms
- [ ] T050 [PHASE 2] (pack) Article 5 — Metrics emitter for stt_latency_ms
- [ ] T051 [PHASE 2] (pack) Article 5 — Metrics emitter for tts_first_byte_ms
- [ ] T052 [PHASE 2] (pack) Article 5 — Metrics emitter for memory_recall_latency_ms
- [ ] T053 [PHASE 2] (pack) Article 5 — Local observability dashboard
- [ ] T054 [PHASE 2] (pack) Article 5 — Wire observability into FastAPI sidecar
- [ ] T055 [PHASE 2] (pack) Article 5 — Wire observability into Angular SPA

## Phase 3: User Story US001 — Read a home timeline (Priority: P1) 🎯 MVP

**Independent Test**: A signed-in user with at least 10 followed authors sees a paginated home feed sorted by recency.

### Tests for User Story US001 (OPTIONAL — write first)

- [ ] T056 [US001] Author BDD for FR-001: Given a signed-in reader with 10 followed authors who each posted in the last hour, When the reader opens the home tab, Then the feed renders the 10 newest posts in reverse chronological order within 1.5s p95
- [ ] T057 [US001] Author BDD for FR-002: Given a signed-in reader on the home tab, When they scroll past the 25th post, Then the next page loads via cursor pagination without full reload
- [ ] T058 Surface TDD specs for the components this story touches: `post-aggregate`, `post-repository`, `create-post-use-case`, `post-controller`.

### Implementation for User Story US001

- [ ] T059 [P] [US001] Implement Fan-out Dispatcher worker
  - **Files:** `workers/src/fan_out/dispatcher.py`, `workers/src/fan_out/materializer.py`, `workers/src/fan_out/timeline_cache.py`
  - **User Stories:** `US001`
  - Build the worker that consumes post.published.v1 from the Redis stream and materialises timeline rows.
  - **Acceptance criteria:**
    - [ ] Dispatcher batches inserts at 500 rows per chunk.
    - [ ] Dispatcher is idempotent on event id.
    - [ ] Dispatcher prepends to the per-user cache and trims to 800 entries.
    - [ ] Community-scoped posts fan out only to community members.
    - [ ] Tests under workers/tests/fan_out pass.
- [ ] T060 [P] [US001] Build the Angular Home Feed feature
  - **Files:** `frontend/src/app/features/home/home-feed.component.ts`, `frontend/src/app/core/stores/home-feed.store.ts`
  - **User Stories:** `US001`
  - Implement the lazy-loaded Home Feed with virtual scrolling and pull-to-refresh.
  - **Acceptance criteria:**
    - [ ] HomeFeedComponent renders skeletons while the store is loading.
    - [ ] loadMore is invoked on scroll near the bottom.
    - [ ] TTI under 3 seconds on a warm cache.
    - [ ] Vitest tests for the feature shell and the store pass.

## Phase 4: User Story US002 — Compose and publish a post (Priority: P1) 🎯 MVP

**Independent Test**: An author composes a 140-char post with one image and sees it on the home timeline of a followed reader within 2s.

### Tests for User Story US002 (OPTIONAL — write first)

- [ ] T061 [US002] Author BDD for FR-003: Given a signed-in author on the composer with a valid 140-char body and one image, When they tap Publish, Then the post is persisted with status=published and emitted as post.published.v1
- [ ] T062 [US002] Author BDD for FR-004: Given a signed-in author on the composer with an empty body, When they tap Publish, Then the publish action is disabled and the body field shows a validation hint
- [ ] T063 Surface TDD specs for the components this story touches: `post-aggregate`, `post-repository`, `create-post-use-case`, `post-controller`.

### Implementation for User Story US002

- [ ] T064 [P] [US002] Implement Post aggregate and repository
  - **Files:** `backend/src/posts/domain/aggregates/post.py`, `backend/src/posts/infrastructure/repositories/postgres_post_repository.py`
  - **User Stories:** `US002`
  - Build the Post aggregate, the PostRepository, and SQLAlchemy models for posts and outbox.
  - **Acceptance criteria:**
    - [ ] Post aggregate enforces all invariants from the DDD section including 280-char limit.
    - [ ] PostRepository round-trips a Post through PostgreSQL.
    - [ ] publish writes both the post row and the outbox row in one transaction.
    - [ ] Tests under backend/tests/posts pass.
- [ ] T065 [P] [US002] Implement Post REST API
  - **Files:** `backend/src/posts/interfaces/routes.py`, `shared/python/posts.py`
  - **User Stories:** `US002`
  - Wire the Post use cases into FastAPI routes and validate requests with Pydantic schemas.
  - **Acceptance criteria:**
    - [ ] POST /api/posts returns 201 with the persisted PostDTO.
    - [ ] GET /api/posts/{id} returns a single post or 404.
    - [ ] POST /api/posts requires an Idempotency-Key header.
    - [ ] OpenAPI schema is generated and committed.
- [ ] T066 [P] [US002] Build the Angular Post Composer feature
  - **Files:** `frontend/src/app/features/home/post-composer.component.ts`, `frontend/src/app/core/stores/composer.store.ts`
  - **User Stories:** `US002`
  - Implement the lazy-loaded Composer with character counter and media attachment.
  - **Acceptance criteria:**
    - [ ] Submit is disabled when the body is empty or over 280 characters.
    - [ ] Character counter turns red over 260 characters.
    - [ ] Submit is debounced at 600ms.
    - [ ] The store emits submit and resets the composer on 201 Created.

## Phase 5: User Story US003 — Send a direct message (Priority: P2)

**Independent Test**: A user creates a new conversation with another user, sends a message, and the recipient sees the notification fire and the message appear in their inbox within 1s.

### Tests for User Story US003 (OPTIONAL — write first)

- [ ] T067 [US003] Author BDD for FR-005: Given two signed-in users A and B with no existing conversation, When A opens a new conversation with B and sends a message, Then the message is persisted ciphertext by the notifications outbox and B sees the decrypted plaintext within 1s
- [ ] T068 Surface TDD specs for the components this story touches: `user-account-aggregate`, `authentication-service`, `user-account-repository`, `register-account-use-case`.

### Implementation for User Story US003

- [ ] T069 [P] [US003] Implement DM Conversation and Message aggregates
  - **Files:** `backend/src/direct_messages/domain/aggregates/conversation.py`, `backend/src/direct_messages/domain/aggregates/message.py`, `backend/src/direct_messages/domain/dm_encryption.py`
  - **User Stories:** `US003`
  - Build the 1:1 Conversation and Message aggregates with envelope encryption at rest.
  - **Acceptance criteria:**
    - [ ] Conversation reuses an existing pair conversation on a duplicate create.
    - [ ] Message assigns a monotonic sequence per conversation.
    - [ ] delete is rejected after the 60-second window with WindowExpired.
    - [ ] DmEncryption.encrypt then decrypt round-trips a plaintext body.
- [ ] T070 [P] [US003] Wire the Notifications panel to WSS
  - **Files:** `frontend/src/app/features/notifications/notifications-panel.component.ts`, `frontend/src/app/core/ws/notifications.ws.ts`, `frontend/src/app/core/stores/notifications.store.ts`
  - **User Stories:** `US003`
  - Implement the Notifications panel with live WebSocket updates and mark-all-read.
  - **Acceptance criteria:**
    - [ ] Panel re-renders within 2 seconds of a new notification arriving via WSS.
    - [ ] markAllRead is reflected in the UI without a full reload.
    - [ ] Vitest tests for the store and the WSS subscription pass.

## Phase 6: User Story US004 — Search public posts (Priority: P3)

**Independent Test**: A visitor enters a known keyword and the search returns a paginated list of public posts sorted by relevance.

### Tests for User Story US004 (OPTIONAL — write first)

- [ ] T071 [US004] Author BDD for FR-006: Given a visitor on the search page with the keyword "election", When they submit the query, Then the search returns public posts matching "election" ranked by relevance with a relevance score above 0.3
- [ ] T072 Surface TDD specs for the components this story touches: `post-aggregate`, `post-repository`, `create-post-use-case`, `post-controller`.

### Implementation for User Story US004

- [ ] T073 [P] [US004] Implement Search Indexer worker
  - **Files:** `workers/src/search_index/indexer.py`, `backend/src/search/infrastructure/opensearch_client.py`
  - **User Stories:** `US004`
  - Build the buffered OpenSearch indexer that consumes post.published.v1 and post.deleted.v1.
  - **Acceptance criteria:**
    - [ ] Indexer flushes at 500 items or 2 seconds, whichever first.
    - [ ] Indexer removes deleted posts from the index within 5 seconds.
    - [ ] Indexer retries failures with exponential backoff and DLQs after 5 attempts.

## Phase 7: Polish & Cross-Cutting Concerns

**Independent Test**: every success criterion (SC-NNN) has a reproducible measurement harness and the audit/regenerate cycle is green.

### Tests for the polish phase

- [ ] T074 Build the SC-001 measurement harness — SC-001 measurement harness.
- [ ] T075 Build the SC-002 measurement harness — SC-002 measurement harness.
- [ ] T076 Build the SC-003 measurement harness — SC-003 measurement harness.
- [ ] T077 Build the SC-004 measurement harness — SC-004 measurement harness.

### Implementation for the polish phase

- [ ] T078 Implement the SC-001 criteria: p95 home feed render under 1.5s on a warm cache.
- [ ] T079 Implement the SC-002 criteria: Fan-out latency p95 under 1s from publish to follower timeline.
- [ ] T080 Implement the SC-003 criteria: 99.9% availability for the read APIs.
- [ ] T081 Implement the SC-004 criteria: Zero PII in logs; structured logging with correlation IDs.
- [ ] T082 Document the compliance audit + changelog updates.


## Dependencies & Execution Order

- Phase 1 (Setup) blocks every later phase.
- Phase 2 (Foundational) blocks every User Story phase.
- User Story phases (4 of them) can run sequentially or in parallel once Phase 2 completes.

## Parallel Example

```text
# Within a User Story phase:
T101 [P] [US001] Build the Post aggregate
T102 [P] [US001] Build the PostRepository
T103     [US001] Wire the Post REST controller (depends on T101, T102)
```

## Implementation Strategy

- MVP first: ship Phase 1 → Phase 2 → first P1 User Story. Validate before moving on.
- Incremental delivery: each completed User Story phase is independently shippable.
- Tests-first: write BDD scenarios in the `Tests for User Story` sub-phase before the implementation sub-phase.

## Notes

- `[P]` tasks can run in parallel only when their `fileHints` AND `userStoryIds` are disjoint from every other in-flight task.
- `[USn]` markers cross-link the task to a User Story in `spec.md`.
- `(ghost)` / `(synth)` markers flag tasks synthesised by the renderer to close coverage gaps; they are NOT persisted back to `plan.agentTasks` and disappear if the LLM produces real work on the next regeneration.