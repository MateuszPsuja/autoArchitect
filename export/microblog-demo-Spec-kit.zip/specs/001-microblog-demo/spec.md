# Feature Specification: Microblog Platform

**Status**: Draft
**Input**: User description: "A Twitter-like social platform where people share short posts (up to 280 characters), reply in threads, like and repost, attach images or short videos, follow other users, and get a real-time personal feed of updates from people they follow. Includes public search and trending topics, private direct messages, multiple separate communities, and basic moderation tools. For creative ppl"
**Feature Branch**: `001-microblog-demo` · **Generated**: 2026-09-15T00:00:00.000Z

> What users need and why. No tech stack, no code.

## Purpose

Deliver a [TODO: measure], accessible microblog platform with real-time fan-out timelines, threaded conversations, media uploads, search, and direct messages.

## Context

Replaces a legacy single-server blog with a distributed microblog: a Python FastAPI backend, dedicated fan-out workers, an Angular SPA, and a managed Postgres plus Redis plus OpenSearch stack.

## User Scenarios & Testing


### User Story US001 — Read a home timeline (Priority: P1)

As an authenticated reader, I want to open the home feed and see the latest posts from the people I follow so that I can keep up with the conversation.

**Why this priority**

Core read path; without this the platform has no value.

**Independent Test**

A signed-in user with at least 10 followed authors sees a paginated home feed sorted by recency.

**Acceptance Scenarios**

1. **FR-001** —
   - **Given** a signed-in reader with 10 followed authors who each posted in the last hour
   - **When** the reader opens the home tab
   - **Then** the feed renders the 10 newest posts in reverse chronological order within 1.5s p95
2. **FR-002** —
   - **Given** a signed-in reader on the home tab
   - **When** they scroll past the 25th post
   - **Then** the next page loads via cursor pagination without full reload

**Bounded Contexts:** `posts`, `social-graph`

**Cross-references:** ↔ FR-001 ↔ FR-002

### User Story US002 — Compose and publish a post (Priority: P1)

As an authenticated author, I want to compose a post with optional media and publish it so that my followers see it on their home timeline.

**Why this priority**

Without authoring there is no content to read.

**Independent Test**

An author composes a 140-char post with one image and sees it on the home timeline of a followed reader within 2s.

**Acceptance Scenarios**

1. **FR-003** —
   - **Given** a signed-in author on the composer with a valid 140-char body and one image
   - **When** they tap Publish
   - **Then** the post is persisted with status=published and emitted as post.published.v1
2. **FR-004** —
   - **Given** a signed-in author on the composer with an empty body
   - **When** they tap Publish
   - **Then** the publish action is disabled and the body field shows a validation hint

**Bounded Contexts:** `posts`, `media`

**Cross-references:** ↔ FR-003 ↔ FR-004

### User Story US003 — Send a direct message (Priority: P2)

As an authenticated user, I want to send an encrypted 1:1 direct message to another user so that we can have a private conversation.

**Why this priority**

Important for trust, but the public platform works without it.

**Independent Test**

A user creates a new conversation with another user, sends a message, and the recipient sees the notification fire and the message appear in their inbox within 1s.

**Acceptance Scenarios**

1. **FR-005** —
   - **Given** two signed-in users A and B with no existing conversation
   - **When** A opens a new conversation with B and sends a message
   - **Then** the message is persisted ciphertext by the notifications outbox and B sees the decrypted plaintext within 1s

**Bounded Contexts:** `identity`, `notifications`

**Cross-references:** ↔ FR-005

### User Story US004 — Search public posts (Priority: P3)

As any visitor, I want to search public posts by keyword so that I can discover content without following the author first.

**Why this priority**

Discovery; the platform works without it but reach suffers.

**Independent Test**

A visitor enters a known keyword and the search returns a paginated list of public posts sorted by relevance.

**Acceptance Scenarios**

1. **FR-006** —
   - **Given** a visitor on the search page with the keyword "election"
   - **When** they submit the query
   - **Then** the search returns public posts matching "election" ranked by relevance with a relevance score above 0.3

**Bounded Contexts:** `search`, `posts`

**Cross-references:** ↔ FR-006

### User Story US007 — Transcript export (Priority: P2)

Operators can export the transcript of a session for review and archival.

**Why this priority**

Required for compliance review and for the Spec Verifier cross-check loop.

**Independent Test**

Generate a transcript artefact from the spec editor and verify it round-trips through the JSON Schema validator.

**Acceptance Scenarios**

1. **SC-007a** —
   - **Given** a completed session is recorded in the conversation-memory service
   - **When** an operator requests a transcript export
   - **Then** an artefact with `primary=json` and `secondary=markdown` is produced and signed

**Transcript format:** primary: `json`, secondary: `markdown`

## Edge Cases

- Domain layer MUST have zero framework imports
- every status transition MUST be idempotent and emit exactly one domain event via the outbox
- all authorization checks MUST live in the application layer, never in routes
- Workers must be idempotent on event id
- transient errors retry with exponential backoff up to 5 times
- No BehaviorSubject or ReplaySubject — use signals only. Mutate signalStore state only via patchState inside withMethods. All HTTP and WSS payloads must be Zod-validated before reaching components. No NgModules.
- every type is z.infer. No breaking changes without a .vN+1 suffix on the event name. openapi.yaml and asyncapi.yaml must be regenerated and committed in the same PR as any schema change.
- Pin base image digests, not tags. Migrations run as a separate one-shot job, not on app start. Every alert links to a runbook. Media uploads use pre-signed S3 URLs. Sidecars bind to 127.0.0.1 only.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001** — The home timeline must render posts in reverse chronological order with cursor pagination.
- **FR-002** — Post publishing must be idempotent on the Idempotency-Key header.
- **FR-003** — Direct messages must be encrypted at rest with envelope encryption.
- **FR-004** — Media uploads must support JPEG, PNG, and MP4 up to 50 MB. **[NEEDS CLARIFICATION: confirm exact max size per file and whether GIFs are in scope.]**
- **FR-TS-001** — TypeScript compiles in `--strict` mode with zero `any` introduced by app code; library escape hatches are explicitly commented.
- **FR-MYPY-001** — Python sidecar modules run under `mypy --strict` and pass the CI gate.

## Key Entities

- **UserAccount** (`user-account`, in `identity`) — The aggregate root representing a registered member of the platform. It owns credentials, profile attributes, and lifecycle status, and enforces the consistency rules that keep the identity context self-contained.
- **Post** (`post`, in `posts`) — Owns the lifecycle of a single post or reply, enforcing the 280-character limit, authorship, edit window, and soft-delete semantics.
- **Thread** (`thread`, in `posts`) — Maintains the structural integrity of reply trees, including parent linkage, orphan handling, and reply count denormalization.
- **Like** (`like`, in `engagement`) — Aggregate representing a single user's like on a target post.
- **Repost** (`repost`, in `engagement`) — Aggregate representing a user's simple or quote repost of another post.
- **Bookmark** (`bookmark`, in `engagement`) — Aggregate representing a user's private bookmark of a post, optionally grouped into a named collection.
- **MediaAsset** (`media-asset`, in `media`) — A single uploaded media asset tracked from upload initiation through processing, attachment, and eventual deletion, with ownership and quota invariants.
- **MediaAttachment** (`media-attachment`, in `media`) — The linkage between a Ready MediaAsset and the post that references it, tracking role and ordering within a post body.
- **Search Index** (`search-index`, in `search`) — Projection aggregate holding the searchable view of posts and users consumed by query handlers.
- **Trending Topic** (`trending-topic`, in `search`) — Rolling-window aggregate that ranks hashtags by mention velocity and decay-weighted score.
- **NotificationStream** (`notification-stream`, in `notifications`) — A user's timeline of recorded notifications with read and dismissed lifecycle, subject to aggregation and ordering rules.
- **NotificationPreferences** (`notification-preferences`, in `notifications`) — Per-user settings for which event types fan out to which channels, including quiet hours and topic-level mutes.
- **NotificationDelivery** (`notification-delivery`, in `notifications`) — Tracks per-channel delivery attempts and retries for a recorded notification.

## Offline Behaviour

> No offline contract declared. `local-first` is not set on this plan; add `plan.offlineContract` to surface the per-capability degradation matrix below.

## Success Criteria *(mandatory)*

### Measurable Outcomes

| ID | Outcome | Measurement Scenario |
|---|---|---|
| **SC-001** | p95 home feed render under 1.5s on a warm cache. | warm session, single avatar, 10 Mbps down / 2 Mbps up, baseline laptop (Intel i5 / 16 GB), concurrent avatars = 1, sample size n=30 |
| **SC-002** | Fan-out latency p95 under 1s from publish to follower timeline. | — |
| **SC-003** | 99.9% availability for the read APIs. | "warm session = ≤3 min idle; cold session = ≥24 h idle" |
| **SC-004** | Zero PII in logs; structured logging with correlation IDs. | — |

## Preconditions & Constraints

> Operational preconditions and single-tenant constraints. See also `systemOverview.constraints[]`.

- Public timelines must render in under 2 seconds on 4G.
- Fan-out latency p95 under 1 second from publish to follower timeline.
- Direct messages must be encrypted at rest with envelope encryption.

## Non-Goals

- [TODO: measure] — default Multi-user / multi-tenant
- [TODO: measure] — default Mobile platform
- [TODO: measure] — default SSR rendering
- [TODO: measure] — default Voice / avatar marketplace

> Default seed — override via `plan.nonGoals[]`.

## Glossary

| Term | Definition |
|---|---|
| **bounded context** | A DDD-aligned code ownership boundary with its own ubiquitous language. _(default seed)_ |
| **sidecar** | A local process that exposes the LLM/STT/TTS endpoints to the browser via HTTP. _(default seed)_ |
| **BFF** | Backend-for-frontend: an application-layer facade shaped to the SPA surface. _(default seed)_ |
| **signalStore** | NgRx signal-based reactive state container; mutations only via patchState(). _(default seed)_ |
| **OPFS** | Origin Private File System; the browser storage target for cached avatars and transcripts. _(default seed)_ |
| **p95** | 95th percentile latency; the SLO measure used for every time-budget SC. _(default seed)_ |
| **warm session** | A user session that has had activity within the last 3 minutes (see SC-003 baseline). _(default seed)_ |
