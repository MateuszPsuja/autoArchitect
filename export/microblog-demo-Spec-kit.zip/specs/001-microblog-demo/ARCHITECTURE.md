# Microblog Platform — Architecture

> A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications.

## Architecture Approach

### Backend (Python)

FastAPI service exposing REST and WebSocket APIs for the public reader, the personal feed, and the staff moderation console, backed by PostgreSQL, Redis, S3-compatible object storage, and OpenSearch.

**Patterns:** Domain-Driven Design (aggregates, bounded contexts), Clean Architecture (domain, application, infrastructure, interfaces), Outbox pattern for reliable domain events, Repository pattern with async sessions and Unit of Work, Hexagonal ports and adapters
**Tech stack:** Python 3.11, FastAPI 0.111, SQLAlchemy 2 (async), Alembic, Pydantic v2, redis-py async, ARQ (background workers), boto3

### Backend Workers

ARQ-based worker processes for fan-out, notifications, search indexing, media transcoding, and DM delivery. Workers consume domain events from Redis Streams, deduplicate by event id, and write back to PostgreSQL, Redis, S3, OpenSearch, or the realtime push gateway.

**Patterns:** Idempotent consumers keyed by event id, Stream consumer groups with backoff, Batch processing per chunk, Coalescing for fan-out notifications, Outbox-driven publishing to streams, Dead-letter queue per stream
**Tech stack:** Python 3.11, ARQ, redis-py async, FFmpeg, Pillow, OpenSearch client, structlog, OpenTelemetry SDK

### Frontend (Angular)

Angular 17 standalone-component SPA that renders timelines, profiles, threaded replies, DMs, notifications, search/trending, and community views; all I/O is Zod-validated and all client state lives in NgRx signalStores mutated only through patchState.

**Patterns:** Standalone components only — no NgModule declarations, Signal-first state via NgRx signalStore; mutate exclusively through patchState inside withMethods, Lazy-loaded feature shells via loadComponent or loadChildren, Route guards for authenticated and staff areas, Strict runtime schema validation with Zod on every HTTP and WebSocket payload
**Tech stack:** Angular 17 (standalone components, control flow syntax), PrimeNG 17 (Aura preset), NgRx 17 Signals signalStore, Zod 3 (runtime schema validation), Vitest plus Angular Testing Library, Native WebSocket for live notifications and DMs

### Shared Contracts

Schemas, types, and event catalogs shared between the backend, workers, and the frontend. Single source of truth written in Zod, mirrored in Pydantic, and exposed as TypeScript types, OpenAPI 3.1, and AsyncAPI 2 artefacts.

**Patterns:** Single source of truth per contract (Zod root, Pydantic generated), Generated TypeScript types via z.infer, Versioned event names with semantic suffixes (.v1, .v2), Codegen-on-CI with committed artefacts, Contract-first API design
**Tech stack:** Zod 3 (TypeScript), Pydantic v2 (Python), OpenAPI 3.1, AsyncAPI 2, openapi-typescript codegen

### Infrastructure

Containerised runtime, IaC, observability, and CI/CD for the whole Microblog Platform stack including media storage, search, WebSocket fan-out, and trending signals.

**Patterns:** 12-factor configuration via environment variables, OpenTelemetry traces and metrics on every request, worker job, and WebSocket frame, Migrations run as a separate one-shot job, not on app start, GitOps via Argo CD with image-digest pinning, Media uploads use pre-signed S3 URLs to keep the API stateless, Infrastructure is immutable: every change goes through git, plan, and apply
**Tech stack:** Terraform 1.6, Kubernetes (EKS 1.29), PostgreSQL 16 (RDS), Redis 7 (ElastiCache), OpenSearch 2 (search and trending), S3 + CloudFront (media bucket and CDN), OpenTelemetry + Prometheus + Grafana, GitHub Actions + Argo CD

## Document Index

| Section | File |
|---|---|
| Feature Spec | [spec.md](spec.md) |
| Implementation Plan | [plan.md](plan.md) |
| Data Model | [data-model.md](data-model.md) |
| Contracts | [contracts/](contracts/) |
| Quickstart | [quickstart.md](quickstart.md) |
| Tasks | [tasks.md](tasks.md) |
| System Overview | [docs/00-system/overview.md](docs/00-system/overview.md) |
| Bounded Context Map | [docs/00-system/bounded-context-map.md](docs/00-system/bounded-context-map.md) |
| Architecture Overview | [docs/10-architecture/overview.md](docs/10-architecture/overview.md) |
| Backend (Python) Architecture | [docs/10-architecture/backend-architecture.md](docs/10-architecture/backend-architecture.md) |
| Backend Workers Architecture | [docs/10-architecture/backend-workers-architecture.md](docs/10-architecture/backend-workers-architecture.md) |
| Frontend (Angular) Architecture | [docs/10-architecture/frontend-architecture.md](docs/10-architecture/frontend-architecture.md) |
| Shared Contracts Architecture | [docs/10-architecture/shared-architecture.md](docs/10-architecture/shared-architecture.md) |
| Infrastructure Architecture | [docs/10-architecture/infra-architecture.md](docs/10-architecture/infra-architecture.md) |
| Backend (Python) Contracts | [contracts/backend.md](contracts/backend.md) |
| Backend Workers Contracts | [contracts/backend-workers.md](contracts/backend-workers.md) |
| Frontend (Angular) Contracts | [contracts/frontend.md](contracts/frontend.md) |
| Shared Contracts Contracts | [contracts/shared.md](contracts/shared.md) |
| Infrastructure Contracts | [contracts/infra.md](contracts/infra.md) |
