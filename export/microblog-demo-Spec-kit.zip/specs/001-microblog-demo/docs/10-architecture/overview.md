# Architecture Overview

## Design Principles

- **Domain-Driven Design (DDD):** Bounded contexts align code ownership with business domains.
- **Clean Architecture:** Dependencies point inward; domain layer has zero external dependencies.
- **Test-Driven Development (TDD):** Each component ships with BDD-style Given/When/Then specifications.

## Layers

| Layer | Responsibility | Pattern |
|---|---|---|
| Backend (Python) | FastAPI service exposing REST and WebSocket APIs for the public reader, the personal feed, and the staff moderation console, backed by PostgreSQL, Redis, S3-compatible object storage, and OpenSearch. | Domain-Driven Design (aggregates, bounded contexts), Clean Architecture (domain, application, infrastructure, interfaces), Outbox pattern for reliable domain events, Repository pattern with async sessions and Unit of Work, Hexagonal ports and adapters |
| Backend Workers | ARQ-based worker processes for fan-out, notifications, search indexing, media transcoding, and DM delivery. Workers consume domain events from Redis Streams, deduplicate by event id, and write back to PostgreSQL, Redis, S3, OpenSearch, or the realtime push gateway. | Idempotent consumers keyed by event id, Stream consumer groups with backoff, Batch processing per chunk, Coalescing for fan-out notifications, Outbox-driven publishing to streams, Dead-letter queue per stream |
| Frontend (Angular) | Angular 17 standalone-component SPA that renders timelines, profiles, threaded replies, DMs, notifications, search/trending, and community views; all I/O is Zod-validated and all client state lives in NgRx signalStores mutated only through patchState. | Standalone components only — no NgModule declarations, Signal-first state via NgRx signalStore; mutate exclusively through patchState inside withMethods, Lazy-loaded feature shells via loadComponent or loadChildren, Route guards for authenticated and staff areas, Strict runtime schema validation with Zod on every HTTP and WebSocket payload |
| Shared Contracts | Schemas, types, and event catalogs shared between the backend, workers, and the frontend. Single source of truth written in Zod, mirrored in Pydantic, and exposed as TypeScript types, OpenAPI 3.1, and AsyncAPI 2 artefacts. | Single source of truth per contract (Zod root, Pydantic generated), Generated TypeScript types via z.infer, Versioned event names with semantic suffixes (.v1, .v2), Codegen-on-CI with committed artefacts, Contract-first API design |
| Infrastructure | Containerised runtime, IaC, observability, and CI/CD for the whole Microblog Platform stack including media storage, search, WebSocket fan-out, and trending signals. | 12-factor configuration via environment variables, OpenTelemetry traces and metrics on every request, worker job, and WebSocket frame, Migrations run as a separate one-shot job, not on app start, GitOps via Argo CD with image-digest pinning, Media uploads use pre-signed S3 URLs to keep the API stateless, Infrastructure is immutable: every change goes through git, plan, and apply |

## ADR Index

- [ADR-0001 — Fan-out on write for home timelines](../20-decisions/adr-001-fan-out-on-write-for-home-timelines.md) *(accepted)*
- [ADR-0002 — PostgreSQL plus Redis for the primary store](../20-decisions/adr-002-postgresql-plus-redis-for-the-primary-store.md) *(accepted)*
- [ADR-0003 — OpenSearch for full-text and trending](../20-decisions/adr-003-opensearch-for-full-text-and-trending.md) *(accepted)*
- [ADR-0004 — S3-compatible object storage plus CDN for media](../20-decisions/adr-004-s3-compatible-object-storage-plus-cdn-for-media.md) *(accepted)*
- [ADR-0005 — NgRx signalStore for frontend state](../20-decisions/adr-005-ngrx-signalstore-for-frontend-state.md) *(accepted)*
- [ADR-0006 — Zod schemas shared between frontend and backend](../20-decisions/adr-006-zod-schemas-shared-between-frontend-and-backend.md) *(accepted)*
