# Infrastructure Architecture

**Layer ID**: `infra` · **Spec**: docs/10-architecture/infra-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

Containerised runtime, IaC, observability, and CI/CD for the Microblog Platform. Local development runs the full dependency graph via docker compose; production runs on EKS managed by Argo CD with image digests pinned to the commit SHA. Media is served from S3 behind CloudFront via pre-signed URLs, search and trending run on OpenSearch, and WebSocket fan-out plus caches run on Redis. Every request, worker job, and WebSocket frame emits OpenTelemetry traces plus metrics to a central collector, and migrations run as a separate one-shot job, not on app start.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | GitHub Actions cache + ECR (tagged by digest) + S3 media bucket (versioned, lifecycle to Glacier) |
| **Target Platform** | Linux containers (amd64 plus arm64) on Kubernetes 1.29 |
| **Performance Goals** | CI build under 12 minutes; production deploy under 5 minutes; image pull under 30 seconds on a warm cluster; p95 feed read under 200ms |
| **Constraints** | Pin base image digests, not tags. Migrations run as a separate one-shot job, not on app start. Every alert links to a runbook. Media uploads use pre-signed S3 URLs. Sidecars bind to 127.0.0.1 only. |
| **Scale / Scope** | 3 environments (dev, staging, prod), ~80 services, ~20TB PostgreSQL, ~50TB S3, ~10M daily active users |

## Constitution Check

- ✅ All images pinned by digest, not tag
- ✅ Migrations run as a separate one-shot job, not on app start
- ✅ OpenTelemetry traces and metrics exported on every request, worker job, and WebSocket frame
- ✅ Every Prometheus alert links to a runbook in docs/runbooks/
- ✅ CI fails on any uncommitted generated artefact (OpenAPI, TS types, Terraform plan)
- ✅ Sidecars bind to 127.0.0.1 only; multi-tenant access is enforced at the listen address

## Project Structure

### Documentation (this layer)

```text
docs/70-infra/
```

### Source Code

```text
infra/
├── terraform/
│   ├── modules/
│   │   ├── vpc/
│   │   ├── eks/
│   │   ├── rds/
│   │   ├── elasticache/
│   │   ├── opensearch/
│   │   ├── s3-media/
│   │   └── cloudfront/
│   └── envs/
│       ├── dev/
│       ├── staging/
│       └── prod/
├── deploy/
│   ├── backend/
│   ├── workers/
│   ├── frontend/
│   └── realtime/
├── observability/
│   ├── otel-collector-values.yaml
│   ├── prometheus-rules.yaml
│   └── grafana/dashboards/
├── ci/
│   ├── backend-pipeline.yml
│   ├── frontend-pipeline.yml
│   ├── workers-pipeline.yml
│   ├── realtime-pipeline.yml
│   ├── infra-plan-pipeline.yml
│   └── e2e-pipeline.yml
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| OpenTelemetry collector plus Prometheus plus Grafana stack | Single pane of glass across FastAPI, Angular SPA, ARQ workers, and WebSocket gateway | Vendor-specific APM (NewRelic or Datadog) - high cost and lock-in for a single-team project |
| Image digests instead of mutable tags | Reproducible rollbacks and zero ambiguity between what is in staging and what is in prod | latest or version tags - caused a known incident on a previous project where a base image was re-tagged mid-deploy |
| Separate OpenSearch cluster for search and trending | Full-text search on posts, hashtag trending, and user handle lookup at p95 under 200ms; PostgreSQL GIN is not [TODO: measure] enough at this scale | PostgreSQL full-text search only - acceptable at small scale but does not meet the 10M DAU NFR |
