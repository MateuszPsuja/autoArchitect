# Shared Contracts Architecture

**Layer ID**: `shared` · **Spec**: docs/10-architecture/shared-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

Single source of truth for every API request, response, and domain event that crosses the backend, workers, and frontend boundary. Schemas are written once in Zod (frontend) and mirrored in Pydantic (backend); TypeScript types are generated via z.infer, and the OpenAPI 3.1 and AsyncAPI 2 specs are codegen output committed to the repo. Domain events are versioned with a .vN suffix that bumps on breaking payload changes.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | Repo-committed Zod sources + codegen artefacts (Pydantic models, openapi.yaml, asyncapi.yaml); no runtime database |
| **Target Platform** | Node 20 + Python 3.11 codegen runners on CI; artefacts consumed by web SPA and FastAPI backend |
| **Performance Goals** | Full codegen completes in under 30 seconds on CI; schema validation on the client adds under 1 ms per request |
| **Constraints** | No hand-written TypeScript request or response types; every type is z.infer. No breaking changes without a .vN+1 suffix on the event name. openapi.yaml and asyncapi.yaml must be regenerated and committed in the same PR as any schema change. |
| **Scale / Scope** | ~80 Zod schemas, ~30 AsyncAPI events across 12 bounded contexts (posts, engagement, identity, dm, communities, search, trends, media, moderation, notifications, feeds, billing) |

## Constitution Check

- ✅ Zod schema is the source of truth; TypeScript types and Pydantic models are generated, never handwritten
- ✅ Every domain event is declared in the AsyncAPI catalogue with a versioned name (.vN)
- ✅ OpenAPI 3.1 spec is regenerated on every CI run and committed to the repo
- ✅ Breaking payload changes require a new .vN+1 suffix on the event name and a deprecation window
- ✅ Schemas live in shared/schemas and are imported by both backend and frontend through the codegen artefacts
- ✅ codegen drift (committed artefact != generated artefact) fails CI on both backend and frontend

## Project Structure

### Documentation (this layer)

```text
docs/60-shared/
```

### Source Code

```text
```text
shared/
├── schemas/
│   ├── posts.ts              # Zod root for post payloads
│   ├── engagement.ts         # like/repost/bookmark commands
│   ├── identity.ts           # UserSummary and Session
│   ├── dm.ts                 # DmMessage and Conversation
│   ├── communities.ts        # Community membership and roles
│   ├── search.ts             # Search query and hit
│   ├── trends.ts             # Trending topic and rank
│   ├── media.ts              # MediaAttachment metadata
│   ├── moderation.ts         # Report and moderation action
│   ├── notifications.ts      # Notification envelope
│   ├── feeds.ts              # FeedItem and FeedCursor
│   ├── events.ts             # AsyncAPI-aligned event schemas
│   └── pagination.ts         # Page<T> and Cursor
├── python/
│   ├── posts.py              # Pydantic mirror of posts.ts
│   ├── engagement.py
│   ├── identity.py
│   ├── dm.py
│   ├── communities.py
│   ├── search.py
│   ├── trends.py
│   ├── media.py
│   ├── moderation.py
│   ├── notifications.py
│   ├── feeds.py
│   └── events.py
├── codegen/
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| Maintaining schema parity across Zod, Pydantic, OpenAPI, and AsyncAPI | Lets the backend and frontend evolve independently without silent contract drift; a single root schema fans out to every consumer format | Hand-written Pydantic models and hand-written TypeScript types — drifts within weeks and produces runtime schema errors in the SPA |
| Versioned event names with .vN suffix instead of in-payload version fields | Lets brokers and consumers filter on the topic name so old and new payloads can coexist during rollout and rollback | Single unversioned event name with an in-payload version field — couples consumer decoding logic to every producer and blocks clean rollback |
