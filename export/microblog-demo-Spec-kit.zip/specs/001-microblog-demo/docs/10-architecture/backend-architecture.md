# Backend (Python) Architecture

**Layer ID**: `backend` · **Spec**: docs/10-architecture/backend-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

FastAPI service that owns the publish, reply, engagement, and social-graph bounded contexts behind REST and WebSocket APIs. Follows Clean Architecture (domain, application, infrastructure, interfaces) with DDD aggregates per context, an outbox table for reliable domain events, and ARQ workers that fan out timelines and notifications.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | PostgreSQL 16 via SQLAlchemy 2 async; Redis 7 for hot caches and timeline fan-out; S3-compatible object storage for media; OpenSearch 2 for search and trending |
| **Target Platform** | Linux server (Python 3.11) containerised via Docker; deployed behind a reverse proxy with TLS termination |
| **Performance Goals** | p95 GET home timeline under 200ms; p95 POST post under 400ms; fan-out worker sustains 50k posts per minute at peak |
| **Constraints** | Domain layer MUST have zero framework imports; every status transition MUST be idempotent and emit exactly one domain event via the outbox; all authorization checks MUST live in the application layer, never in routes |
| **Scale / Scope** | 1M MAU readers, 50k posts per minute at peak, 200 RPS on read endpoints, 50 RPS on write endpoints |

## Constitution Check

- ✅ Strict type checking on every Pydantic schema (extra=forbid) and mypy --strict on the application layer
- ✅ At least 2 unit tests plus 1 integration test per use case, with the domain layer tested without I/O
- ✅ Domain layer has zero framework imports (no FastAPI, SQLAlchemy, Redis, boto3, or OpenSearch client)
- ✅ Outbox pattern is used for every domain event; no synchronous cross-context calls from request handlers
- ✅ All authorization checks live in the application layer; routes never short-circuit policy decisions
- ✅ Background work runs only in ARQ workers; the web process never executes long jobs inline

## Project Structure

### Documentation (this layer)

```text
docs/30-backend/
docs/30-backend/identity/
docs/30-backend/identity/overview.md
docs/30-backend/identity/domain/aggregates.md
docs/30-backend/identity/domain/domain-services.md
docs/30-backend/identity/application/use-cases.md
docs/30-backend/identity/infrastructure/repositories.md
docs/30-backend/posts/
docs/30-backend/posts/overview.md
docs/30-backend/posts/domain/aggregates.md
docs/30-backend/posts/domain/domain-services.md
docs/30-backend/posts/application/use-cases.md
docs/30-backend/posts/infrastructure/repositories.md
docs/30-backend/engagement/
docs/30-backend/engagement/overview.md
docs/30-backend/engagement/domain/aggregates.md
docs/30-backend/engagement/domain/domain-services.md
docs/30-backend/engagement/application/use-cases.md
docs/30-backend/engagement/infrastructure/repositories.md
docs/30-backend/media/
docs/30-backend/media/overview.md
docs/30-backend/media/domain/aggregates.md
docs/30-backend/media/domain/domain-services.md
docs/30-backend/media/application/use-cases.md
docs/30-backend/media/infrastructure/repositories.md
docs/30-backend/search/
docs/30-backend/search/overview.md
docs/30-backend/search/domain/aggregates.md
docs/30-backend/search/domain/domain-services.md
docs/30-backend/search/application/use-cases.md
docs/30-backend/search/infrastructure/repositories.md
docs/30-backend/notifications/
docs/30-backend/notifications/overview.md
docs/30-backend/notifications/components.md
docs/30-backend/notifications/services.md
docs/30-backend/notifications/state.md
```

### Source Code

```text
backend/
├── pyproject.toml
├── alembic.ini
├── Dockerfile
├── src/
│   ├── main.py                       # FastAPI composition root
│   ├── app.py                        # create_app with middleware and routers
│   ├── config.py                     # pydantic-settings
│   ├── observability.py              # OpenTelemetry + structlog init
│   ├── shared/
│   │   ├── events.py                 # typed domain event catalog
│   │   ├── exceptions.py
│   │   ├── middleware.py
│   │   └── types.py
│   ├── identity/
│   │   ├── domain/user_account.py
│   │   └── application/use_cases/authenticate.py
│   ├── posts/
│   │   ├── domain/aggregates/post.py
│   │   ├── application/use_cases/publish_post.py
│   │   ├── infrastructure/repositories/postgres_post_repository.py
│   │   └── interfaces/routes.py
│   ├── engagement/
│   │   ├── domain/aggregates/like.py
│   │   ├── application/use_cases/record_engagement.py
│   │   └── infrastructure/repositories/engagement_repository.py
│   ├── social_graph/
│   │   ├── domain/aggregates/follow_edge.py
│   │   ├── application/use_cases/follow.py
│   │   └── infrastructure/repositories/social_graph_repository.py
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| Outbox table for domain events | Guarantees at-least-once delivery to ARQ workers without dual-write inconsistencies between PostgreSQL and Redis | Direct synchronous call from request handler to worker - would lose events on partial failure and tightly couples the web process to the worker runtime |
| Repository pattern plus Unit of Work per request | Keeps the use-case layer testable without SQLAlchemy sessions and isolates the aggregate from persistence concerns | Use cases calling SQLAlchemy sessions directly - couples domain logic to a specific ORM and makes unit tests slow or flaky |

## Domain Areas

| Domain | Layer | Description |
|---|---|---|
| [Identity and Access](../30-backend/identity/overview.md) | backend | Manages user identity lifecycle, authentication credentials, profile attributes, and account state for the microblog platform. Acts as the trusted source of identity used by every other bounded context. |
| [Posts and Threads](../30-backend/posts/overview.md) | backend | Bounded context that owns the lifecycle of user-authored short posts and threaded replies, including edits, deletions, and media attachments up to 280 characters. |
| [Engagement](../30-backend/engagement/overview.md) | backend | Tracks user interactions (likes, reposts, bookmarks) on posts, enforces single-action invariants, exposes engagement counters, and publishes engagement events to the feed, posts, and notifications contexts. |
| [Media](../30-backend/media/overview.md) | backend | Manages user-uploaded media assets (images and short videos) including upload lifecycle, asynchronous processing, derivative generation, CDN delivery, attachment linkage, and quota enforcement. |
| [Search and Trending](../30-backend/search/overview.md) | backend | Public full-text search over posts, hashtags, and users plus rolling-window trending topic detection for the microblog platform. |
| [Notifications](../30-backend/notifications/overview.md) | backend | Aggregates, stores, and delivers real-time and historical notifications for users across in-app, push, email, and WebSocket channels, honoring per-user preferences and topic-level mutes. |
