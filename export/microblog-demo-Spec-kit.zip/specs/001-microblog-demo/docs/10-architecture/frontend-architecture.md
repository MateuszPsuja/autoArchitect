# Frontend (Angular) Architecture

**Layer ID**: `frontend` · **Spec**: docs/10-architecture/frontend-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

Angular 17 standalone-component SPA with lazy-loaded feature shells (Home, Profile, Thread, Explore, DMs, Notifications, Preferences, Staff) that consume a REST API and two WebSocket channels. All I/O is validated with Zod before reaching components, and all client state lives in NgRx signalStores mutated exclusively through patchState; authenticated and staff routes are protected by AuthGuard and StaffGuard.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | Browser memory only; no IndexedDB or localStorage; persistence happens via the backend and HttpOnly session cookies |
| **Target Platform** | Browser (Chrome 110+, Firefox 110+, Safari 16+, Edge 110+) on desktop and mobile viewports |
| **Performance Goals** | TTI under 3s on a cold cache; LCP under 2s on 4G; main-thread long tasks under 50ms; first feed paint under 1.5s |
| **Constraints** | No BehaviorSubject or ReplaySubject — use signals only. Mutate signalStore state only via patchState inside withMethods. All HTTP and WSS payloads must be Zod-validated before reaching components. No NgModules. |
| **Scale / Scope** | 1M MAU, 50k posts per minute, 10k signed-in DM sessions per day, ~100k concurrent WebSocket connections |

## Constitution Check

- ✅ Strict TypeScript with noImplicitAny and strictNullChecks
- ✅ Standalone components only — no NgModule declarations
- ✅ Mutate signalStore state only via patchState inside withMethods
- ✅ All HTTP and WSS payloads validated with a Zod schema before reaching components
- ✅ Lazy-load every top-level feature via loadComponent or loadChildren
- ✅ Route guards (AuthGuard, StaffGuard) wrap every protected route; no client-side trust of auth state
- ✅ Accessibility: WCAG 2.1 AA targets with PrimeNG ARIA primitives and keyboard-navigable timeline

## Project Structure

### Documentation (this layer)

```text
docs/50-frontend/
```

### Source Code

```text
```text
frontend/
├── angular.json
├── package.json
├── tsconfig.json
├── vitest.config.ts
└── src/
    ├── main.ts
    ├── index.html
    ├── styles.scss
    └── app/
        ├── app.ts                   # bootstrapApplication
        ├── app.config.ts            # router, http, interceptors
        ├── app.routes.ts            # top-level routes (lazy)
        ├── core/
        │   ├── api/                 # HttpClient wrappers
        │   ├── stores/              # NgRx signalStores
        │   ├── schemas/             # Zod schemas
        │   ├── guards/              # auth.guard, staff.guard
        │   └── interceptors/        # auth, error, trace
        ├── features/                # lazy feature shells
        ├── shared/                  # ui-kit, pipes, directives
        └── styles/                  # tokens, themes
```
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| NgRx signalStore for feature state (vs. plain service plus signals) | Standardises selectors, methods, and patchState boundaries so multiple components can subscribe without cross-feature coupling | Plain service exposing writable signals — would let any consumer mutate state and removes the audit boundary between read and write |
| Zod schema validation for every HTTP and WSS payload | Catches upstream contract drift at the seam where the SPA meets the backend instead of crashing a component at render time | Trust the typed response — leaves the SPA exposed to silent runtime errors when the backend ships a breaking change |
| Two WebSocket channels (notifications and DMs) with per-feature stores | Live feed and inbox updates must render without polling; per-feature stores keep reconnection and back-pressure isolated | Single shared WSS client with a global event bus — couples unrelated features and complicates back-pressure handling |
