# Join and Participate in a Community

User discovers a community, joins, and posts within it; community-scoped fan-out keeps timelines separated.

## Steps

1. Visitor browses the Communities directory and opens a community page.
2. Signed-in user clicks Join; membership is persisted and community.joined.v1 is emitted.
3. User opens the community composer; body and media are validated against community rules.
4. POST /api/posts with communityId persists the post scoped to the community.
5. Fan-out writes the post to community-member timelines only, not the global home feed.
6. Community moderators can pin or remove posts via the moderation tool.

## Domains Involved

- `communities`
- `posts`
- `moderation`
