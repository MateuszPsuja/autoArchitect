# Search and Trend

Search indexer ingests published posts; the trending calculator updates the explore page with half-life decay.

## Steps

1. Fan-out emits post.published.v1 and post.deleted.v1 to the search indexer stream.
2. Indexing queue buffers posts up to 500 items or 2 seconds.
3. Indexing queue flushes a bulk request to OpenSearch and retries with backoff on failure.
4. Trending calculator applies half-life decay to recent engagements per hashtag.
5. Explore page serves the top-N trending hashtags from the 60-second snapshot.

## Domains Involved

- `search`
- `posts`
