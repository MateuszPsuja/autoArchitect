# Upload and Process

Author attaches media (image or short video) to a post; the media worker produces CDN-served variants.

## Steps

1. Author attaches an image or short video in the composer.
2. Backend issues a presigned URL and records the upload in pending status.
3. Client uploads directly to the presigned URL and calls markUploaded.
4. Media worker transcodes into thumbnail, medium, and full variants.
5. Variants are uploaded to the object store and CDN URLs are returned.
6. The post publish flow attaches variants and emits post.published.v1.

## Domains Involved

- `media`
- `posts`
