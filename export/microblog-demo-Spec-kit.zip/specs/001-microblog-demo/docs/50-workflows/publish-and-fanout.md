# Publish and Fan-out

Author publishes a post; the fan-out worker materialises the post into follower timelines and indexes it for search.

## Steps

1. Author opens the composer and clicks Post.
2. POST /api/posts persists the post and writes an outbox event in the same transaction.
3. PubSub bus publishes post.published.v1 to the fan-out and search streams.
4. Fan-out dispatcher loads followers and writes per-user timeline rows in 500-row batches.
5. Timeline cache prepends the new post id to each follower cache and trims to 800 entries.
6. SPA home feed receives the new post on the next refresh or pull-to-refresh.

## Domains Involved

- `posts`
- `social-graph`
- `search`
