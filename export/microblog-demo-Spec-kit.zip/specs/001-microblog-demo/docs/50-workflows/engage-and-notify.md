# Engage and Notify

A like, reply, repost, or mention triggers an in-app notification and updates engagement counters atomically.

## Steps

1. Reader likes a post from the home feed or thread view.
2. POST /api/likes persists the like and writes engagement.recorded.v1.
3. Reply or repost persists the new post and emits reply.created.v1 or repost.created.v1.
4. Notification worker detects engagement events and creates a Notification aggregate.
5. Fan-out scheduler coalesces notifications and dispatches WSS push to the recipient.
6. The author sees the notification in the panel within 2 seconds.

## Domains Involved

- `engagement`
- `notifications`
- `posts`
