# Report and Enforce

Reader reports a post; a staff moderator triages and applies an enforcement action via the BlockList.

## Steps

1. Reader clicks Report on a post and submits a form with a reason.
2. POST /api/reports persists the report and emits report.created.v1.
3. Triage service assigns the report to the least-loaded moderator with capacity.
4. Staff reviews the report and applies an enforcement action via the BlockList (hide, soft-delete, suspend).
5. Backend persists the block and emits graph.blocked.v1 or post.hidden.v1.
6. The reported post is hidden from the reporter's timelines within 5 seconds.

## Domains Involved

- `social-graph`
- `posts`
- `moderation`
