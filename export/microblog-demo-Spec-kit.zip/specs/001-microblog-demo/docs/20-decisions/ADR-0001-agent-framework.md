# ADR-0001 — Agent Framework

**Status:** `accepted`

## Context

The plan needs a single, explicit decision about the agent framework so downstream tasks (`tasks.md`) can refer to it unambiguously.

## Decision

Chosen framework: **none**. The plan relies on deterministic retrieval via the chosen embedding model (FR-010) rather than an agent runtime.

## Consequences

- `tasks.md` retrieval tasks cite the framework explicitly (no LangChain drift).
- `langgraph` rejected — kept available as a fallback if FR-010 changes
