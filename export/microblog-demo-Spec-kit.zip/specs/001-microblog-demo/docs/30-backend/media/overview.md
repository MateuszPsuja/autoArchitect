# Media

Manages user-uploaded media assets (images and short videos) including upload lifecycle, asynchronous processing, derivative generation, CDN delivery, attachment linkage, and quota enforcement.

**Layer:** `backend`
**Directory:** `src/media`

## Responsibilities

- Coordinate resumable uploads of images and short videos to object storage
- Validate media metadata (type, size, dimensions) against platform rules
- Trigger and reconcile asynchronous processing (transcoding, thumbnails, safety scans)
- Issue short-lived CDN URLs and manage per-asset derivatives
- Enforce ownership, quota, and orphan-cleanup rules for media assets
- Expose lifecycle events consumed by Posts, Feed, and Moderation contexts
