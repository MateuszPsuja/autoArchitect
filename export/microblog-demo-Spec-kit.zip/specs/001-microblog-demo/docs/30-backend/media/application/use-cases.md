# Media — Application Use Cases

## MediaUploadUseCase

**Type:** `use-case` · **Layer:** `application` · **File:** `src/media/application/media_upload_use_case.py`

### Purpose

Application use case that orchestrates a resumable upload: validate, reserve storage, hand off to processor, persist final state.

### Responsibilities

- Coordinate domain validation with storage and processing collaborators
- Generate signed upload URLs and storage keys
- Persist final state and emit events after processor confirmation

### Public API

- `MediaUploadUseCase.initiate`
- `MediaUploadUseCase.complete`
- `MediaUploadUseCase.handleProcessorNotification`

### Inputs

- InitiateUploadInput
- CompleteUploadInput
- MediaReadyNotification
- MediaFailedNotification

### Outputs

- UploadSession
- MediaUploadResult
- MediaAcknowledgment

### Dependencies

- MediaAsset (domain aggregate)
- MediaRepository
- MediaStoragePort
- MediaProcessorPort
- UnitOfWork

### Error Handling

Wraps domain errors as UploadRejected; translates storage errors into StorageUnavailable; idempotent retries on processor notifications keyed by uploadId.

### Acceptance Criteria

- [ ] Initiate returns an upload session with a signed URL and reserved key
- [ ] Complete fails [TODO: measure] with UploadRejected when MediaAsset validation fails
- [ ] Processor notification with idempotency key is applied exactly once
- [ ] Successful notification persists Ready state and emits MediaReady

### Out of Scope

- Choice of object storage provider
- Generating actual transcoded derivatives
- User-facing HTTP transport

### Test Specifications

#### Unit Tests

**Test: Initiate returns signed URL and reserves storage key**

- Given: valid request
- Given: fake storage adapter
- When: initiate is called
- Then: returns session with URL
- Then: calls storage.reserve once

**Test: Complete rejects unsupported MIME types via domain error**

- Given: CompleteUploadInput with mime = application/zip
- When: complete is invoked
- Then: raises UploadRejected
- Then: no asset is persisted

**Test: Duplicate processor notification is idempotent**

- Given: an asset already in Ready state
- Given: redelivered notification
- When: handleProcessorNotification is invoked again
- Then: no additional event emitted
- Then: asset state unchanged

#### Integration Tests

**Test: Full upload lifecycle persists asset and publishes events**

- Given: fake storage, fake processor, in-memory repository
- When: initiate, complete, and notify success run sequentially
- Then: asset stored in Ready state
- Then: MediaReady event recorded once

---
