# Media — Infrastructure

## MediaStorageRepository

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/media/infrastructure/media_storage_repository.py`

### Purpose

Infrastructure repository implementing MediaRepository and MediaStoragePort against the chosen object store and database.

### Responsibilities

- Persist and load MediaAsset aggregates
- Reserve, fetch, and delete objects in object storage
- Generate signed upload and short-lived CDN delivery URLs

### Public API

- `MediaStorageRepository.save`
- `MediaStorageRepository.find`
- `MediaStorageRepository.reserve`
- `MediaStorageRepository.issueCdnUrl`
- `MediaStorageRepository.deleteObject`

### Inputs

- MediaAsset
- StorageReservationRequest
- ObjectKey
- Checksum

### Outputs

- MediaAsset (loaded)
- UploadTicket
- CdnUrl
- StorageMetadata

### Dependencies

- SQLAlchemy session
- S3-compatible client
- Domain entities and value objects

### Error Handling

Translates client exceptions to NotFound, StorageUnavailable, or IntegrityViolation; never silently drops writes (logs and surfaces errors).

### Acceptance Criteria

- [ ] save and find round-trip preserves all fields and version
- [ ] reserve returns a unique immutable key per request
- [ ] issueCdnUrl produces short-lived HTTPS URLs for derived variants
- [ ] deleteObject removes underlying bytes and writes a metadata tombstone

### Out of Scope

- Database schema migrations
- CDN edge policy configuration
- Processing pipeline implementation

### Test Specifications

#### Unit Tests

**Test: save then find returns the same aggregate snapshot**

- Given: a fresh MediaAsset
- Given: fake object store + SQL session
- When: save followed by find by id
- Then: fields match
- Then: version is unchanged

**Test: reserve yields unique keys under concurrent calls**

- Given: 100 concurrent reserve requests via threads
- When: all reserve calls complete
- Then: all returned keys are distinct
- Then: no key collisions

**Test: issueCdnUrl returns HTTPS URL with short TTL**

- Given: a Ready MediaAsset with derived variants
- When: issueCdnUrl is called for variant = 'thumb'
- Then: URL starts with https://
- Then: TTL <= 15 minutes

#### Integration Tests

**Test: End-to-end persistence via test database and fake S3**

- Given: Postgres test container
- Given: Moto-backed fake S3
- When: save -> issueCdnUrl -> deleteObject flow runs
- Then: DB row persists
- Then: object gone from S3 after delete

---

## MediaProcessorWebhookController

**Type:** `controller` · **Layer:** `infrastructure` · **File:** `src/media/infrastructure/media_processor_webhook.py`

### Purpose

Infrastructure controller receiving asynchronous success/failure notifications from the media pipeline and reconciling them with persisted assets.

### Responsibilities

- Validate HMAC-signed webhook payloads from the media processor
- Translate success/failure into domain commands via the use case
- Return idempotent acknowledgments and structured errors

### Public API

- `MediaProcessorWebhookController.handle_success`
- `MediaProcessorWebhookController.handle_failure`
- `MediaProcessorWebhookController.health`

### Inputs

- WebhookHeaders
- ProcessingSuccessPayload
- ProcessingFailurePayload

### Outputs

- HttpAck
- DomainCommandEnvelope
- RetryHint

### Dependencies

- MediaUploadUseCase
- Signature verifier
- Event publisher
- Structured logger

### Error Handling

Returns 401 for invalid signatures, 404 for unknown mediaId, 409 for state conflicts, 202 for accepted retries; never leaks internal errors.

### Acceptance Criteria

- [ ] Rejects requests with bad HMAC signature returning 401
- [ ] Applies success command idempotently to existing Ready assets
- [ ] Marks unknown mediaId as 404 and does not mutate state
- [ ] Logs correlation id on every handled request

### Out of Scope

- Choosing the processor implementation
- Long-polling or websocket fan-out
- Authentication of human callers

### Test Specifications

#### Unit Tests

**Test: Invalid HMAC signature is rejected with 401**

- Given: a forged webhook payload
- When: handle_success receives the payload
- Then: responds 401
- Then: no command dispatched to use case

**Test: Valid success payload dispatches MarkReady once**

- Given: valid signature
- Given: Processing asset in memory
- When: handle_success runs
- Then: MarkReady invoked once
- Then: responds 200

**Test: Unknown mediaId returns 404 without state change**

- Given: valid signature
- Given: mediaId = missing
- When: handle_failure runs
- Then: responds 404
- Then: use case not invoked

#### Integration Tests

**Test: End-to-end webhook flow publishes MediaReady to the bus**

- Given: real use case, fake processor, in-memory bus
- When: POST with valid signed success arrives
- Then: MediaReady delivered to bus
- Then: asset persisted as Ready

---
