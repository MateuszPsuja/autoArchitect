# Media — Aggregates & Domain Events

## MediaAsset

A single uploaded media asset tracked from upload initiation through processing, attachment, and eventual deletion, with ownership and quota invariants.

**Root Entity:** `MediaFile`

### Invariants
- File size must not exceed the per-type limit (e.g. 5 MB image, 40 MB video)
- MIME type must belong to the platform whitelist; unsupported uploads are rejected
- An asset cannot transition backwards out of Deleted or out of Failed
- Storage key is immutable once CompleteUpload succeeds; only derived URLs change

### Value Objects
- `MediaType`
- `MediaDimensions`
- `MediaChecksum`
- `StorageLocation`

### Commands
- `InitiateUpload`
- `CompleteUpload`
- `MarkProcessing`
- `MarkReady`
- `MarkFailed`
- `Delete`

### Domain Events Emitted
- `MediaUploadCompleted`
- `MediaReady`
- `MediaProcessingFailed`
- `MediaDeleted`

## MediaAttachment

The linkage between a Ready MediaAsset and the post that references it, tracking role and ordering within a post body.

**Root Entity:** `MediaAttachment`

### Invariants
- A post may reference at most N media attachments (e.g. 4)
- An attachment cannot exist without a referenced MediaAsset in Ready state
- Attachments are scoped to a single post; cross-post reuse is forbidden
- Detaching an attachment without deleting the asset preserves the asset

### Value Objects
- `AttachmentRole`
- `AltText`

### Commands
- `AttachMedia`
- `ReorderAttachments`
- `DetachMedia`

### Domain Events Emitted
- `MediaAttachedToPost`
- `MediaDetachedFromPost`

## Domain Events Catalog

### MediaReady

Published when an asset finishes transcoding and scanning and is available for delivery.

**Triggered by:** MediaAsset.MarkReady
**Handled by:** posts, feed, moderation

**Payload:**
- `mediaId`
- `ownerId`
- `mediaType`
- `derivedVariants`
- `checksum`

### MediaProcessingFailed

Published when asynchronous processing cannot produce a deliverable asset.

**Triggered by:** MediaAsset.MarkFailed
**Handled by:** posts, moderation

**Payload:**
- `mediaId`
- `ownerId`
- `reasonCode`

### MediaAttachedToPost

Published when a Ready media asset is linked to a post.

**Triggered by:** MediaAttachment.AttachMedia
**Handled by:** posts, feed

**Payload:**
- `postId`
- `mediaId`
- `role`

### MediaDeleted

Published when a media asset is purged from storage after grace period.

**Triggered by:** MediaAsset.Delete
**Handled by:** posts, feed, moderation

**Payload:**
- `mediaId`
- `ownerId`
- `deletedBy`
