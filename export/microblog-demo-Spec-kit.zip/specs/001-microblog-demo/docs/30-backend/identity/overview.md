# Identity and Access

Manages user identity lifecycle, authentication credentials, profile attributes, and account state for the microblog platform. Acts as the trusted source of identity used by every other bounded context.

**Layer:** `backend`
**Directory:** `src/identity`

## Responsibilities

- Register new user accounts with unique username, email, and hashed credentials
- Authenticate users via password verification and issue short-lived access tokens
- Maintain and validate user profile attributes such as display name, bio, and avatar URL
- Handle account verification, password reset requests, and account deactivation flows
- Expose a stable repository contract so other bounded contexts can look up users by id or handle
