# Identity and Access — Infrastructure

## UserAccount Repository

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/identity/infrastructure/user-account.repository.ts`

### Purpose

Persistence port and adapter for UserAccount aggregates, exposing lookups by id, username, and email.

### Responsibilities

- Persist and rehydrate UserAccount aggregates transactionally
- Enforce unique indexes on username and email at the storage layer
- Emit stored domain events to an outbox after a successful save

### Public API

- `save`
- `findById`
- `findByUsername`
- `findByEmail`

### Inputs

- UserAccount
- userId
- username
- email

### Outputs

- UserAccount
- null
- DomainError

### Dependencies

- PostgresConnection
- OutboxWriter

### Error Handling

Unique-constraint violations are translated into UsernameAlreadyTaken or EmailAlreadyRegistered; connection failures bubble up as InfrastructureError.

### Acceptance Criteria

- [ ] save persists the aggregate and writes pending events to the outbox in the same transaction
- [ ] findById returns null (not throws) for unknown ids
- [ ] Concurrent registrations with the same username yield exactly one success and one UsernameAlreadyTaken
- [ ] findByUsername and findByEmail are case-insensitive and indexed for [TODO: measure] lookup

### Out of Scope

- Caching layer, added later by a decorator
- Search-index updates, owned by the search context
- Profile media upload, owned by the media context

### Test Specifications

#### Unit Tests

**Test: save translates a unique-constraint collision into UsernameAlreadyTaken**

- Given: a Postgres stub raising a unique violation on username
- When: save is invoked with a new UserAccount using a taken username
- Then: UsernameAlreadyTaken is returned
- Then: no partial row is committed

**Test: findByUsername is case-insensitive and preserves original casing**

- Given: a stored account with username JohnDoe
- When: findByUsername is called with 'johndoe'
- Then: the stored UserAccount is returned with original casing preserved

#### Integration Tests

**Test: save writes domain events to the outbox within the same transaction**

- Given: a fresh database with the outbox table empty
- When: save is called after issuing a UserRegistered event
- Then: exactly one outbox row exists with event_type UserRegistered
- Then: rolling back the transaction removes both the row and the outbox entry

---
