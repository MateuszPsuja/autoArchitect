# Identity and Access — Application Use Cases

## Register Account Use Case

**Type:** `use-case` · **Layer:** `application` · **File:** `src/identity/application/register-account.use-case.ts`

### Purpose

Application-layer orchestration for new account creation: validates input, hashes the password, calls the aggregate, persists, and triggers verification email delivery.

### Responsibilities

- Validate and normalize incoming registration payloads
- Hash the password before constructing the aggregate
- Coordinate the aggregate, repository, and verification-email publisher

### Public API

- `execute`

### Inputs

- RegistrationRequest
- ipAddress
- userAgent

### Outputs

- UserAccount
- DomainError

### Dependencies

- UserAccountRepository
- PasswordHasher
- EmailPublisher
- UserAccountFactory

### Error Handling

All failures (invalid email format, weak password, duplicate handle) bubble as typed DomainError; partial state is impossible because the aggregate is only persisted after all validations pass.

### Acceptance Criteria

- [ ] execute accepts a valid RegistrationRequest and returns the persisted UserAccount
- [ ] execute rejects passwords failing the platform strength policy with WeakPassword
- [ ] The plaintext password never leaves this use case; only its hash is stored
- [ ] On success a UserRegistered event is enqueued and a verification email is dispatched
- [ ] Calling execute twice with the same email returns EmailAlreadyRegistered without side effects the second time

### Out of Scope

- Password strength policy definition, owned by a settings module
- Captcha and bot protection at the edge
- GDPR deletion requests

### Test Specifications

#### Unit Tests

**Test: execute hashes the password before persisting via the repository**

- Given: a valid RegistrationRequest and a hasher spy
- When: execute is invoked
- Then: the hasher was called exactly once with the plaintext password
- Then: the repository received an aggregate whose hash differs from the plaintext

**Test: execute rejects weak passwords without calling the repository or hasher**

- Given: a RegistrationRequest with a too-short password
- When: execute is invoked
- Then: WeakPassword is returned
- Then: neither the hasher nor the repository is invoked

**Test: duplicate email produces EmailAlreadyRegistered and no email is sent**

- Given: a repository stub that throws EmailAlreadyRegistered on save
- When: execute is called for a registration with a known email
- Then: EmailAlreadyRegistered is returned
- Then: no verification email is dispatched

#### Integration Tests

**Test: successful execute persists the account, enqueues event, and queues email**

- Given: empty database and a stubbed email publisher
- When: execute is called with a fully valid RegistrationRequest
- Then: one user row exists in the database
- Then: one UserRegistered event is in the outbox
- Then: the email publisher received exactly one verification message

---
