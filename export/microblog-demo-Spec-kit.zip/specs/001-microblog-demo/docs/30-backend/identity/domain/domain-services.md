# Identity and Access — Domain Services

## Authentication Service

**Type:** `domain-service` · **Layer:** `domain` · **File:** `src/identity/domain/authentication.service.ts`

### Purpose

Domain service that verifies passwords against stored hashes and mints short-lived bearer tokens for use across the platform.

### Responsibilities

- Compare a presented password to the stored hash using constant-time comparison
- Issue a signed bearer token carrying the userId and sessionId
- Reject authentication for deactivated accounts

### Public API

- `authenticate`
- `verifyToken`
- `revokeToken`

### Inputs

- userId
- presentedPassword
- clockNow

### Outputs

- AuthToken
- AuthenticationResult
- DomainError

### Dependencies

- UserAccountRepository
- PasswordHasher

### Error Handling

Failures return typed errors (InvalidCredentials, AccountInactive, TokenInvalid) rather than throwing generic exceptions; never leak whether the username exists.

### Acceptance Criteria

- [ ] Authentication with the correct password returns a signed token whose payload contains userId
- [ ] Authentication with the wrong password returns InvalidCredentials and reveals no account existence
- [ ] Deactivated accounts always fail authentication regardless of password correctness
- [ ] Tokens have an expiry no longer than 15 minutes and are verifiable by verifyToken
- [ ] verifyToken rejects tokens signed with a different secret or past their expiry

### Out of Scope

- Persistence of refresh tokens
- OAuth and third-party identity providers
- Rate limiting of login attempts at the edge

### Test Specifications

#### Unit Tests

**Test: authenticate returns AuthToken when the password matches the stored hash**

- Given: a repository stub returning an active account
- Given: a hasher returning true
- When: authenticate is invoked with the matching password
- Then: an AuthToken is returned
- Then: UserAuthenticated is recorded

**Test: authenticate rejects deactivated accounts even with correct password**

- Given: a repository stub returning a deactivated account
- When: authenticate is called with the previously valid password
- Then: AccountInactiveError is returned
- Then: no AuthToken is issued

**Test: verifyToken rejects tokens signed with the wrong secret**

- Given: a token issued by a different signer instance
- When: verifyToken is called
- Then: TokenInvalid is returned and the call result is falsy

#### Integration Tests

**Test: revokeToken prevents subsequent verifyToken calls from succeeding**

- Given: a token issued and stored in the revocation registry
- When: verifyToken is called after revokeToken
- Then: TokenInvalid is returned
- Then: no further authentication events are emitted

---
