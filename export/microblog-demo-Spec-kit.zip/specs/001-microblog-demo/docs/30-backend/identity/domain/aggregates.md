# Identity and Access — Aggregates & Domain Events

## UserAccount

The aggregate root representing a registered member of the platform. It owns credentials, profile attributes, and lifecycle status, and enforces the consistency rules that keep the identity context self-contained.

**Root Entity:** `UserAccount`

### Invariants
- Username must be unique across the platform and match ^[a-z0-9_]{3,20}$
- Email address must be unique and syntactically valid
- Password is never stored in plaintext; only its hash is persisted
- A deactivated account cannot authenticate, reactivate, or update its profile

### Value Objects
- `Username`
- `EmailAddress`
- `PasswordHash`
- `DisplayProfile`

### Commands
- `Register`
- `VerifyEmail`
- `UpdateProfile`
- `ChangePassword`
- `RequestPasswordReset`
- `Deactivate`

### Domain Events Emitted
- `UserRegistered`
- `EmailVerified`
- `ProfileUpdated`
- `PasswordChanged`
- `PasswordResetRequested`
- `AccountDeactivated`

## Domain Events Catalog

### UserRegistered

Published when a new account successfully completes registration.

**Triggered by:** Register command on UserAccount aggregate
**Handled by:** social-graph, notifications, search

**Payload:**
- `userId`
- `username`
- `email`
- `registeredAt`

### UserAuthenticated

Published after a successful password-based login. Carries no credentials.

**Triggered by:** AuthenticationService.authenticate
**Handled by:** feed, social-graph, notifications

**Payload:**
- `userId`
- `sessionId`
- `authenticatedAt`

### ProfileUpdated

Published when a user changes any profile-level attribute such as name, bio, or avatar.

**Triggered by:** UpdateProfile command on UserAccount aggregate
**Handled by:** search, feed

**Payload:**
- `userId`
- `changedFields`
- `updatedAt`

### PasswordResetRequested

Published when a user requests a password reset, signalling the notifications context to send a reset link.

**Triggered by:** RequestPasswordReset command on UserAccount aggregate
**Handled by:** notifications

**Payload:**
- `userId`
- `resetTokenId`
- `requestedAt`
