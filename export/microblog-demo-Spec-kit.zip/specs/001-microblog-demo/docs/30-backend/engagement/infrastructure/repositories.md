# Engagement — Infrastructure

## Engagement Read Model

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/engagement/engagement_read_model.py`

### Purpose

Repository-backed query service exposing like and repost counts, projected from domain events.

### Responsibilities

- Maintain denormalized like and repost counters per post
- Project PostLiked, PostUnliked, PostReposted, and PostUnreposted events into counters
- Serve bulk count queries for feed assembly and post detail pages

### Public API

- `GetCounts(postId)`
- `GetCountsBatch(postIds)`
- `ProjectEvent(event)`

### Inputs

- postId
- batch of postIds
- incoming domain event

### Outputs

- EngagementCounts DTO (likes, reposts, quotes)
- projection ack/nack

### Dependencies

- engagement:LikeAggregate (event source)
- engagement:RepostAggregate (event source)
- postgres or Redis counter store

### Error Handling

Returns zeros for missing posts; logs and DLQs event-projection failures for replay; retries transient store errors with exponential backoff.

### Acceptance Criteria

- [ ] PostLiked increments like count by exactly 1 and is idempotent under event replay
- [ ] PostUnliked decrements like count and the count never goes negative
- [ ] GetCountsBatch returns within p99 < 50ms for 50 postIds
- [ ] Projection handler survives transient store errors via retry

### Out of Scope

- Authoring engagement actions (controller and aggregates do this)
- Cross-context fan-out to notifications

### Test Specifications

#### Unit Tests

**Test: PostLiked projection increments like count idempotently**

- Given: post p1 with current like count 0
- Given: PostLiked event for p1
- When: ProjectEvent is called once, then again with same eventId
- Then: count is 1 after both calls
- Then: no double-count on replay

**Test: PostUnliked never reduces like count below zero**

- Given: post p1 with current like count 0
- When: ProjectEvent handles a PostUnliked for p1
- Then: count remains 0
- Then: no negative value is stored

**Test: GetCountsBatch returns per-post counts for a mixed list**

- Given: p1 with 5 likes
- Given: p2 with 0 likes
- When: GetCountsBatch([p1, p2]) is called
- Then: returns {p1:5, p2:0}
- Then: missing posts return 0 not error

#### Integration Tests

**Test: Read model rebuilds counts from event log on cold start**

- Given: empty counter store
- Given: event log with 3 PostLiked for p1 and 1 PostUnliked
- When: ProjectEvent replays the log
- Then: p1 like count is 2
- Then: no projection errors are raised

---
