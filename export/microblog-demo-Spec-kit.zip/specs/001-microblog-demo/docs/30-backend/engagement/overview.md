# Engagement

Tracks user interactions (likes, reposts, bookmarks) on posts, enforces single-action invariants, exposes engagement counters, and publishes engagement events to the feed, posts, and notifications contexts.

**Layer:** `backend`
**Directory:** `src/engagement`

## Responsibilities

- Record and revoke likes on posts with single-like-per-user enforcement
- Record simple and quote reposts with attribution to the original author
- Manage user-private bookmarks and bookmark collections
- Expose denormalized like and repost counters for posts and feed assembly
- Publish PostLiked, PostUnliked, PostReposted, PostUnreposted, and PostBookmarked events
- Make all engagement actions idempotent to survive retries and concurrent requests
