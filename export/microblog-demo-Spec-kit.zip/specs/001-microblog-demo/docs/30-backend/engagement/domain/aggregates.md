# Engagement — Aggregates & Domain Events

## Like

Aggregate representing a single user's like on a target post.

**Root Entity:** `Like`

### Invariants
- A user can like a given post at most once
- A like must reference an existing post and an existing user
- Unlike is only valid when a like currently exists
- Each state transition emits exactly one domain event

### Value Objects
- `LikeId`
- `PostId`
- `UserId`
- `LikedAt`

### Commands
- `LikePost`
- `UnlikePost`

### Domain Events Emitted
- `PostLiked`
- `PostUnliked`

## Repost

Aggregate representing a user's simple or quote repost of another post.

**Root Entity:** `Repost`

### Invariants
- A user cannot repost their own post
- Quote text, if present, must be 1–280 characters
- Repost preserves the original post identifier and author
- Unrepost removes the repost without affecting the original

### Value Objects
- `RepostId`
- `OriginalPostId`
- `ReposterId`
- `QuoteText`

### Commands
- `RepostPost`
- `QuoteRepost`
- `Unrepost`

### Domain Events Emitted
- `PostReposted`
- `PostUnreposted`

## Bookmark

Aggregate representing a user's private bookmark of a post, optionally grouped into a named collection.

**Root Entity:** `Bookmark`

### Invariants
- A user can bookmark a given post at most once
- Bookmarks are visible only to the owning user
- Collection name, if present, must be non-empty and ≤ 32 characters
- MoveToCollection requires the bookmark to currently exist

### Value Objects
- `BookmarkId`
- `PostId`
- `UserId`
- `CollectionName`

### Commands
- `BookmarkPost`
- `UnbookmarkPost`
- `MoveToCollection`

### Domain Events Emitted
- `PostBookmarked`
- `PostUnbookmarked`
- `BookmarkMoved`

## Domain Events Catalog

### PostLiked

Emitted when a user likes a post for the first time.

**Triggered by:** Like.LikePost command
**Handled by:** feed, notifications, posts

**Payload:**
- `postId`
- `userId`
- `likedAt`
- `totalLikeCount`

### PostUnliked

Emitted when a user removes their like from a post.

**Triggered by:** Like.UnlikePost command
**Handled by:** feed, posts

**Payload:**
- `postId`
- `userId`
- `unlikedAt`

### PostReposted

Emitted when a user reposts or quote-reposts a post.

**Triggered by:** Repost.RepostPost or Repost.QuoteRepost command
**Handled by:** feed, notifications, posts

**Payload:**
- `originalPostId`
- `reposterId`
- `repostId`
- `isQuote`
- `repostedAt`

### PostBookmarked

Emitted when a user bookmarks a post (used internally by engagement read model).

**Triggered by:** Bookmark.BookmarkPost command
**Handled by:** feed

**Payload:**
- `postId`
- `userId`
- `bookmarkId`
- `collection`
