# Engagement — Application Use Cases

## Engagement Controller

**Type:** `controller` · **Layer:** `application` · **File:** `src/engagement/engagement_controller.py`

### Purpose

HTTP controller exposing like, repost, and bookmark endpoints with auth and idempotency.

### Responsibilities

- Expose REST endpoints for like, unlike, repost, quote-repost, unbookmark
- Resolve authenticated userId from JWT and validate request payloads
- Apply idempotency keys to make engagement actions retry-safe

### Public API

- `POST /posts/{id}/like`
- `DELETE /posts/{id}/like`
- `POST /posts/{id}/repost`
- `POST /posts/{id}/quote`
- `DELETE /posts/{id}/bookmark`

### Inputs

- HTTP request (auth token, path and body params, idempotency key)

### Outputs

- HTTP 200/201/204 with engagement result
- HTTP 4xx with domain error code

### Dependencies

- identity:AuthService
- engagement:LikeAggregate
- engagement:RepostAggregate
- engagement:BookmarkAggregate

### Error Handling

Maps domain errors to 409 (conflict), 404 (not found), 400 (validation); 401 on auth failure; 429 on idempotency replay abuse.

### Acceptance Criteria

- [ ] POST /posts/{id}/like returns 201 on first like and 409 on duplicate within the idempotency window
- [ ] DELETE /posts/{id}/like returns 204 on success and 404 if no like exists
- [ ] POST /posts/{id}/quote rejects quotes over 280 chars with 400
- [ ] All endpoints require a valid JWT and return 401 otherwise

### Out of Scope

- Engagement counter reads (handled by read model)
- Realtime WebSocket fan-out

### Test Specifications

#### Unit Tests

**Test: POST /like returns 201 on first like and 409 on duplicate**

- Given: authenticated user u1
- Given: post p1
- Given: no prior like
- When: POST /posts/p1/like is called twice with same idempotency key
- Then: first call returns 201
- Then: second call returns 409

**Test: POST /quote rejects payloads with quote longer than 280 chars**

- Given: authenticated user u1
- Given: post p1 authored by u2
- When: POST /posts/p1/quote is called with a 281-char quote
- Then: response is 400
- Then: no Repost entity is created

#### Integration Tests

**Test: Like endpoint persists state and publishes PostLiked to event bus**

- Given: authenticated user u1
- Given: post p1
- Given: subscribed event sink
- When: POST /posts/p1/like is invoked end-to-end
- Then: Like row exists
- Then: PostLiked event reaches sink
- Then: response is 201

**Test: Unauthenticated like request returns 401 without side effects**

- Given: missing or invalid JWT
- Given: post p1
- When: POST /posts/p1/like is invoked
- Then: response is 401
- Then: no Like row is created
- Then: no event is emitted

---
