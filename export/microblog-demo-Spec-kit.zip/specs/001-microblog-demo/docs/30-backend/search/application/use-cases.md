# Search and Trending — Application Use Cases

## Search Controller

**Type:** `controller` · **Layer:** `application` · **File:** `src/search/search_controller.py`

### Purpose

FastAPI HTTP layer exposing /search and /trending endpoints with auth, rate limiting, and validation.

### Responsibilities

- Validate incoming search and trending query parameters
- Enforce per-user rate limits and content-safety filters at the edge
- Translate HTTP requests into use-case invocations and shaped responses

### Public API

- `GET /search/posts`
- `GET /search/users`
- `GET /trending/topics`
- `GET /search/suggest`

### Inputs

- query string
- filter params
- auth context
- pagination cursor

### Outputs

- result page
- trend list
- request id
- rate-limit headers

### Dependencies

- search-query-service
- trending-computation-service
- auth middleware
- rate limiter

### Error Handling

Map validation failures to 400, empty results to 200 with an empty page, index backend failures to 503 with retry hint.

### Acceptance Criteria

- [ ] p95 /search latency under 300ms with a warm index
- [ ] Returns 400 on malformed query and 401 when unauthenticated
- [ ] Trending list refreshes at least every 5 minutes
- [ ] Rate limit headers are present on every response

### Out of Scope

- Frontend rendering
- Indexer infrastructure provisioning

### Test Specifications

#### Unit Tests

**Test: controller rejects empty query string with 400**

- Given: GET /search/posts?q=
- When: the handler validates the request
- Then: returns 400
- Then: no service invocation occurs

**Test: controller forwards valid query to search query service**

- Given: GET /search/posts?q=hello&limit=20
- Given: auth context present
- When: the handler dispatches the request
- Then: calls search-query-service.search() once
- Then: returns 200 with page

#### Integration Tests

**Test: GET /trending returns current snapshot from computation service**

- Given: a seeded trending snapshot at T-1m
- When: GET /trending/topics is invoked
- Then: returns 200 with topics ordered by descending score

---

## Search Query Service

**Type:** `service` · **Layer:** `application` · **File:** `src/search/search_query_service.py`

### Purpose

Application service that parses queries, applies ranking and filters, and returns paginated result pages.

### Responsibilities

- Parse and normalize user queries including hashtag and @mention syntax
- Apply scoring, recency boosts, and moderation filters
- Paginate results with stable opaque cursors

### Public API

- `search(query, ctx)`
- `suggest(prefix, ctx)`
- `countMatches(query, ctx)`

### Inputs

- SearchQuery value object
- user context
- filter set
- page size

### Outputs

- ranked result page
- total estimate
- next cursor

### Dependencies

- search-index repository
- authz service
- moderation filter
- result shaper

### Error Handling

Raise IndexUnavailable for transient backend failures, PermissionDenied for restricted entities, ValidationError for malformed normalized queries.

### Acceptance Criteria

- [ ] p95 search latency under 250ms on a warm cache
- [ ] Ranking is stable across identical inputs in the same window
- [ ] Filters from the moderation domain are always applied before pagination

### Out of Scope

- Index update path
- Frontend rendering

### Test Specifications

#### Unit Tests

**Test: service applies recency boost to posts newer than 24h**

- Given: two matching posts with different createdAt values
- Given: query 'hello'
- When: search(query, ctx) is invoked
- Then: newer post ranks first
- Then: returned page reflects boosted scores

**Test: service strips moderation-hidden posts before pagination**

- Given: indexed posts where some are flagged hidden by moderation
- When: search(query, ctx) is invoked
- Then: hidden posts are absent from results
- Then: total excludes hidden items

**Test: service raises IndexUnavailable when backend is unreachable**

- Given: index backend responds with a connection error
- When: search(query, ctx) is invoked
- Then: raises IndexUnavailable
- Then: no partial results returned

#### Integration Tests

**Test: search returns deterministic ordering across repeated calls**

- Given: seeded index with 50 matching posts
- When: search(query, ctx) is invoked twice in a row
- Then: order is identical between calls
- Then: total count is identical

---
