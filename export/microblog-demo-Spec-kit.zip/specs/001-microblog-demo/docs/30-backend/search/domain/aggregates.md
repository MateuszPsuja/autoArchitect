# Search and Trending — Aggregates & Domain Events

## Search Index

Projection aggregate holding the searchable view of posts and users consumed by query handlers.

**Root Entity:** `IndexedDocument`

### Invariants
- Every indexed document references an existing source record id
- Removed sources generate tombstones preventing resurrection by stale replays
- Tokenized fields use the analyzer version active when the document was indexed

### Value Objects
- `SearchQuery`
- `RelevanceScore`
- `IndexTombstone`

### Commands
- `IndexDocument`
- `RemoveDocument`
- `RebuildIndex`

### Domain Events Emitted
- `DocumentIndexed`
- `DocumentRemoved`

## Trending Topic

Rolling-window aggregate that ranks hashtags by mention velocity and decay-weighted score.

**Root Entity:** `TrendingSnapshot`

### Invariants
- Snapshot window duration is a positive multiple of the recompute interval
- Ranked topics are always ordered by descending trend score
- Pinned topics persist across recomputes until explicitly unpinned

### Value Objects
- `TimeWindow`
- `TrendScore`
- `Hashtag`

### Commands
- `RecordMention`
- `RecomputeTrends`
- `PinTopic`

### Domain Events Emitted
- `TrendingSnapshotComputed`
- `TrendingTopicPromoted`

## Domain Events Catalog

### Search Index Updated

Emitted when documents are added, updated, or removed from the search index.

**Triggered by:** IndexDocument|RemoveDocument
**Handled by:** posts, engagement, feed

**Payload:**
- `documentId`
- `operation`
- `indexedAt`
- `indexName`

### Trending Snapshot Computed

Periodic recompute completion carrying the new trending list and window timestamps.

**Triggered by:** RecomputeTrends
**Handled by:** feed, notifications

**Payload:**
- `snapshotId`
- `windowStart`
- `windowEnd`
- `topics`

### Trending Topic Promoted

A hashtag crossed the promotion threshold and appears on the public trending list.

**Triggered by:** RecomputeTrends
**Handled by:** feed, notifications

**Payload:**
- `hashtag`
- `score`
- `rank`
- `language`
