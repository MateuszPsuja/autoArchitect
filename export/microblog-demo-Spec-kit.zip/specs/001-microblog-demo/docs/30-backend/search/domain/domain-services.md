# Search and Trending — Domain Services

## Trending Computation Service

**Type:** `service` · **Layer:** `domain` · **File:** `src/search/trending_computation_service.py`

### Purpose

Domain service that aggregates hashtag mentions and produces immutable trending snapshots.

### Responsibilities

- Aggregate hashtag mentions within the configured time window
- Compute trend scores using velocity and decay weighting
- Produce immutable trending snapshots for downstream consumers

### Public API

- `recompute(now)`
- `getLatestSnapshot()`
- `pinTopic(hashtag, ttl)`

### Inputs

- engagement events
- window configuration
- pin list

### Outputs

- TrendingSnapshot
- ranked hashtag list
- compute metadata

### Dependencies

- event store
- snapshot repository

### Error Handling

Raise TrendingComputationFailed when the event store is unavailable; partial failures fall back to the previous snapshot with a degraded flag.

### Acceptance Criteria

- [ ] Recompute completes in under 5 seconds for 1M mention events
- [ ] Snapshots are immutable and append-only
- [ ] Pinned topics remain on the list regardless of raw score

### Out of Scope

- Rendering trending UI
- Index management

### Test Specifications

#### Unit Tests

**Test: snapshot orders topics by descending weighted score**

- Given: mention counts a:50, b:80, c:30 in the window
- When: recompute(now) is called
- Then: ranked list returns b, a, c in order

**Test: pinned topic survives even with zero mentions**

- Given: pin list with topic #event
- Given: no mentions in window
- When: recompute(now) is called
- Then: #event appears in ranked list
- Then: carries a pinned marker

**Test: prior snapshot is returned when recompute fails**

- Given: prior valid snapshot S
- Given: event store raising on read
- When: recompute(now) is called
- Then: returns S with degraded=true flag

#### Integration Tests

**Test: scheduled recompute persists a new snapshot and emits an event**

- Given: scheduler tick and engagement events for the last hour
- When: the scheduled recompute runs
- Then: new snapshot row exists
- Then: feed listener receives the event

---
