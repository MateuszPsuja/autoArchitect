# Search and Trending

Public full-text search over posts, hashtags, and users plus rolling-window trending topic detection for the microblog platform.

**Layer:** `backend`
**Directory:** `src/search`

## Responsibilities

- Provide full-text search across posts, hashtags, and user profiles
- Compute trending topics from a rolling time window with periodic recompute
- Maintain a synchronized search index driven by upstream domain events
- Apply ranking, pagination, and content-safety filters to outgoing queries
