# Search and Trending — Infrastructure

## Search Indexing Service

**Type:** `service` · **Layer:** `infrastructure` · **File:** `src/search/search_indexing_service.py`

### Purpose

Infrastructure service consuming upstream events to maintain the search index projection.

### Responsibilities

- Subscribe to post and user events from upstream domains
- Project events into indexable documents and tombstones
- Coordinate batched index writes with retry and dead-letter handling

### Public API

- `applyEvent(event)`
- `rebuildFromSnapshot(snapshot)`
- `getLag()`

### Inputs

- upstream domain events
- replay cursor
- index settings

### Outputs

- indexed documents
- tombstones
- lag metrics

### Dependencies

- event bus
- search index repository
- dead-letter queue
- metrics sink

### Error Handling

Retry transient errors with exponential backoff up to N attempts, then route the event to the dead-letter queue with id and cause.

### Acceptance Criteria

- [ ] Indexing lag p95 under 10 seconds under nominal load
- [ ] Replayed events produce identical indexed state
- [ ] Dead-letter entries include the original payload and a human-readable cause

### Out of Scope

- Query-time ranking
- Frontend rendering

### Test Specifications

#### Unit Tests

**Test: service indexes PostCreated into a fresh document**

- Given: incoming PostCreated event with author id
- When: applyEvent(event) is called
- Then: index contains one document matching the event id

**Test: service emits tombstone on PostDeleted event**

- Given: PostDeleted event for an indexed post
- When: applyEvent(event) is called
- Then: tombstone exists for the post id
- Then: search no longer returns the post

**Test: service dead-letters after retry exhaustion**

- Given: index backend rejecting writes for all retries
- When: applyEvent(event) is called
- Then: event id is forwarded to the dead-letter queue

#### Integration Tests

**Test: rebuild restores indexed state from a saved snapshot**

- Given: saved snapshot of posts and users
- When: rebuildFromSnapshot(snapshot) is called
- Then: index state matches the snapshot contents exactly

---
