# Posts and Threads — Infrastructure

## PostRepository

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `src/posts/infrastructure/post_repository.py`

### Purpose

Persistence port for Post aggregates using the application's chosen datastore.

### Responsibilities

- Persist new and edited posts
- Fetch posts by id, author, or parent
- Soft-delete rows while preserving tree structure
- Project post changes into the read model

### Public API

- `save`
- `findById`
- `findByAuthor`
- `findReplies`
- `softDelete`

### Inputs

- Post
- authorId
- parentPostId
- cursor

### Outputs

- Post
- Post list
- page metadata

### Dependencies

- database-client
- orm-mapper
- clock-service

### Error Handling

Translate infrastructure failures into a NotFound or PersistenceError domain exception; never leak ORM types to callers.

### Acceptance Criteria

- [ ] save persists aggregate and emits outbox row
- [ ] findById returns None for soft-deleted posts by default
- [ ] findReplies paginates by createdAt cursor
- [ ] softDelete keeps children discoverable
- [ ] bulk fetch limits to 100 per page

### Out of Scope

- Authorization checks
- Engagement metrics
- Search indexing

### Test Specifications

#### Unit Tests

**Test: save inserts a new post row**

- Given: a new Post aggregate
- Given: no existing id
- When: repository.save is called
- Then: row is inserted
- Then: returned post has populated id

**Test: findById returns None for soft-deleted posts**

- Given: a soft-deleted post id
- When: findById is called
- Then: None is returned

#### Integration Tests

**Test: findReplies returns children ordered by createdAt asc**

- Given: a root post with three replies
- When: findReplies is called
- Then: three replies returned
- Then: ordered oldest first

---

## PostController

**Type:** `controller` · **Layer:** `infrastructure` · **File:** `src/posts/api/post_controller.py`

### Purpose

HTTP boundary exposing post CRUD and reply endpoints for clients.

### Responsibilities

- Parse and validate JSON payloads
- Authenticate bearer tokens
- Delegate to use cases
- Map domain errors to HTTP status codes

### Public API

- `POST /posts`
- `POST /posts/{id}/reply`
- `PATCH /posts/{id}`
- `DELETE /posts/{id}`
- `GET /posts/{id}`

### Inputs

- HTTP request body
- Authorization header
- path parameters

### Outputs

- JSON response
- HTTP status

### Dependencies

- create-post-use-case
- edit-post-use-case
- delete-post-use-case
- identity-port

### Error Handling

Domain errors map to 400/401/403/404; unexpected errors map to 500 with a generic body.

### Acceptance Criteria

- [ ] POST /posts returns 201 with body
- [ ] PATCH /posts/{id} returns 200 on edit
- [ ] DELETE /posts/{id} returns 204 on soft-delete
- [ ] GET /posts/{id} returns 404 for missing
- [ ] All endpoints require Authorization header

### Out of Scope

- Rate limiting logic
- Media upload
- Threading UI rendering

### Test Specifications

#### Unit Tests

**Test: POST /posts with valid body returns 201**

- Given: authenticated user
- Given: valid body
- When: POST /posts is called
- Then: status is 201
- Then: response contains post id

**Test: DELETE /posts/{id} by non-author returns 403**

- Given: authenticated user not the author
- Given: existing post id
- When: DELETE /posts/{id} is called
- Then: status is 403
- Then: post is not soft-deleted

#### Integration Tests

**Test: GET /posts/{id}/replies returns paged children**

- Given: a post with two replies
- When: GET /posts/{id}/replies endpoint is called
- Then: status is 200
- Then: replies are ordered by createdAt asc

---
