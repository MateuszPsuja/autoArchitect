# Posts and Threads

Bounded context that owns the lifecycle of user-authored short posts and threaded replies, including edits, deletions, and media attachments up to 280 characters.

**Layer:** `backend`
**Directory:** `src/posts`

## Responsibilities

- Create, edit, and delete original posts up to 280 characters
- Author threaded replies and maintain parent-child reply structure
- Enforce authorship, immutability, and soft-delete invariants
- Attach media references (image/video) to posts
- Emit domain events for engagement, feed, and notifications contexts
- Validate content policy rules prior to persistence
