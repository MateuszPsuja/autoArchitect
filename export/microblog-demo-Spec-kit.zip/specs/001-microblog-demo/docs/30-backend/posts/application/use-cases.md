# Posts and Threads — Application Use Cases

## CreatePostUseCase

**Type:** `use-case` · **Layer:** `application` · **File:** `src/posts/application/create_post.py`

### Purpose

Application service orchestrating Post creation, persistence, and event publication.

### Responsibilities

- Authorize the caller against identity context
- Validate input and enforce 280-char limit
- Persist via PostRepository
- Publish PostCreated to the outbox

### Public API

- `execute`

### Inputs

- callerId
- body
- mediaIds
- parentPostId

### Outputs

- Post

### Dependencies

- post-repository
- identity-port
- outbox-port
- clock-service

### Error Handling

Map domain errors to typed application exceptions (Unauthorized, ValidationError); never expose stack traces.

### Acceptance Criteria

- [ ] Returns 201 with Post on success
- [ ] Returns 400 on empty or >280 char body
- [ ] Returns 401 if caller is unauthenticated
- [ ] Returns 404 if parentPostId references missing post
- [ ] Outbox row written in same transaction as Post

### Out of Scope

- Rendering responses
- Pushing notifications
- Indexing for search

### Test Specifications

#### Unit Tests

**Test: execute returns post and writes outbox event**

- Given: authenticated caller
- Given: valid 140-char body
- When: execute is called
- Then: Post is returned
- Then: PostCreated written to outbox

**Test: execute rejects body exceeding 280 chars**

- Given: body of 281 chars
- When: execute is called
- Then: ValidationError is raised
- Then: no write occurs

#### Integration Tests

**Test: replying routes to ReplyToPost and emits ReplyPosted**

- Given: authenticated caller
- Given: existing parent post
- When: execute with parentPostId is called
- Then: reply persisted
- Then: ReplyPosted event in outbox

---
