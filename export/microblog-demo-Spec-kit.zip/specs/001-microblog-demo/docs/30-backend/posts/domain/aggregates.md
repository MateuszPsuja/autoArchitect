# Posts and Threads — Aggregates & Domain Events

## Post

Owns the lifecycle of a single post or reply, enforcing the 280-character limit, authorship, edit window, and soft-delete semantics.

**Root Entity:** `Post`

### Invariants
- Post body length is between 1 and 280 characters after trimming
- Only the original author may edit or delete the post
- Edits are not permitted after 24 hours from creation
- A reply must reference an existing non-deleted parent post

### Value Objects
- `PostId`
- `PostBody`
- `MediaAttachment`
- `AuthorRef`

### Commands
- `CreatePost`
- `ReplyToPost`
- `EditPost`
- `DeletePost`
- `AttachMedia`

### Domain Events Emitted
- `PostCreated`
- `PostEdited`
- `PostDeleted`
- `ReplyPosted`

## Thread

Maintains the structural integrity of reply trees, including parent linkage, orphan handling, and reply count denormalization.

**Root Entity:** `Thread`

### Invariants
- A thread root is always a top-level (non-reply) post
- Reply count equals the count of non-deleted direct children
- Cyclic reply chains are rejected at write time
- Deleting a thread root soft-cascades to all descendants

### Value Objects
- `ThreadId`
- `ReplyNode`
- `ThreadStats`

### Commands
- `OpenThread`
- `RegisterReply`
- `RecomputeReplyCount`
- `SoftDeleteThread`

### Domain Events Emitted
- `ThreadOpened`
- `ThreadReplyRegistered`
- `ThreadClosed`

## Domain Events Catalog

### PostCreated

Emitted when a new top-level post or reply is successfully persisted.

**Triggered by:** CreatePost or ReplyToPost command
**Handled by:** engagement, feed, notifications, search

**Payload:**
- `postId`
- `authorId`
- `body`
- `parentPostId`
- `createdAt`

### PostEdited

Emitted when an author updates the body of a post within the edit window.

**Triggered by:** EditPost command
**Handled by:** feed, search

**Payload:**
- `postId`
- `authorId`
- `newBody`
- `editedAt`

### PostDeleted

Emitted when a post is soft-deleted by its author or by moderation.

**Triggered by:** DeletePost command
**Handled by:** engagement, feed, notifications, search

**Payload:**
- `postId`
- `authorId`
- `deletedAt`
- `reason`

### ReplyPosted

Emitted when a reply is attached to an existing post, used to thread notifications.

**Triggered by:** ReplyToPost command
**Handled by:** notifications, feed, engagement

**Payload:**
- `replyId`
- `parentPostId`
- `rootPostId`
- `authorId`
- `createdAt`
