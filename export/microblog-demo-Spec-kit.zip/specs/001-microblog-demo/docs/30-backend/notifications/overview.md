# Notifications

Aggregates, stores, and delivers real-time and historical notifications for users across in-app, push, email, and WebSocket channels, honoring per-user preferences and topic-level mutes.

**Layer:** `backend`
**Directory:** `src/notifications`

## Responsibilities

- Record notifications emitted from Posts, Engagement, Social Graph, Messaging, and Moderation contexts
- Fan-in aggregation to suppress duplicates (e.g., many likes on one post collapse into one digest)
- Deliver notifications through in-app inbox, WebSocket push, mobile push, and email channels
- Manage user notification preferences, quiet hours, and per-type and per-channel muting
- Expose REST and WebSocket APIs to list, stream, mark read, and dismiss notifications
- Backfill missed notifications when a user reconnects after offline periods
