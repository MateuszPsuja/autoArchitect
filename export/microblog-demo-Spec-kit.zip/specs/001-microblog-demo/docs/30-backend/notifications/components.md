# Notifications — UI Components

## NotificationsController

**Type:** `controller` · **Layer:** `presentation` · **File:** `src/notifications/api/notifications_controller.py`

### Purpose

Presentation layer exposing REST endpoints for inbox management and a WebSocket channel for real-time push of newly recorded notifications.

### Responsibilities

- Authenticate and authorize every request against the calling user
- Stream real-time notifications over WebSocket with last-event-id replay
- Validate query parameters and apply cursor-based pagination
- Translate HTTP inputs into aggregate commands and route events to clients

### Public API

- `GET /notifications`
- `POST /notifications/{id}/read`
- `POST /notifications/read-all`
- `DELETE /notifications/{id}`
- `GET /notifications/preferences`
- `WS /ws/notifications`

### Inputs

- HTTP request
- WebSocket connection
- JWT bearer token
- cursor query param
- status filter

### Outputs

- JSON envelope
- WebSocket frames
- 204 No Content
- 401/403/404 HTTP responses

### Dependencies

- notification-stream-aggregate
- notification-preferences-aggregate
- notification-repository
- jwt-auth
- websocket-hub

### Error Handling

Domain errors are mapped to RFC 9457 problem+json responses; authentication failures return 401; rate-limited endpoints return 429 with a Retry-After header.

### Acceptance Criteria

- [ ] Unauthenticated requests are rejected with 401 before reaching aggregates
- [ ] WebSocket replay delivers missed notifications within 2 seconds of reconnect
- [ ] Rate limit of 120 reads per minute per user returns 429 beyond threshold
- [ ] Read-all endpoint processes 10k unread entries within 500ms
- [ ] All endpoints include a Request-ID header for correlation

### Out of Scope

- Email or push provider SDKs (handled by the NotificationDelivery dispatcher)
- Preference persistence (handled by NotificationPreferences aggregate and repository)

### Test Specifications

#### Unit Tests

**Test: GET /notifications returns envelope with desc-ordered items**

- Given: a user with 3 notifications across two days
- When: GET /notifications is called without cursor
- Then: status is 200
- Then: items are desc by createdAt
- Then: envelope contains nextCursor

**Test: Read-all marks every unread notification for the caller**

- Given: a user with 5 unread notifications
- When: POST /notifications/read-all is called
- Then: status is 204
- Then: all 5 notifications become READ

#### Integration Tests

**Test: WebSocket stream emits a recorded notification within 1 second**

- Given: an open WS session for userA authenticated with a valid JWT
- When: a NotificationRecorded event for userA is published
- Then: the client receives the notification frame within 1 second
- Then: no other user's frames leak

---
