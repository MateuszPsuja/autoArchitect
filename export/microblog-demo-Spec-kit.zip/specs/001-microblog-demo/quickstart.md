# Microblog Platform — Quickstart / Validation Scenarios

> Auto-derived from the per-layer constitution checks. Each scenario is a BDD Given/When/Then that an automated test (or manual run) can reproduce.

## Scenario 01 — Strict type checking on every Pydantic schema (extra=forbid) and mypy --strict on the application layer

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** strict type checking on every pydantic schema (extra=forbid) and mypy --strict on the application layer holds true.

## Scenario 02 — At least 2 unit tests plus 1 integration test per use case, with the domain layer tested without I/O

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** at least 2 unit tests plus 1 integration test per use case, with the domain layer tested without i/o holds true.

## Scenario 03 — Domain layer has zero framework imports (no FastAPI, SQLAlchemy, Redis, boto3, or OpenSearch client)

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** domain layer has zero framework imports (no fastapi, sqlalchemy, redis, boto3, or opensearch client) holds true.

## Scenario 04 — Outbox pattern is used for every domain event; no synchronous cross-context calls from request handlers

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** outbox pattern is used for every domain event; no synchronous cross-context calls from request handlers holds true.

## Scenario 05 — All authorization checks live in the application layer; routes never short-circuit policy decisions

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** all authorization checks live in the application layer; routes never short-circuit policy decisions holds true.

## Scenario 06 — Background work runs only in ARQ workers; the web process never executes long jobs inline

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** background work runs only in arq workers; the web process never executes long jobs inline holds true.

## Scenario 07 — Every worker job is idempotent on its event id

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** every worker job is idempotent on its event id holds true.

## Scenario 08 — Workers never call the API directly; they consume events from Redis Streams

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** workers never call the api directly; they consume events from redis streams holds true.

## Scenario 09 — Every job emits an OpenTelemetry span with the event id as an attribute

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** every job emits an opentelemetry span with the event id as an attribute holds true.

## Scenario 10 — Failed jobs go to a per-stream DLQ after 5 retries

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** failed jobs go to a per-stream dlq after 5 retries holds true.

## Scenario 11 — Worker processes expose a /healthz endpoint

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** worker processes expose a /healthz endpoint holds true.

## Scenario 12 — Strict TypeScript with noImplicitAny and strictNullChecks

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** strict typescript with noimplicitany and strictnullchecks holds true.

## Scenario 13 — Standalone components only — no NgModule declarations

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** standalone components only — no ngmodule declarations holds true.

## Scenario 14 — Mutate signalStore state only via patchState inside withMethods

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** mutate signalstore state only via patchstate inside withmethods holds true.

## Scenario 15 — All HTTP and WSS payloads validated with a Zod schema before reaching components

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** all http and wss payloads validated with a zod schema before reaching components holds true.

## Scenario 16 — Lazy-load every top-level feature via loadComponent or loadChildren

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** lazy-load every top-level feature via loadcomponent or loadchildren holds true.

## Scenario 17 — Route guards (AuthGuard, StaffGuard) wrap every protected route; no client-side trust of auth state

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** route guards (authguard, staffguard) wrap every protected route; no client-side trust of auth state holds true.

## Scenario 18 — Accessibility: WCAG 2.1 AA targets with PrimeNG ARIA primitives and keyboard-navigable timeline

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** accessibility: wcag 2.1 aa targets with primeng aria primitives and keyboard-navigable timeline holds true.

## Scenario 19 — Zod schema is the source of truth; TypeScript types and Pydantic models are generated, never handwritten

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** zod schema is the source of truth; typescript types and pydantic models are generated, never handwritten holds true.

## Scenario 20 — Every domain event is declared in the AsyncAPI catalogue with a versioned name (.vN)

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** every domain event is declared in the asyncapi catalogue with a versioned name (.vn) holds true.

## Scenario 21 — OpenAPI 3.1 spec is regenerated on every CI run and committed to the repo

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** openapi 3.1 spec is regenerated on every ci run and committed to the repo holds true.

## Scenario 22 — Breaking payload changes require a new .vN+1 suffix on the event name and a deprecation window

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** breaking payload changes require a new .vn+1 suffix on the event name and a deprecation window holds true.

## Scenario 23 — Schemas live in shared/schemas and are imported by both backend and frontend through the codegen artefacts

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** schemas live in shared/schemas and are imported by both backend and frontend through the codegen artefacts holds true.

## Scenario 24 — codegen drift (committed artefact != generated artefact) fails CI on both backend and frontend

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** codegen drift (committed artefact != generated artefact) fails ci on both backend and frontend holds true.

## Scenario 25 — All images pinned by digest, not tag

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** all images pinned by digest, not tag holds true.

## Scenario 26 — Migrations run as a separate one-shot job, not on app start

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** migrations run as a separate one-shot job, not on app start holds true.

## Scenario 27 — OpenTelemetry traces and metrics exported on every request, worker job, and WebSocket frame

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** opentelemetry traces and metrics exported on every request, worker job, and websocket frame holds true.

## Scenario 28 — Every Prometheus alert links to a runbook in docs/runbooks/

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** every prometheus alert links to a runbook in docs/runbooks/ holds true.

## Scenario 29 — CI fails on any uncommitted generated artefact (OpenAPI, TS types, Terraform plan)

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** ci fails on any uncommitted generated artefact (openapi, ts types, terraform plan) holds true.

## Scenario 30 — Sidecars bind to 127.0.0.1 only; multi-tenant access is enforced at the listen address

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** sidecars bind to 127.0.0.1 only; multi-tenant access is enforced at the listen address holds true.
