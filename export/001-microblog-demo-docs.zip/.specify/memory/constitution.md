# Microblog Platform (Demo) Project Constitution

> The principles that govern how this project is built. Every per-layer Constitution Check in `plan.md` MUST be traceable back to one of the articles below. Amendments append a changelog entry to **Last Amended** rather than rewriting articles in place.

| Field | Value |
|---|---|
| **Version** | `1.0.0` |
| **Ratified** | 2026-09-15T00:00:00.000Z |
| **Last Amended** | 2026-09-15T00:00:00.000Z |

## Article 1 — Library-First

Each bounded context ships as a standalone library with a public API and a CLI surface, owned by exactly one team.

## Article 2 — CLI Interface

Every library exposes a CLI entry point for ad-hoc operations and integration testing; the CLI is the canonical operator interface.

## Article 3 — Test-First (TDD)

Tests are written before implementation. Every component ships with a tddSpec that lists BDD Given/When/Then scenarios covering the happy path and the primary failure mode.

## Article 4 — Integration Testing

Real dependencies are exercised in integration tests; only repositories and external adapters are stubbed.

## Article 5 — Observability

Structured logs with correlation IDs, OpenTelemetry traces, and Prometheus metrics at every cross-process boundary.

## Article 6 — Versioning & Breaking Changes

Breaking changes require a major version bump and a migration note. Wire payloads use a `.vN` suffix; consumer is responsible for handling at least N-1.

## Article 7 — Simplicity

Prefer the simplest solution that satisfies the constitution checks. Reject premature abstractions and premature optimisation.

## Article 8 — Anti-Abstraction

No interface or base class without at least two concrete consumers in the current plan. Repositories do not exist before a second implementation appears.

## Article 9 — Integration-First Delivery

Every change ships with at least one integration test that exercises the new path end-to-end. Pure unit-test additions are not a release blocker on their own.

## Governance

- This constitution is amended, not rewritten. When an article changes, append a changelog row to the **Changelog** table and bump the **Version** field.
- The 9-article structure mirrors GitHub spec-kit's `constitution-template.md`. Adding or removing articles requires a major version bump.
- Per-layer Constitution Checks in `plan.md` MUST be traceable to one of the 9 articles above.

## Changelog

| Version | Date | Change | Author |
|---|---|---|---|
| `1.0.0` | 2026-09-15T00:00:00.000Z | Initial ratification (9 articles generated from autoArchitect stack + plan NFRs). | autoArchitect planner |
