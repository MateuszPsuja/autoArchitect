# `workers/src/fan_out`

> **Layer:** Backend Workers

Fan-out dispatcher, materializer, and timeline cache.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Workers must be idempotent; deduplicate by event id before mutating state.
- [ ] Every long-running job must emit an OpenTelemetry span with the event id as an attribute.
- [ ] Batch inserts into the timeline table at 500 rows per chunk.
