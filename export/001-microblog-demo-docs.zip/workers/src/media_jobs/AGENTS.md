# `workers/src/media_jobs`

> **Layer:** Backend Workers

Media transcoder and variant generator.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Workers must be idempotent; deduplicate by event id before mutating state.
- [ ] Every long-running job must emit an OpenTelemetry span with the event id as an attribute.
- [ ] Transcoding failures DLQ with reason code in the failure event.

## Files to Create

| File | Type | Description |
|---|---|---|
| `workers/src/media_jobs/transcoder.py` | `service` | Background service that transcodes uploaded media into variants. |

## Component Specifications

### Media Processor

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Failed transcode jobs emit Media.failed.v1 with a reason code.
- [ ] Transcoding is idempotent by upload id.
