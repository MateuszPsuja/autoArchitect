# `workers/src/search_index`

> **Layer:** Backend Workers

OpenSearch indexer and trending calculator.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Workers must be idempotent; deduplicate by event id before mutating state.
- [ ] Every long-running job must emit an OpenTelemetry span with the event id as an attribute.
- [ ] Flush the indexing queue at 500 items or 2 seconds, whichever first.

## Files to Create

| File | Type | Description |
|---|---|---|
| `workers/src/search_index/trending_calculator.py` | `domain-service` | Computes trending hashtags and topics over a rolling 24-hour window. |
| `workers/src/search_index/indexer.py` | `service` | Buffers index events and flushes them to OpenSearch in batches. |

## Component Specifications

### Trending Calculator

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Trending recomputation completes within 30 seconds for 1M events.
- [ ] Snapshot is served from cache with a 60-second TTL.

### Indexing Queue

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] The queue never drops events on graceful shutdown.
- [ ] Flush latency p95 is under 250ms under steady load.
