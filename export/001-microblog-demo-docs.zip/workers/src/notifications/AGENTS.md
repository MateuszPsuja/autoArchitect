# `workers/src/notifications`

> **Layer:** Backend Workers

Mention detector and fan-out scheduler.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Workers must be idempotent; deduplicate by event id before mutating state.
- [ ] Every long-running job must emit an OpenTelemetry span with the event id as an attribute.
- [ ] Coalesce notifications within a 60-second window per user.

## Files to Create

| File | Type | Description |
|---|---|---|
| `workers/src/notifications/mention_detector.py` | `domain-service` | Parses post bodies and DMs to find mentioned handles. |
| `workers/src/notifications/fanout_scheduler.py` | `service` | Decides when and how to fan out a notification to push and WS channels. |

## Component Specifications

### Mention Detector

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Duplicate mentions are deduplicated.
- [ ] Handles are case-insensitive when resolving.

### Fan-out Scheduler

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] At most one push per user per coalescing window.
- [ ] WebSocket fan-out never blocks the API request path.
