# `infra/ci`

> **Layer:** Infrastructure

GitHub Actions pipelines for backend, workers, frontend, and e2e tests.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Pin base image digests, not tags.
- [ ] Every alert must link to a runbook in docs/runbooks/.
- [ ] Pipelines fail if any generated artefact is uncommitted.
