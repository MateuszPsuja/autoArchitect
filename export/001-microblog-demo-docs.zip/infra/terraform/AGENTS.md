# `infra/terraform`

> **Layer:** Infrastructure

Terraform modules and per-env configuration for VPC, EKS, RDS, ElastiCache, and OpenSearch.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Pin base image digests, not tags.
- [ ] Every alert must link to a runbook in docs/runbooks/.
- [ ] Compose files are for local dev only; production deploys use the EKS manifests.
