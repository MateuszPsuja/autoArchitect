# Microblog Platform (Demo) — Quickstart / Validation Scenarios

> Auto-derived from the per-layer constitution checks. Each scenario is a BDD Given/When/Then that an automated test (or manual run) can reproduce.

## Scenario 01 — Strict type checking on all Pydantic schemas (extra forbid)

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** strict type checking on all pydantic schemas (extra forbid) holds true.

## Scenario 02 — Unit plus integration tests per use case (at least 2 unit, at least 1 integration)

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** unit plus integration tests per use case (at least 2 unit, at least 1 integration) holds true.

## Scenario 03 — Domain layer has zero framework imports (no FastAPI, SQLAlchemy, or Redis)

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** domain layer has zero framework imports (no fastapi, sqlalchemy, or redis) holds true.

## Scenario 04 — Outbox pattern used for every domain event

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** outbox pattern used for every domain event holds true.

## Scenario 05 — All authorization checks live in the application layer, not routes

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend` layer,
- **Then** all authorization checks live in the application layer, not routes holds true.

## Scenario 06 — Every worker job is idempotent on its event id

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** every worker job is idempotent on its event id holds true.

## Scenario 07 — Workers never call the API directly; they consume events from Redis Streams

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** workers never call the api directly; they consume events from redis streams holds true.

## Scenario 08 — Every job emits an OpenTelemetry span with the event id as an attribute

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** every job emits an opentelemetry span with the event id as an attribute holds true.

## Scenario 09 — Failed jobs go to a per-stream DLQ after 5 retries

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** failed jobs go to a per-stream dlq after 5 retries holds true.

## Scenario 10 — Worker processes expose a /healthz endpoint

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `backend-workers` layer,
- **Then** worker processes expose a /healthz endpoint holds true.

## Scenario 11 — Strict TypeScript with noImplicitAny and strictNullChecks

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** strict typescript with noimplicitany and strictnullchecks holds true.

## Scenario 12 — Standalone components only - no NgModule declarations

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** standalone components only - no ngmodule declarations holds true.

## Scenario 13 — Mutate signalStore state only via patchState inside withMethods

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** mutate signalstore state only via patchstate inside withmethods holds true.

## Scenario 14 — All HTTP responses validated with a Zod schema before reaching components

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** all http responses validated with a zod schema before reaching components holds true.

## Scenario 15 — Lazy-load every top-level feature via loadComponent or loadChildren

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `frontend` layer,
- **Then** lazy-load every top-level feature via loadcomponent or loadchildren holds true.

## Scenario 16 — Zod schema is the source of truth; TypeScript types and Pydantic models are generated

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** zod schema is the source of truth; typescript types and pydantic models are generated holds true.

## Scenario 17 — Every domain event is declared in the AsyncAPI catalogue with a versioned name

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** every domain event is declared in the asyncapi catalogue with a versioned name holds true.

## Scenario 18 — OpenAPI 3.1 spec is regenerated on every CI run and committed

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** openapi 3.1 spec is regenerated on every ci run and committed holds true.

## Scenario 19 — Breaking payload changes require a new .vN suffix on the event name

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** breaking payload changes require a new .vn suffix on the event name holds true.

## Scenario 20 — Schemas live in shared/schemas and are imported by both backend and frontend

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `shared` layer,
- **Then** schemas live in shared/schemas and are imported by both backend and frontend holds true.

## Scenario 21 — All images pinned by digest, not tag

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** all images pinned by digest, not tag holds true.

## Scenario 22 — Migrations run as a separate one-shot job, not on app start

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** migrations run as a separate one-shot job, not on app start holds true.

## Scenario 23 — OpenTelemetry traces and metrics exported on every request and worker job

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** opentelemetry traces and metrics exported on every request and worker job holds true.

## Scenario 24 — Every Prometheus alert links to a runbook in docs/runbooks/

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** every prometheus alert links to a runbook in docs/runbooks/ holds true.

## Scenario 25 — CI fails on any uncommitted generated artefact (OpenAPI, TS types)

- **Given** the plan has been generated and the per-layer constitution checks are recorded,
- **When** an agent implements the `infra` layer,
- **Then** ci fails on any uncommitted generated artefact (openapi, ts types) holds true.
