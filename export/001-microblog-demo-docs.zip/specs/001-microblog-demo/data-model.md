# Microblog Platform (Demo) — Data Model

Cross-layer index of aggregates, value objects, commands, and domain events.

## Domains

| Domain | Layer | Aggregates | Events |
|---|---|---|---|
| [Identity and Access](#identity) | `shared` | 0 | 0 |
| [Social Graph](#social-graph) | `backend` | 1 | 1 |
| [Posts and Threads](#posts) | `backend` | 1 | 2 |
| [Engagement](#engagement) | `backend` | 0 | 1 |
| [Media](#media) | `backend` | 0 | 1 |
| [Search and Trending](#search) | `backend` | 0 | 0 |
| [Notifications](#notifications) | `backend` | 0 | 1 |

## Identity and Access

Shared context for user accounts, sessions, and verification badges.

**Layer:** `shared` · **Directory:** `backend/src/identity`

## Social Graph

Backend context for follow, block, and mute relationships.

**Layer:** `backend` · **Directory:** `backend/src/social_graph`

### Aggregates

#### FollowEdge

Aggregates a directed follow relationship between two users.

**Root entity:** `FollowEdge`

**Invariants:**

- A user cannot follow themselves.
- A user cannot follow another user who has blocked them.

**Value objects:**

- `FollowerId`
- `FolloweeId`
- `FollowTimestamp`

**Commands:**

- `follow`
- `unfollow`

**Domain events emitted:**

- `graph.followed.v1`
- `graph.unfollowed.v1`

### Domain Events

#### graph.followed.v1

Raised when a user follows another user.

**Triggered by:** FollowEdge.follow()

**Handled by:** Fan-out Dispatcher

**Payload:**

- `followerId`
- `followeeId`
- `followedAt`

## Posts and Threads

Backend context for the post, thread, and media-attachment aggregates.

**Layer:** `backend` · **Directory:** `backend/src/posts`

### Aggregates

#### Post

Aggregates a single post with a body, a status, and a bounded edit history.

**Root entity:** `Post`

**Invariants:**

- Body length is at most 280 characters.
- A post with status deleted cannot transition to published.
- A post published with media references cannot transition until all media are ready.

**Value objects:**

- `PostId`
- `PostBody`
- `PostStatus`

**Commands:**

- `publish`
- `edit`
- `delete`
- `reply`

**Domain events emitted:**

- `post.published.v1`
- `post.edited.v1`
- `post.deleted.v1`

### Domain Events

#### post.published.v1

Raised when a post transitions to published.

**Triggered by:** Post.publish()

**Handled by:** Fan-out Dispatcher, Search Indexer, Notification Worker

**Payload:**

- `postId`
- `authorId`
- `body`
- `replyTo`
- `mediaIds`
- `publishedAt`

#### post.deleted.v1

Raised when a post is deleted.

**Triggered by:** Post.delete()

**Handled by:** Fan-out Dispatcher, Search Indexer

**Payload:**

- `postId`
- `deletedAt`

## Engagement

Backend context for likes, reposts, and bookmarks.

**Layer:** `backend` · **Directory:** `backend/src/engagement`

### Domain Events

#### engagement.recorded.v1

Raised when a user likes, reposts, or bookmarks a post.

**Triggered by:** Like.like() or Repost.repost() or Bookmark.bookmark()

**Handled by:** Fan-out Dispatcher, Analytics Aggregator

**Payload:**

- `userId`
- `postId`
- `kind`
- `recordedAt`

## Media

Backend context for media uploads, variants, and transcoding.

**Layer:** `backend` · **Directory:** `backend/src/media`

### Domain Events

#### media.processed.v1

Raised when all variants for an upload are ready.

**Triggered by:** MediaProcessor.processUpload()

**Handled by:** Search Indexer

**Payload:**

- `uploadId`
- `variants`
- `processedAt`

## Search and Trending

Backend context for indexing published posts and computing trending topics.

**Layer:** `backend` · **Directory:** `backend/src/search`

## Notifications

Backend context for in-app notifications with push fan-out.

**Layer:** `backend` · **Directory:** `backend/src/notifications`

### Domain Events

#### notification.created.v1

Raised when a per-user notification is persisted.

**Triggered by:** Notification.create()

**Handled by:** Fan-out Scheduler

**Payload:**

- `userId`
- `kind`
- `actorId`
- `subjectId`
- `createdAt`
