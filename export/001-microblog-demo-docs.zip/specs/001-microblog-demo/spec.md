# Feature Specification: Microblog Platform (Demo)

**Feature Branch**: `001-microblog-demo` · **Generated**: 2026-09-15T00:00:00.000Z

> What users need and why. No tech stack, no code.

## Purpose

Deliver a fast, accessible microblog platform with real-time fan-out timelines, threaded conversations, media uploads, search, and direct messages.

## Context

Replaces a legacy single-server blog with a distributed microblog: a Python FastAPI backend, dedicated fan-out workers, an Angular SPA, and a managed Postgres plus Redis plus OpenSearch stack.

## User Scenarios & Testing


### User Story US001 — Read a home timeline (Priority: P1)

As an authenticated reader, I want to open the home feed and see the latest posts from the people I follow so that I can keep up with the conversation.

**Why this priority**

Core read path; without this the platform has no value.

**Independent Test**

A signed-in user with at least 10 followed authors sees a paginated home feed sorted by recency.

**Acceptance Scenarios**

1. **FR-001** —
   - **Given** a signed-in reader with 10 followed authors who each posted in the last hour
   - **When** the reader opens the home tab
   - **Then** the feed renders the 10 newest posts in reverse chronological order within 1.5s p95
2. **FR-002** —
   - **Given** a signed-in reader on the home tab
   - **When** they scroll past the 25th post
   - **Then** the next page loads via cursor pagination without full reload

**Bounded Contexts:** `posts`, `social-graph`

### User Story US002 — Compose and publish a post (Priority: P1)

As an authenticated author, I want to compose a post with optional media and publish it so that my followers see it on their home timeline.

**Why this priority**

Without authoring there is no content to read.

**Independent Test**

An author composes a 140-char post with one image and sees it on the home timeline of a followed reader within 2s.

**Acceptance Scenarios**

1. **FR-003** —
   - **Given** a signed-in author on the composer with a valid 140-char body and one image
   - **When** they tap Publish
   - **Then** the post is persisted with status=published and emitted as post.published.v1
2. **FR-004** —
   - **Given** a signed-in author on the composer with an empty body
   - **When** they tap Publish
   - **Then** the publish action is disabled and the body field shows a validation hint

**Bounded Contexts:** `posts`, `media`

### User Story US003 — Send a direct message (Priority: P2)

As an authenticated user, I want to send an encrypted 1:1 direct message to another user so that we can have a private conversation.

**Why this priority**

Important for trust, but the public platform works without it.

**Independent Test**

A user creates a new conversation with another user, sends a message, and the recipient sees the notification fire and the message appear in their inbox within 1s.

**Acceptance Scenarios**

1. **FR-005** —
   - **Given** two signed-in users A and B with no existing conversation
   - **When** A opens a new conversation with B and sends a message
   - **Then** the message is persisted ciphertext by the notifications outbox and B sees the decrypted plaintext within 1s

**Bounded Contexts:** `identity`, `notifications`

### User Story US004 — Search public posts (Priority: P3)

As any visitor, I want to search public posts by keyword so that I can discover content without following the author first.

**Why this priority**

Discovery; the platform works without it but reach suffers.

**Independent Test**

A visitor enters a known keyword and the search returns a paginated list of public posts sorted by relevance.

**Acceptance Scenarios**

1. **FR-006** —
   - **Given** a visitor on the search page with the keyword "election"
   - **When** they submit the query
   - **Then** the search returns public posts matching "election" ranked by relevance with a relevance score above 0.3

**Bounded Contexts:** `search`, `posts`

## Edge Cases

> No edge cases identified by the planner. Add explicit edge-case notes during refinement.

## Requirements (mandatory)

### Functional Requirements

- **FR-001** — The home timeline must render posts in reverse chronological order with cursor pagination.
- **FR-002** — Post publishing must be idempotent on the Idempotency-Key header.
- **FR-003** — Direct messages must be encrypted at rest with envelope encryption.
- **FR-004** — Media uploads must support JPEG, PNG, and MP4 up to 50 MB. **[NEEDS CLARIFICATION: NEEDS CLARIFICATION: confirm exact max size per file and whether GIFs are in scope.]**

## Key Entities

- **FollowEdge** (`follow-edge-aggregate`, in `social-graph`) — Aggregates a directed follow relationship between two users.
- **Post** (`post-aggregate`, in `posts`) — Aggregates a single post with a body, a status, and a bounded edit history.

## Success Criteria (mandatory)

### Measurable Outcomes

- **SC-001** — p95 home feed render under 1.5s on a warm cache.
- **SC-002** — Fan-out latency p95 under 1s from publish to follower timeline.
- **SC-003** — 99.9% availability for the read APIs.
- **SC-004** — Zero PII in logs; structured logging with correlation IDs.

## Assumptions

- Public timelines must render in under 2 seconds on 4G.
- Fan-out latency p95 under 1 second from publish to follower timeline.
- Direct messages must be encrypted at rest with envelope encryption.
