# Tasks: Microblog Platform (Demo)

> Tasks organised by User Story priority. Tests are written **before** implementation inside each story phase. Tasks with disjoint files (`fileHints`) AND disjoint user stories (`userStoryIds`) from every other task are marked `[P]` (parallelizable).

## Format

`- [ ] T### [P?] [USn?] Description — files: a, b`

## Path Conventions

- Repo root: this plan's branch (`specs/<NNN>-<slug>/`)
- Per-layer architecture: `docs/10-architecture/<layer>-architecture.md`
- Per-task file: `docs/60-agent-tasks/<NN>-<slug>.md`

## Phase 1: Setup (Shared Infrastructure)

- [ ] T001 Bootstrap repository layout per `docs/10-architecture/overview.md` and per-layer `projectStructureTree`.

## Phase 2: Foundational (Blocking Prerequisites)

> No domain-layer components block every user story.


## Phase 3: User Story US001 — Read a home timeline (Priority: P1) 🎯 MVP

**Independent Test**: A signed-in user with at least 10 followed authors sees a paginated home feed sorted by recency.

### Tests for User Story US001 (OPTIONAL — write first)

- [ ] T-TEST-US001-1 Author BDD scenarios that map to acceptance scenarios for US001.
- [ ] T-TEST-US001-2 Surface TDD specs for the components this story touches: `user-account`, `session`, `verification-badge`, `follow-edge`.

### Implementation for User Story US001

> No agent tasks linked to US001. Add `userStoryIds: ["US001"]` on the relevant `agentTasks` entries.

## Phase 4: User Story US002 — Compose and publish a post (Priority: P1) 🎯 MVP

**Independent Test**: An author composes a 140-char post with one image and sees it on the home timeline of a followed reader within 2s.

### Tests for User Story US002 (OPTIONAL — write first)

- [ ] T-TEST-US002-1 Author BDD scenarios that map to acceptance scenarios for US002.
- [ ] T-TEST-US002-2 Surface TDD specs for the components this story touches: `user-account`, `session`, `verification-badge`, `follow-edge`.

### Implementation for User Story US002

> No agent tasks linked to US002. Add `userStoryIds: ["US002"]` on the relevant `agentTasks` entries.

## Phase 5: User Story US003 — Send a direct message (Priority: P2)

**Independent Test**: A user creates a new conversation with another user, sends a message, and the recipient sees the notification fire and the message appear in their inbox within 1s.

### Tests for User Story US003 (OPTIONAL — write first)

- [ ] T-TEST-US003-1 Author BDD scenarios that map to acceptance scenarios for US003.
- [ ] T-TEST-US003-2 Surface TDD specs for the components this story touches: `user-account`, `session`, `verification-badge`, `follow-edge`.

### Implementation for User Story US003

> No agent tasks linked to US003. Add `userStoryIds: ["US003"]` on the relevant `agentTasks` entries.

## Phase 6: User Story US004 — Search public posts (Priority: P3)

**Independent Test**: A visitor enters a known keyword and the search returns a paginated list of public posts sorted by relevance.

### Tests for User Story US004 (OPTIONAL — write first)

- [ ] T-TEST-US004-1 Author BDD scenarios that map to acceptance scenarios for US004.
- [ ] T-TEST-US004-2 Surface TDD specs for the components this story touches: `user-account`, `session`, `verification-badge`, `follow-edge`.

### Implementation for User Story US004

> No agent tasks linked to US004. Add `userStoryIds: ["US004"]` on the relevant `agentTasks` entries.

## Phase 7: Polish & Cross-Cutting Concerns

- [ ] Cross-layer integration tests pass (see per-layer `tddSpec.integrationTests`).
- [ ] Run audit, regenerate diagrams if any failed, and re-export.

## Dependencies & Execution Order

- Phase 1 (Setup) blocks every later phase.
- Phase 2 (Foundational) blocks every User Story phase.
- User Story phases (4 of them) can run sequentially or in parallel once Phase 2 completes.

## Parallel Example

```text
# Within a User Story phase:
T101 [P] (US001) Build the Post aggregate
T102 [P] (US001) Build the PostRepository
T103     (US001) Wire the Post REST controller (depends on T101, T102)
```

## Implementation Strategy

- MVP first: ship Phase 1 → Phase 2 → first P1 User Story. Validate before moving on.
- Incremental delivery: each completed User Story phase is independently shippable.
- Tests-first: write BDD scenarios in the `Tests for User Story` sub-phase before the implementation sub-phase.

## Notes

- `[P]` tasks can run in parallel only when their `fileHints` AND `userStoryIds` are disjoint from every other in-flight task.
- `[USn]` markers cross-link the task to a User Story in `spec.md`.