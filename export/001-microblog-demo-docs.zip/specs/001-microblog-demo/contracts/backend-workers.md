# Backend Workers — Contracts

> Public surface for the **backend-workers** layer. Sourced from each component's `publicApi`, `inputs`, and `outputs`.

## User Account

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/identity/domain/user_account.py`

Aggregates a user identity with handles, verification, and profile metadata.

**Public API:**

- `register`
- `verify`
- `deactivate`
- `updateProfile`

**Inputs:**

- RegisterCommand
- VerifyCommand
- DeactivateCommand

**Outputs:**

- UserAccount
- UserAccount.persisted.v1
- UserAccount.verified.v1

## Session

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/identity/domain/session.py`

Tracks an authenticated session bound to a user and a refresh-token id.

**Public API:**

- `issue`
- `revoke`
- `lookup`

**Inputs:**

- IssueCommand
- RevokeCommand

**Outputs:**

- Session
- Session.issued.v1
- Session.revoked.v1

## Verification Badge

**Type:** `domain-service` · **Layer:** `domain` · **File:** `backend/src/identity/domain/verification_badge.py`

Owns the verified-badge lifecycle decoupled from the user account.

**Public API:**

- `evaluate`
- `grant`
- `revoke`

**Inputs:**

- UserAccountId
- Eligibility signals

**Outputs:**

- BadgeDecision
- Badge.granted.v1
- Badge.revoked.v1

## Follow Edge

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/social_graph/domain/follow_edge.py`

Aggregates a directed follow relationship between two users.

**Public API:**

- `follow`
- `unfollow`
- `isFollowing`
- `listFollowers`

**Inputs:**

- FollowCommand
- UnfollowCommand

**Outputs:**

- FollowEdge
- graph.followed.v1
- graph.unfollowed.v1

## Block List

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/social_graph/domain/block_list.py`

Tracks which users have blocked the current user across all surfaces.

**Public API:**

- `block`
- `unblock`
- `isBlockedBy`

**Inputs:**

- BlockCommand
- UnblockCommand

**Outputs:**

- BlockList
- graph.blocked.v1
- graph.unblocked.v1

## Mute List

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/social_graph/domain/mute_list.py`

Maintains a per-user mute list that hides posts without unfollowing.

**Public API:**

- `mute`
- `unmute`
- `isMuted`

**Inputs:**

- MuteCommand
- UnmuteCommand

**Outputs:**

- MuteList
- graph.muted.v1
- graph.unmuted.v1

## Post

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/posts/domain/aggregates/post.py`

Aggregate that owns a post, its body, and lifecycle status.

**Public API:**

- `publish`
- `edit`
- `delete`
- `reply`

**Inputs:**

- PublishPostCommand
- EditPostCommand
- DeletePostCommand

**Outputs:**

- Post
- post.published.v1
- post.edited.v1
- post.deleted.v1

## Thread

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/posts/domain/aggregates/thread.py`

Composite aggregate that orders replies into a self-thread.

**Public API:**

- `append`
- `close`
- `list`

**Inputs:**

- AppendThreadPostCommand
- CloseThreadCommand

**Outputs:**

- Thread
- thread.appended.v1
- thread.closed.v1

## Media Attachment

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/posts/domain/aggregates/media_attachment.py`

Links a media variant to a post and enforces upload ordering.

**Public API:**

- `attach`
- `detach`
- `list`

**Inputs:**

- AttachMediaCommand
- DetachMediaCommand

**Outputs:**

- MediaAttachment
- media.attached.v1
- media.detached.v1

## Like

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/engagement/domain/aggregates/like.py`

Records a user liking a post and exposes undo.

**Public API:**

- `like`
- `unlike`
- `countFor`

**Inputs:**

- LikeCommand
- UnlikeCommand

**Outputs:**

- Like
- Engagement.recorded.v1
- Engagement.undone.v1

## Repost

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/engagement/domain/aggregates/repost.py`

Records a user reposting (reposting) a post.

**Public API:**

- `repost`
- `undo`
- `countFor`

**Inputs:**

- RepostCommand
- UndoRepostCommand

**Outputs:**

- Repost
- Engagement.recorded.v1
- Engagement.undone.v1

## Bookmark

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/engagement/domain/aggregates/bookmark.py`

Stores a private per-user bookmark for a post.

**Public API:**

- `bookmark`
- `unbookmark`
- `listForUser`

**Inputs:**

- BookmarkCommand
- UnbookmarkCommand

**Outputs:**

- Bookmark
- Engagement.recorded.v1
- Engagement.undone.v1

## Media Upload

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/media/domain/aggregates/media_upload.py`

Tracks the lifecycle of a single media upload from request to ready variants.

**Public API:**

- `requestUpload`
- `markUploaded`
- `markProcessed`

**Inputs:**

- RequestUploadCommand
- MarkUploadedCommand
- MarkProcessedCommand

**Outputs:**

- MediaUpload
- Media.uploaded.v1
- Media.processed.v1

## Media Processor

**Type:** `service` · **Layer:** `application` · **File:** `workers/src/media_jobs/transcoder.py`

Background service that transcodes uploaded media into variants.

**Public API:**

- `processUpload`
- `handleFailure`

**Inputs:**

- Media.uploaded.v1

**Outputs:**

- Media.processed.v1
- Media.failed.v1

## Media Variant

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/media/domain/aggregates/media_variant.py`

Represents a single transcoded variant (thumbnail, medium, full, HLS).

**Public API:**

- `upsert`
- `cdnUrlFor`

**Inputs:**

- UpsertVariantCommand

**Outputs:**

- MediaVariant
- MediaVariant.ready.v1

## Search Index

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `backend/src/search/infrastructure/opensearch_client.py`

Maintains the OpenSearch index of published posts.

**Public API:**

- `indexPost`
- `removePost`
- `search`

**Inputs:**

- Post.published.v1
- Post.deleted.v1

**Outputs:**

- Indexed posts
- Search results

## Trending Calculator

**Type:** `domain-service` · **Layer:** `domain` · **File:** `workers/src/search_index/trending_calculator.py`

Computes trending hashtags and topics over a rolling 24-hour window.

**Public API:**

- `recompute`
- `topN`

**Inputs:**

- Engagement.recorded.v1

**Outputs:**

- TrendingItem list

## Indexing Queue

**Type:** `service` · **Layer:** `application` · **File:** `workers/src/search_index/indexer.py`

Buffers index events and flushes them to OpenSearch in batches.

**Public API:**

- `enqueue`
- `flush`
- `close`

**Inputs:**

- IndexEvent list

**Outputs:**

- OpenSearch bulk response

## Notification

**Type:** `aggregate` · **Layer:** `domain` · **File:** `backend/src/notifications/domain/aggregates/notification.py`

Aggregates a per-user notification entry.

**Public API:**

- `create`
- `markRead`
- `markAllRead`
- `listForUser`

**Inputs:**

- CreateNotificationCommand
- MarkReadCommand

**Outputs:**

- Notification
- Notification.created.v1
- Notification.read.v1

## Mention Detector

**Type:** `domain-service` · **Layer:** `domain` · **File:** `workers/src/notifications/mention_detector.py`

Parses post bodies and DMs to find mentioned handles.

**Public API:**

- `detectMentions`
- `resolveHandles`

**Inputs:**

- Post body or DM body

**Outputs:**

- Mention list

## Fan-out Scheduler

**Type:** `service` · **Layer:** `application` · **File:** `workers/src/notifications/fanout_scheduler.py`

Decides when and how to fan out a notification to push and WS channels.

**Public API:**

- `schedule`
- `cancel`
- `flush`

**Inputs:**

- Notification.created.v1

**Outputs:**

- Notification.fanout.v1
