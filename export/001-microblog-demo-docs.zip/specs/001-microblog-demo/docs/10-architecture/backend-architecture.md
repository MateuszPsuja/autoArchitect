# Backend (Python) Architecture

**Layer ID**: `backend` · **Spec**: docs/10-architecture/backend-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

FastAPI service exposing REST and WebSocket APIs for the public reader and the staff console. Follows Clean Architecture (domain, application, infrastructure, interfaces) with DDD aggregates per bounded context. The Post aggregate, repositories, and use cases implement the publish flow; an outbox table feeds the workers.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | PostgreSQL 16 via SQLAlchemy 2 async; outbox table for domain events |
| **Target Platform** | Linux server (Python 3.11); containerised via Docker |
| **Performance Goals** | p95 GET api timelines home under 200ms; p95 POST post under 400ms |
| **Constraints** | Domain layer MUST have zero framework imports; all status transitions MUST be idempotent and emit exactly one domain event |
| **Scale / Scope** | 1M MAU readers, 50k posts per minute at peak, 200 RPS on read endpoints |

## Constitution Check

- ✅ Strict type checking on all Pydantic schemas (extra forbid)
- ✅ Unit plus integration tests per use case (at least 2 unit, at least 1 integration)
- ✅ Domain layer has zero framework imports (no FastAPI, SQLAlchemy, or Redis)
- ✅ Outbox pattern used for every domain event
- ✅ All authorization checks live in the application layer, not routes

## Project Structure

### Documentation (this layer)

```text
docs/30-backend/
docs/30-backend/social-graph/
docs/30-backend/social-graph/overview.md
docs/30-backend/social-graph/domain/aggregates.md
docs/30-backend/social-graph/domain/domain-services.md
docs/30-backend/social-graph/application/use-cases.md
docs/30-backend/social-graph/infrastructure/repositories.md
docs/30-backend/posts/
docs/30-backend/posts/overview.md
docs/30-backend/posts/domain/aggregates.md
docs/30-backend/posts/domain/domain-services.md
docs/30-backend/posts/application/use-cases.md
docs/30-backend/posts/infrastructure/repositories.md
docs/30-backend/engagement/
docs/30-backend/engagement/overview.md
docs/30-backend/engagement/domain/aggregates.md
docs/30-backend/engagement/domain/domain-services.md
docs/30-backend/engagement/application/use-cases.md
docs/30-backend/engagement/infrastructure/repositories.md
docs/30-backend/media/
docs/30-backend/media/overview.md
docs/30-backend/media/domain/aggregates.md
docs/30-backend/media/domain/domain-services.md
docs/30-backend/media/application/use-cases.md
docs/30-backend/media/infrastructure/repositories.md
docs/30-backend/search/
docs/30-backend/search/overview.md
docs/30-backend/search/domain/aggregates.md
docs/30-backend/search/domain/domain-services.md
docs/30-backend/search/application/use-cases.md
docs/30-backend/search/infrastructure/repositories.md
docs/30-backend/notifications/
docs/30-backend/notifications/overview.md
docs/30-backend/notifications/domain/aggregates.md
docs/30-backend/notifications/domain/domain-services.md
docs/30-backend/notifications/application/use-cases.md
docs/30-backend/notifications/infrastructure/repositories.md
```

### Source Code

```text
backend/
├── pyproject.toml
├── alembic.ini
├── Dockerfile
├── src/
│   ├── main.py                       # FastAPI composition root
│   ├── app.py                        # create_app with middleware and routers
│   ├── config.py                     # pydantic-settings
│   ├── observability.py              # OpenTelemetry init
│   ├── shared/
│   │   ├── events.py                 # typed domain event catalog
│   │   ├── exceptions.py
│   │   └── middleware.py
│   ├── identity/
│   │   └── domain/
│   │       ├── user_account.py
│   │       └── session.py
│   ├── posts/
│   │   ├── domain/aggregates/post.py
│   │   ├── application/use_cases/publish_post.py
│   │   ├── infrastructure/repositories/postgres_post_repository.py
│   │   └── interfaces/routes.py
│   ├── engagement/
│   │   ├── domain/aggregates/like.py
│   │   ├── application/use_cases/record_engagement.py
│   │   └── infrastructure/repositories/engagement_repository.py
│   ├── social_graph/
│   │   ├── domain/aggregates/follow_edge.py
│   │   ├── application/use_cases/follow.py
│   │   └── infrastructure/repositories/social_graph_repository.py
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| Outbox table for domain events | Guarantees at-least-once delivery to workers without dual-write inconsistencies | Direct synchronous call from request handler to worker - would lose events on partial failure and tightly couples the request to the worker runtime |
| Repository pattern plus Unit of Work per request | Keeps the use-case layer testable without SQLAlchemy sessions and isolates the aggregate from persistence | Use cases calling SQLAlchemy sessions directly - couples domain logic to a specific ORM and makes unit tests slow or flaky |

## Domain Areas

| Domain | Layer | Description |
|---|---|---|
| [Social Graph](../30-backend/social-graph/overview.md) | backend | Backend context for follow, block, and mute relationships. |
| [Posts and Threads](../30-backend/posts/overview.md) | backend | Backend context for the post, thread, and media-attachment aggregates. |
| [Engagement](../30-backend/engagement/overview.md) | backend | Backend context for likes, reposts, and bookmarks. |
| [Media](../30-backend/media/overview.md) | backend | Backend context for media uploads, variants, and transcoding. |
| [Search and Trending](../30-backend/search/overview.md) | backend | Backend context for indexing published posts and computing trending topics. |
| [Notifications](../30-backend/notifications/overview.md) | backend | Backend context for in-app notifications with push fan-out. |
