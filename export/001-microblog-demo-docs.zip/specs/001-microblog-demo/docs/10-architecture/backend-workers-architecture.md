# Backend Workers Architecture

**Layer ID**: `backend-workers` · **Spec**: docs/10-architecture/backend-workers-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

ARQ-based worker processes for fan-out, notifications, indexing, and media transcoding. Each worker consumes a single Redis stream, deduplicates by event id, and writes back to PostgreSQL, Redis, S3, or OpenSearch. Workers expose a health endpoint and emit OpenTelemetry spans per event.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | Redis Streams for input; PostgreSQL, S3, and OpenSearch for output |
| **Target Platform** | Linux containers (amd64 plus arm64) |
| **Performance Goals** | Fan-out dispatcher processes 10k events per minute per replica with p95 latency under 1s |
| **Constraints** | Workers must be idempotent on event id; transient errors retry with backoff up to 5 times |
| **Scale / Scope** | 1k concurrent jobs per replica, 6 worker kinds, 3 replicas each |

## Constitution Check

- ✅ Every worker job is idempotent on its event id
- ✅ Workers never call the API directly; they consume events from Redis Streams
- ✅ Every job emits an OpenTelemetry span with the event id as an attribute
- ✅ Failed jobs go to a per-stream DLQ after 5 retries
- ✅ Worker processes expose a /healthz endpoint

## Project Structure

### Documentation (this layer)

```text
docs/40-backend-workers/
```

### Source Code

```text
workers/
├── pyproject.toml
├── Dockerfile
├── src/
│   ├── main.py                      # ARQ worker entrypoint
│   ├── settings.py
│   ├── fan_out/
│   │   ├── dispatcher.py
│   │   ├── materializer.py
│   │   └── timeline_cache.py
│   ├── notifications/
│   │   ├── mention_detector.py
│   │   └── fanout_scheduler.py
│   ├── search_index/
│   │   ├── indexer.py
│   │   └── trending_calculator.py
│   ├── media_jobs/
│   │   ├── transcoder.py
│   │   └── variants.py
│   └── infra/
│       ├── streams.py
│       └── outbox_consumer.py
├── tests/
│   ├── unit/
│   └── integration/
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| Redis Streams consumer groups | Native backpressure, replay, and per-stream DLQ for at-least-once delivery | Polling a Postgres outbox table - doubles DB load and makes replays expensive |
