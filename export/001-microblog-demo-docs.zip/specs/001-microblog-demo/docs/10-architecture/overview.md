# Architecture Overview

## Design Principles

- **Domain-Driven Design (DDD):** Bounded contexts align code ownership with business domains.
- **Clean Architecture:** Dependencies point inward; domain layer has zero external dependencies.
- **Test-Driven Development (TDD):** Each component ships with BDD-style Given/When/Then specifications.

## Layers

| Layer | Responsibility | Pattern |
|---|---|---|
| Backend (Python) | FastAPI service exposing REST and WebSocket APIs for the public reader and the staff console, backed by PostgreSQL, Redis, S3, and OpenSearch. | Domain-Driven Design (aggregates, bounded contexts), Clean Architecture (domain, application, infrastructure, interfaces), Outbox pattern for reliable domain events, Repository pattern with async sessions, Hexagonal ports and adapters |
| Backend Workers | ARQ-based worker processes for fan-out, notifications, indexing, and media transcoding. | Idempotent consumers keyed by event id, Stream consumer groups with backoff, Batch processing per chunk, Coalescing for fan-out notifications |
| Frontend (Angular) | Angular 17 standalone-component SPA for timelines, profiles, threads, DMs, and notifications. | Standalone components, no NgModules, Signal-first state via NgRx signalStore; mutate only through patchState, Lazy-loaded feature shells, Route guards for authenticated and staff areas, Strict runtime schema validation for HTTP responses |
| Shared Contracts | Schemas, types, and event catalogs shared between the backend, workers, and the frontend. | Single source of truth per contract (Zod on the client, Pydantic on the server), Generated TypeScript types via z.infer, Versioned event names with semantic suffixes (.v1) |
| Infrastructure | Containerised runtime, IaC, observability, and CI/CD for the whole stack. | 12-factor configuration via environment variables, OpenTelemetry traces and metrics on every request and worker job, Migrations run as a separate one-shot job, not on app start, GitOps via Argo CD with image-digest pinning |

## ADR Index

- [ADR-0001 — Fan-out on write for home timelines](../20-decisions/adr-001-fan-out-on-write-for-home-timelines.md) *(accepted)*
- [ADR-0002 — PostgreSQL plus Redis for the primary store](../20-decisions/adr-002-postgresql-plus-redis-for-the-primary-store.md) *(accepted)*
- [ADR-0003 — OpenSearch for full-text and trending](../20-decisions/adr-003-opensearch-for-full-text-and-trending.md) *(accepted)*
- [ADR-0004 — S3-compatible object storage plus CDN for media](../20-decisions/adr-004-s3-compatible-object-storage-plus-cdn-for-media.md) *(accepted)*
- [ADR-0005 — NgRx signalStore for frontend state](../20-decisions/adr-005-ngrx-signalstore-for-frontend-state.md) *(accepted)*
- [ADR-0006 — Zod schemas shared between frontend and backend](../20-decisions/adr-006-zod-schemas-shared-between-frontend-and-backend.md) *(accepted)*
