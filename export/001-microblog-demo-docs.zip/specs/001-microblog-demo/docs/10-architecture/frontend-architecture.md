# Frontend (Angular) Architecture

**Layer ID**: `frontend` · **Spec**: docs/10-architecture/frontend-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

Angular 17 standalone-component SPA with lazy-loaded feature shells (Home, Profile, Thread, Explore, DMs, Notifications, Preferences). All HTTP responses are validated with Zod before reaching components; state is owned by NgRx signalStores mutated exclusively via patchState. Authenticated routes are guarded by an AuthGuard; staff routes by a StaffGuard.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | Browser memory only; persistence happens via the backend |
| **Target Platform** | Browser (Chrome 110+, Firefox 110+, Safari 16+) |
| **Performance Goals** | TTI under 3s on a cold cache; largest-contentful-paint under 2s on 4G |
| **Constraints** | No BehaviorSubject or ReplaySubject - use signals only. Mutate signalStore state only via patchState inside withMethods. All HTTP responses must be Zod-validated before reaching components. |
| **Scale / Scope** | 1M MAU, 50k posts per minute, 10k signed-in DM sessions per day |

## Constitution Check

- ✅ Strict TypeScript with noImplicitAny and strictNullChecks
- ✅ Standalone components only - no NgModule declarations
- ✅ Mutate signalStore state only via patchState inside withMethods
- ✅ All HTTP responses validated with a Zod schema before reaching components
- ✅ Lazy-load every top-level feature via loadComponent or loadChildren

## Project Structure

### Documentation (this layer)

```text
docs/50-frontend/
```

### Source Code

```text
frontend/
├── angular.json
├── package.json
├── tsconfig.json
├── src/
│   ├── main.ts
│   ├── index.html
│   ├── styles.scss
│   └── app/
│       ├── app.ts                   # bootstrapApplication
│       ├── app.config.ts            # providers router http interceptors
│       ├── app.routes.ts            # top-level routes (lazy)
│       ├── core/
│       │   ├── api/
│       │   │   ├── microblog.api.ts
│       │   │   ├── media.api.ts
│       │   │   ├── dm.api.ts
│       │   │   └── notifications.api.ts
│       │   ├── stores/
│       │   │   ├── home-feed.store.ts
│       │   │   ├── composer.store.ts
│       │   │   ├── profile.store.ts
│       │   │   ├── notifications.store.ts
│       │   │   └── dm.store.ts
│       │   ├── guards/auth.guard.ts
│       │   └── interceptors/auth.interceptor.ts
│       ├── features/
│       │   ├── home/                # lazy public reader
│       │   ├── profile/             # lazy public reader
│       │   ├── thread/              # lazy public reader
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| NgRx signalStore for feature state (vs. plain service plus signals) | Standardises selectors, methods, and patchState boundaries so multiple components can subscribe without cross-feature coupling | Plain service exposing writable signals - would let any consumer mutate state and removes the audit boundary between read and write |
| Zod schema validation for every HTTP response | Catches upstream contract drift at the seam where the SPA meets the backend instead of crashing a component at render time | Trust the typed response - leaves the SPA exposed to silent runtime errors when the backend ships a breaking change |
