# Infrastructure Architecture

**Layer ID**: `infra` · **Spec**: docs/10-architecture/infra-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

Containerised runtime, IaC, observability, and CI/CD for the whole stack. Local development runs the full dependency graph via docker compose; production runs on EKS managed by Argo CD with image digests pinned to the commit SHA. Every request and worker job emits OpenTelemetry traces plus metrics to a central collector, and migrations run as a separate one-shot job, not on app start.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | GitHub Actions cache + container registry (tagged by digest) |
| **Target Platform** | Linux containers (amd64 plus arm64) on Kubernetes |
| **Performance Goals** | CI build under 12 minutes; production deploy under 5 minutes; image pull under 30 seconds on a warm cluster |
| **Constraints** | Pin base image digests, not tags. Migrations run as a separate one-shot job, not on app start. Every alert links to a runbook. |
| **Scale / Scope** | 3 environments (dev, staging, prod), ~80 services, ~20TB PostgreSQL |

## Constitution Check

- ✅ All images pinned by digest, not tag
- ✅ Migrations run as a separate one-shot job, not on app start
- ✅ OpenTelemetry traces and metrics exported on every request and worker job
- ✅ Every Prometheus alert links to a runbook in docs/runbooks/
- ✅ CI fails on any uncommitted generated artefact (OpenAPI, TS types)

## Project Structure

### Documentation (this layer)

```text
docs/70-infra/
```

### Source Code

```text
infra/
├── terraform/
│   ├── modules/
│   │   ├── vpc/
│   │   ├── eks/
│   │   ├── rds/
│   │   └── elasticache/
│   └── envs/
│       ├── dev/
│       ├── staging/
│       └── prod/
├── deploy/
│   ├── backend/
│   ├── workers/
│   └── frontend/
├── observability/
│   ├── otel-collector-values.yaml
│   ├── prometheus-rules.yaml
│   └── grafana/dashboards/
├── ci/
│   ├── backend-pipeline.yml
│   ├── frontend-pipeline.yml
│   ├── workers-pipeline.yml
│   └── e2e-pipeline.yml
└── docs/runbooks/
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| OpenTelemetry collector plus Prometheus plus Grafana stack | Single pane of glass across FastAPI, Angular SPA, and ARQ workers | Vendor-specific APM (NewRelic or Datadog) - high cost and lock-in for a single-team project |
| Image digests instead of mutable tags | Reproducible rollbacks and zero ambiguity between what is in staging and what is in prod | latest or version tags - caused a known incident on a previous project where a base image was re-tagged mid-deploy |
