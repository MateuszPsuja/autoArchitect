# Shared Contracts Architecture

**Layer ID**: `shared` · **Spec**: docs/10-architecture/shared-architecture.md · **Generated**: 2026-09-15T00:00:00.000Z

## Summary

Single source of truth for every API request, response, and domain event that crosses the backend, workers, and frontend boundary. Schemas are written once in Zod (frontend) and mirrored in Pydantic (backend), so TypeScript types are generated via z.infer and the OpenAPI 3.1 spec is generated from the Zod root schemas. Domain events are catalogued in AsyncAPI 2 with a .v1 suffix that bumps on breaking payload changes.

## Technical Context

| Field | Value |
|---|---|
| **Storage** | Source files only (CI-run codegen + repo-committed artefacts) |
| **Target Platform** | CI-run codegen + repo-committed artefacts |
| **Performance Goals** | Codegen completes in under 30 seconds on CI |
| **Constraints** | No hand-written TypeScript request or response types - every type is z.infer. No breaking changes without a .v2 suffix on the event name. |
| **Scale / Scope** | ~80 schemas, ~30 events across 12 bounded contexts |

## Constitution Check

- ✅ Zod schema is the source of truth; TypeScript types and Pydantic models are generated
- ✅ Every domain event is declared in the AsyncAPI catalogue with a versioned name
- ✅ OpenAPI 3.1 spec is regenerated on every CI run and committed
- ✅ Breaking payload changes require a new .vN suffix on the event name
- ✅ Schemas live in shared/schemas and are imported by both backend and frontend

## Project Structure

### Documentation (this layer)

```text
docs/60-shared/
docs/60-shared/identity/
docs/60-shared/identity/overview.md
docs/60-shared/identity/domain/aggregates.md
docs/60-shared/identity/domain/domain-services.md
docs/60-shared/identity/application/use-cases.md
docs/60-shared/identity/infrastructure/repositories.md
```

### Source Code

```text
shared/
├── schemas/
│   ├── posts.ts           # Zod root for post payloads
│   ├── engagement.ts       # like repost bookmark commands
│   ├── identity.ts         # UserSummary and Session
│   ├── dm.ts               # DmMessage and Conversation
│   ├── events.ts           # AsyncAPI aligned event schemas
│   └── pagination.ts       # Page T and Cursor
├── python/
│   ├── posts.py           # Pydantic mirror of posts.ts
│   ├── engagement.py
│   ├── identity.py
│   ├── dm.py
│   └── events.py
├── openapi.yaml            # generated and committed
└── asyncapi.yaml           # generated and committed
```

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|---|---|---|
| Maintaining schema parity across Zod and Pydantic | Lets the backend and frontend evolve independently without silent contract drift | Hand-written Pydantic and hand-written TypeScript types - drifts within weeks and causes runtime schema drift errors in the SPA |

## Domain Areas

| Domain | Layer | Description |
|---|---|---|
| [Identity and Access](../60-shared/identity/overview.md) | shared | Shared context for user accounts, sessions, and verification badges. |
