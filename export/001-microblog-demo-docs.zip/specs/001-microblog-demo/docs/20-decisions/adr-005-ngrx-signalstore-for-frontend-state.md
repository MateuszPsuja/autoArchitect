# ADR-0005 — NgRx signalStore for frontend state

**Status:** `accepted`

## Context

We need fast, signal-based state management with a clear audit boundary between reads and writes.

## Decision

Standalone Angular components only, NgRx signalStore for feature state, mutate only via patchState inside withMethods.

## Consequences

- Components cannot mutate state directly; they call store methods.
- Schema validation runs at the API service boundary before reaching stores.
- Smaller bundles and clearer feature ownership.
