# ADR-0004 — S3-compatible object storage plus CDN for media

**Status:** `accepted`

## Context

Media uploads include images up to 50MB and videos up to 500MB and must be served with low latency worldwide.

## Decision

Store raw and transcoded media in S3-compatible object storage and serve variants through a CDN.

## Consequences

- Presigned URLs keep uploads off the API server.
- Variant generation is idempotent on upload id.
- CDN cache invalidation is required when a media variant is moderated.
