# ADR-0001 — Fan-out on write for home timelines

**Status:** `accepted`

## Context

Home timelines must render in under 200ms p95 from a warm cache. Fan-out on read would force a join over follow edges on every read.

## Decision

Use fan-out on write via a Redis stream and a dedicated worker that materialises per-user timeline rows and caches.

## Consequences

- Hot authors (verified accounts) require sharded workers to keep up.
- Unfollow requires dematerialisation; dematerialisation is implemented by the worker on graph.unfollowed.v1.
- Read latency drops from multi-second joins to sub-50ms cache reads.
