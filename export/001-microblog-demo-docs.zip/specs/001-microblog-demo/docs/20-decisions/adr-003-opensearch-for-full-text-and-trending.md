# ADR-0003 — OpenSearch for full-text and trending

**Status:** `accepted`

## Context

Typeahead and full-text search must return results in under 100ms p95 across tens of millions of posts.

## Decision

Index published posts into OpenSearch with a dedicated indexer worker and a buffered bulk request strategy.

## Consequences

- A deleted post is removed from the index within 5 seconds.
- Trending snapshots are recomputed from the index with a 60-second TTL.
- Index failures fall back to a Postgres full-text search query path.
