# ADR-0006 — Zod schemas shared between frontend and backend

**Status:** `accepted`

## Context

Type drift between the Angular SPA and the FastAPI backend has caused production schema_drift errors.

## Decision

Write every API contract once in Zod (frontend) and mirror it in Pydantic (backend); generate TypeScript types via z.infer and OpenAPI from Zod.

## Consequences

- No hand-written TypeScript request or response types.
- Schema changes require a codegen run on CI; CI fails on uncommitted generated artefacts.
- Breaking changes require a new .vN suffix on the event name.
