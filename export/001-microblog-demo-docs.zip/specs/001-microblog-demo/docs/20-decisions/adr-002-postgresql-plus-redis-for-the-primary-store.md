# ADR-0002 — PostgreSQL plus Redis for the primary store

**Status:** `accepted`

## Context

We need strong consistency for posts, follows, and engagement with sub-millisecond read latency for hot timelines.

## Decision

Use PostgreSQL 16 as the system of record and Redis 7 for the hot-path timeline cache and Redis Streams.

## Consequences

- Postgres handles transactional outbox writes for fan-out reliability.
- Redis is treated as a cache; a cold cache falls back to Postgres reads.
- Redis failover can lose up to 5 seconds of cache writes; reads recover from Postgres.
