# System Overview

## Purpose
Deliver a fast, accessible microblog platform with real-time fan-out timelines, threaded conversations, media uploads, search, and direct messages.

## Context
Replaces a legacy single-server blog with a distributed microblog: a Python FastAPI backend, dedicated fan-out workers, an Angular SPA, and a managed Postgres plus Redis plus OpenSearch stack.

## Key Actors
- Anonymous Reader
- Authenticated Reader
- Author
- Moderator (staff)
- Admin (staff)

## Constraints
- Public timelines must render in under 2 seconds on 4G.
- Fan-out latency p95 under 1 second from publish to follower timeline.
- Direct messages must be encrypted at rest with envelope encryption.

## Non-Functional Requirements
- p95 home feed render under 1.5s on a warm cache.
- 99.9% availability for the read APIs.
- WCAG 2.1 AA compliance for all public pages.
- Zero PII in logs; structured logging with correlation IDs.
