# Bounded Context Map

## Bounded Contexts

### Identity and Access (`identity`)

**Layer:** shared

Manages user accounts, OAuth and OIDC logins, sessions, and the verification badge.

#### Ubiquitous Language

| Term | Definition |
|---|---|
| **UserAccount** | A registered user with a unique handle, a display name, and a verification state. |
| **Session** | A server-side record of an authenticated client bound to a refresh token id. |
| **VerificationBadge** | A per-user indicator of trust granted by the verification-badge domain service. |

### Social Graph (`social-graph`)

**Layer:** backend

Tracks follow, block, and mute relationships between users.

#### Ubiquitous Language

| Term | Definition |
|---|---|
| **FollowEdge** | A directed edge from follower to followee, with a creation timestamp. |
| **BlockList** | A per-user list of blocked accounts; blocks suppress interactions both ways. |
| **MuteList** | A per-user list of muted accounts; mutes hide posts but preserve follows. |

### Posts and Threads (`posts`)

**Layer:** backend

Owns the post, thread, and media-attachment aggregates and their read APIs.

#### Ubiquitous Language

| Term | Definition |
|---|---|
| **Post** | A short post with up to 280 characters and a lifecycle status. |
| **Thread** | An ordered self-reply chain anchored on a root post. |
| **MediaAttachment** | A reference from a post to one or more media variants owned by the media context. |

### Engagement (`engagement`)

**Layer:** backend

Records likes, reposts, and bookmarks per user-post pair.

#### Ubiquitous Language

| Term | Definition |
|---|---|
| **Like** | A user-post pair indicating a positive engagement. |
| **Repost** | A user-post pair indicating a repost; plain or quote. |
| **Bookmark** | A private per-user pointer to a post, ordered by recency. |

### Media (`media`)

**Layer:** backend

Owns media uploads, variants, and the transcoding worker.

#### Ubiquitous Language

| Term | Definition |
|---|---|
| **MediaUpload** | A single upload tracked from request through ready variants. |
| **MediaVariant** | A single transcoded rendition (thumbnail, medium, full, HLS). |
| **MediaProcessor** | A service that turns a raw upload into ready variants. |

### Search and Trending (`search`)

**Layer:** backend

Indexes published posts into OpenSearch and computes trending topics.

#### Ubiquitous Language

| Term | Definition |
|---|---|
| **SearchIndex** | The OpenSearch index of published posts with typeahead and full-text search. |
| **TrendingItem** | A ranked hashtag or topic over a rolling 24-hour window with half-life decay. |
| **IndexingQueue** | An in-memory buffer that batches index events to OpenSearch. |

### Notifications (`notifications`)

**Layer:** backend

Creates and dispatches in-app notifications with coalescing and push fan-out.

#### Ubiquitous Language

| Term | Definition |
|---|---|
| **Notification** | A per-user record describing a like, repost, mention, follow, or DM event. |
| **Mention** | A handle reference extracted from a post or DM body for notification purposes. |
| **FanoutScheduler** | A coalescing dispatcher that decides when to push a notification. |
