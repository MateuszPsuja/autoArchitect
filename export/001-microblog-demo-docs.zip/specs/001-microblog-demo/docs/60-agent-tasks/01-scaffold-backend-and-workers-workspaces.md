# Task 01: Scaffold backend and workers workspaces

Create the monorepo layout, backend Python package layout, workers Python package layout, and the docker compose stack.

## Acceptance Criteria

- [ ] backend contains a runnable FastAPI app with a health endpoint.
- [ ] workers contains a runnable ARQ worker entrypoint that consumes a sample stream.
- [ ] docker compose up brings up backend, workers, postgres, redis, and opensearch.

## Target Files

- `backend/src/main.py`
- `workers/src/main.py`
- `infra/docker/compose.yml`
