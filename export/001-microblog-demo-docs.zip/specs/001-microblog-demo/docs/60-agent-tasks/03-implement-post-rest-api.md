# Task 03: Implement Post REST API

Wire the Post use cases into FastAPI routes and validate requests with Pydantic schemas.

## Acceptance Criteria

- [ ] POST api posts returns 201 with the persisted PostDTO.
- [ ] GET api posts id returns a single post or 404.
- [ ] POST api posts requires an Idempotency-Key header.
- [ ] OpenAPI schema is generated and committed.

## Target Files

- `backend/src/posts/interfaces/routes.py`
- `shared/python/posts.py`
