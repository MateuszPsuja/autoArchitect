# Implementation Order

| # | Task | Files |
|---|---|---|
| [01](01-scaffold-backend-and-workers-workspaces.md) | Scaffold backend and workers workspaces | backend/src/main.py, workers/src/main.py, infra/docker/compose.yml |
| [02](02-implement-post-aggregate-and-repository.md) | Implement Post aggregate and repository | backend/src/posts/domain/aggregates/post.py, backend/src/posts/infrastructure/repositories/postgres_post_repository.py |
| [03](03-implement-post-rest-api.md) | Implement Post REST API | backend/src/posts/interfaces/routes.py, shared/python/posts.py |
| [04](04-implement-fan-out-dispatcher-worker.md) | Implement Fan-out Dispatcher worker | workers/src/fan_out/dispatcher.py, workers/src/fan_out/materializer.py, workers/src/fan_out/timeline_cache.py |
| [05](05-implement-search-indexer-worker.md) | Implement Search Indexer worker | workers/src/search_index/indexer.py, backend/src/search/infrastructure/opensearch_client.py |
| [06](06-implement-dm-conversation-and-message-aggregates.md) | Implement DM Conversation and Message aggregates | backend/src/direct_messages/domain/aggregates/conversation.py, backend/src/direct_messages/domain/aggregates/message.py, backend/src/direct_messages/domain/dm_encryption.py |
| [07](07-build-the-angular-home-feed-feature.md) | Build the Angular Home Feed feature | frontend/src/app/features/home/home-feed.component.ts, frontend/src/app/core/stores/home-feed.store.ts |
| [08](08-build-the-angular-post-composer-feature.md) | Build the Angular Post Composer feature | frontend/src/app/features/home/post-composer.component.ts, frontend/src/app/core/stores/composer.store.ts |
| [09](09-wire-the-notifications-panel-to-wss.md) | Wire the Notifications panel to WSS | frontend/src/app/features/notifications/notifications-panel.component.ts, frontend/src/app/core/ws/notifications.ws.ts, frontend/src/app/core/stores/notifications.store.ts |
| [10](10-implement-the-moderation-report-triage-service.md) | Implement the Moderation Report triage service | backend/src/moderation/domain/report_triage.py, backend/src/moderation/application/assign_report.py |
