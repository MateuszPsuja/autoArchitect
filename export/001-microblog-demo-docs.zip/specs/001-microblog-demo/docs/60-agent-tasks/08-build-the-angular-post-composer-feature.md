# Task 08: Build the Angular Post Composer feature

Implement the lazy-loaded Composer with character counter and media attachment.

## Acceptance Criteria

- [ ] Submit is disabled when the body is empty or invalid.
- [ ] Character counter turns red over 260 characters.
- [ ] Submit is debounced at 600ms.
- [ ] The store emits submit and resets the composer on 201 Created.

## Target Files

- `frontend/src/app/features/home/post-composer.component.ts`
- `frontend/src/app/core/stores/composer.store.ts`
