# Task 07: Build the Angular Home Feed feature

Implement the lazy-loaded Home Feed with virtual scrolling and pull-to-refresh.

## Acceptance Criteria

- [ ] HomeFeedComponent renders skeletons while the store is loading.
- [ ] loadMore is invoked on scroll near the bottom.
- [ ] TTI under 3 seconds on a warm cache.
- [ ] Vitest tests for the feature shell and the store pass.

## Target Files

- `frontend/src/app/features/home/home-feed.component.ts`
- `frontend/src/app/core/stores/home-feed.store.ts`
