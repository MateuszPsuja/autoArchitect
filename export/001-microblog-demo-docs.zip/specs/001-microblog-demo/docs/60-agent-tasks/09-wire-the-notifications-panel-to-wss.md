# Task 09: Wire the Notifications panel to WSS

Implement the Notifications panel with live WebSocket updates and mark-all-read.

## Acceptance Criteria

- [ ] Panel re-renders within 2 seconds of a new notification arriving via WSS.
- [ ] markAllRead is reflected in the UI without a full reload.
- [ ] Vitest tests for the store and the WSS subscription pass.

## Target Files

- `frontend/src/app/features/notifications/notifications-panel.component.ts`
- `frontend/src/app/core/ws/notifications.ws.ts`
- `frontend/src/app/core/stores/notifications.store.ts`
