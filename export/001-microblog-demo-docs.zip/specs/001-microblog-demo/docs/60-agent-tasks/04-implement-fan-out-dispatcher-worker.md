# Task 04: Implement Fan-out Dispatcher worker

Build the worker that consumes post.published.v1 from the Redis stream and materialises timeline rows.

## Acceptance Criteria

- [ ] Dispatcher batches inserts at 500 rows per chunk.
- [ ] Dispatcher is idempotent on event id.
- [ ] Dispatcher prepends to the per-user cache and trims to 800 entries.
- [ ] Tests under workers/tests/fan_out pass.

## Target Files

- `workers/src/fan_out/dispatcher.py`
- `workers/src/fan_out/materializer.py`
- `workers/src/fan_out/timeline_cache.py`
