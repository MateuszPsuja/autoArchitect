# Task 06: Implement DM Conversation and Message aggregates

Build the 1:1 Conversation and Message aggregates with envelope encryption at rest.

## Acceptance Criteria

- [ ] Conversation reuses an existing pair conversation on a duplicate create.
- [ ] Message assigns a monotonic sequence per conversation.
- [ ] delete is rejected after the 60-second window with WindowExpired.
- [ ] DmEncryption.encrypt then decrypt round-trips a plaintext body.

## Target Files

- `backend/src/direct_messages/domain/aggregates/conversation.py`
- `backend/src/direct_messages/domain/aggregates/message.py`
- `backend/src/direct_messages/domain/dm_encryption.py`
