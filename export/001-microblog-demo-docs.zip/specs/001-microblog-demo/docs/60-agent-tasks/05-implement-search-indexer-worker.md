# Task 05: Implement Search Indexer worker

Build the buffered OpenSearch indexer that consumes post.published.v1 and post.deleted.v1.

## Acceptance Criteria

- [ ] Indexer flushes at 500 items or 2 seconds, whichever first.
- [ ] Indexer removes deleted posts from the index within 5 seconds.
- [ ] Indexer retries failures with exponential backoff and DLQs after 5 attempts.

## Target Files

- `workers/src/search_index/indexer.py`
- `backend/src/search/infrastructure/opensearch_client.py`
