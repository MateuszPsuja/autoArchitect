# Task 02: Implement Post aggregate and repository

Build the Post aggregate, the PostRepository, and SQLAlchemy models for posts and outbox.

## Acceptance Criteria

- [ ] Post aggregate enforces all invariants from the DDD section.
- [ ] PostRepository round-trips a Post through PostgreSQL.
- [ ] publish writes both the post row and the outbox row in one transaction.
- [ ] Tests under backend/tests/posts pass.

## Target Files

- `backend/src/posts/domain/aggregates/post.py`
- `backend/src/posts/infrastructure/repositories/postgres_post_repository.py`
