# Task 10: Implement the Moderation Report triage service

Build the Report Triage service that assigns reports to the least-loaded moderator.

## Acceptance Criteria

- [ ] assignNext picks the moderator with the lowest open count among those with capacity.
- [ ] rebalance redistributes a disconnected moderator queue.
- [ ] Report.assigned.v1 is emitted on assignment.
- [ ] Tests under backend/tests/moderation pass.

## Target Files

- `backend/src/moderation/domain/report_triage.py`
- `backend/src/moderation/application/assign_report.py`
