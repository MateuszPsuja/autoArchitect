# Publish and Fan-out

Author posts a post; the fan-out worker materialises the post into follower timelines.

## Steps

1. Author opens the composer and clicks Post.
2. POST api posts persists the post and writes an outbox event.
3. PubSubBus publishes post.published.v1 to the fan-out stream.
4. Fan-out dispatcher loads followers and writes timeline rows.
5. Timeline cache prepends the new post id to each follower cache.
6. SPA home feed receives the new post on the next refresh.

## Domains Involved

- `posts`
- `social-graph`
