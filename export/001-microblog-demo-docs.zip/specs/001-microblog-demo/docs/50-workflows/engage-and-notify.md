# Engage and Notify

A like or mention triggers an in-app notification for the author.

## Steps

1. Reader likes a post from the home feed.
2. POST api likes persists the like and writes engagement.recorded.v1.
3. Notification worker detects the engagement and creates a notification.
4. Fan-out scheduler coalesces notifications and dispatches push.
5. The author sees the notification in the panel within 2 seconds.

## Domains Involved

- `engagement`
- `notifications`
