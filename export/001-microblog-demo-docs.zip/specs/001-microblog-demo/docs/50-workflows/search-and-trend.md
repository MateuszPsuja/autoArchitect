# Search and Trend

Search indexer ingests posts and the trending calculator updates the explore page.

## Steps

1. Fan-out emits post.published.v1 to the search indexer stream.
2. Indexing queue buffers posts up to 500 items or 2 seconds.
3. Indexing queue flushes a bulk request to OpenSearch.
4. Trending calculator applies half-life decay to engagements.
5. Explore page serves the top-N trending hashtags from the snapshot.

## Domains Involved

- `search`
- `posts`
