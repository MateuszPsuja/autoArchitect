# Upload and Process

Author attaches media to a post; the media worker produces variants.

## Steps

1. Author attaches an image in the composer.
2. Backend issues a presigned URL and stores the upload in pending status.
3. Client uploads to the presigned URL and calls markUploaded.
4. Media worker transcodes the upload into thumbnail, medium, and full variants.
5. Variants are uploaded to the object store and CDN URLs are returned.
6. The post publish flow attaches the variants and emits post.published.v1.

## Domains Involved

- `media`
- `posts`
