# Report and Enforce

Reader reports a post; a staff member triages and applies an enforcement action via the BlockList.

## Steps

1. Reader clicks Report on a post and submits a form.
2. POST api reports persists the report and emits report.created.v1.
3. Staff reviews the report and applies an enforcement action via the BlockList.
4. Backend persists the block and emits graph.blocked.v1.
5. The reported post is hidden from the reporter timelines.

## Domains Involved

- `social-graph`
- `posts`
