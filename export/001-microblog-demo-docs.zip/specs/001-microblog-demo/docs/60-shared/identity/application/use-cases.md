# Identity and Access — Application Use Cases

*No application-layer use cases defined.*
