# Identity and Access — Domain Services

## Verification Badge

**Type:** `domain-service` · **Layer:** `domain` · **File:** `backend/src/identity/domain/verification_badge.py`

### Purpose

Owns the verified-badge lifecycle decoupled from the user account.

### Responsibilities

- Decide whether a user is eligible for a verified badge.
- Issue and revoke badges without mutating user aggregates directly.
- Emit Badge.granted.v1 and Badge.revoked.v1 events.

### Public API

- `evaluate`
- `grant`
- `revoke`

### Inputs

- UserAccountId
- Eligibility signals

### Outputs

- BadgeDecision
- Badge.granted.v1
- Badge.revoked.v1

### Error Handling

Raise Ineligible when signals do not meet the policy.

### Acceptance Criteria

- [ ] A revoked badge cannot be granted again without a new eligibility signal.
- [ ] Grant is idempotent by user id.

### Out of Scope

- Visual badge rendering

### Test Specifications

#### Unit Tests

**Test: evaluate returns false for a brand-new user**

- Given: a user with zero followers and a fresh account
- When: evaluate is called
- Then: the result is not eligible

**Test: grant is idempotent**

- Given: a user with a granted badge
- When: grant is called again
- Then: no second Badge.granted.v1 event is emitted

#### Integration Tests

**Test: integration with the badge repository**

- Given: a TestBed with an in-memory badge store
- When: grant then revoke run sequentially
- Then: the badge is present then absent and two events are emitted

---
