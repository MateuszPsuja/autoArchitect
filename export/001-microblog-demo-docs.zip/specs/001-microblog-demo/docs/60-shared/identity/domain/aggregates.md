# Identity and Access — Aggregates & Domain Events

*No aggregates defined.*
