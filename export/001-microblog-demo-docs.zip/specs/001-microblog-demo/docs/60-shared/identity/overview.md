# Identity and Access

Shared context for user accounts, sessions, and verification badges.

**Layer:** `shared`
**Directory:** `backend/src/identity`

## Responsibilities

- Validate OAuth and OIDC bearer tokens against the configured identity provider.
- Resolve tokens to UserAccount aggregates with handle and verification state.
- Issue and revoke sessions on login, logout, and password reset.
