# Identity and Access — Infrastructure

*No infrastructure-layer components defined.*
