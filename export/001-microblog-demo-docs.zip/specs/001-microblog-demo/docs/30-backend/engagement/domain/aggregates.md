# Engagement — Aggregates & Domain Events

*No aggregates defined.*

## Domain Events Catalog

### engagement.recorded.v1

Raised when a user likes, reposts, or bookmarks a post.

**Triggered by:** Like.like() or Repost.repost() or Bookmark.bookmark()
**Handled by:** Fan-out Dispatcher, Analytics Aggregator

**Payload:**
- `userId`
- `postId`
- `kind`
- `recordedAt`
