# Engagement

Backend context for likes, reposts, and bookmarks.

**Layer:** `backend`
**Directory:** `backend/src/engagement`

## Responsibilities

- Reject duplicate likes and reposts from the same user.
- Maintain per-post engagement count snapshots.
- Emit engagement.recorded.v1 for downstream consumers.
