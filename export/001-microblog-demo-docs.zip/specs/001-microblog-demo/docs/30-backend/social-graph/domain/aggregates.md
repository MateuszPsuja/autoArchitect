# Social Graph — Aggregates & Domain Events

## FollowEdge

Aggregates a directed follow relationship between two users.

**Root Entity:** `FollowEdge`

### Invariants
- A user cannot follow themselves.
- A user cannot follow another user who has blocked them.

### Value Objects
- `FollowerId`
- `FolloweeId`
- `FollowTimestamp`

### Commands
- `follow`
- `unfollow`

### Domain Events Emitted
- `graph.followed.v1`
- `graph.unfollowed.v1`

## Domain Events Catalog

### graph.followed.v1

Raised when a user follows another user.

**Triggered by:** FollowEdge.follow()
**Handled by:** Fan-out Dispatcher

**Payload:**
- `followerId`
- `followeeId`
- `followedAt`
