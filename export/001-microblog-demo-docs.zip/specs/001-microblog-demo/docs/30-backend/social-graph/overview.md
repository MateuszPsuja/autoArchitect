# Social Graph

Backend context for follow, block, and mute relationships.

**Layer:** `backend`
**Directory:** `backend/src/social_graph`

## Responsibilities

- Enforce self-follow rejection on the FollowEdge aggregate.
- Track block edges and hide blocked authors from timelines.
- Track mute edges without breaking follow relationships.
