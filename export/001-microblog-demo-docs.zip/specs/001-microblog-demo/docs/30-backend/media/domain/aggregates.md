# Media — Aggregates & Domain Events

*No aggregates defined.*

## Domain Events Catalog

### media.processed.v1

Raised when all variants for an upload are ready.

**Triggered by:** MediaProcessor.processUpload()
**Handled by:** Search Indexer

**Payload:**
- `uploadId`
- `variants`
- `processedAt`
