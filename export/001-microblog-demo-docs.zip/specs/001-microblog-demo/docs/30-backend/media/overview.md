# Media

Backend context for media uploads, variants, and transcoding.

**Layer:** `backend`
**Directory:** `backend/src/media`

## Responsibilities

- Issue presigned URLs for client uploads.
- Track upload status from requested through ready.
- Transcode images and videos into CDN-ready variants.
