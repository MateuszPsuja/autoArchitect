# Media — Application Use Cases

## Media Processor

**Type:** `service` · **Layer:** `application` · **File:** `workers/src/media_jobs/transcoder.py`

### Purpose

Background service that transcodes uploaded media into variants.

### Responsibilities

- Transcode images to thumbnail, medium, and full variants.
- Transcode videos to 480p and 720p HLS variants.
- Update MediaUpload status to ready on success.

### Public API

- `processUpload`
- `handleFailure`

### Inputs

- Media.uploaded.v1

### Outputs

- Media.processed.v1
- Media.failed.v1

### Error Handling

Raise and DLQ on permanent failures; retry with backoff on transient errors.

### Acceptance Criteria

- [ ] Failed transcode jobs emit Media.failed.v1 with a reason code.
- [ ] Transcoding is idempotent by upload id.

### Out of Scope

- Live-stream ingest

### Test Specifications

#### Unit Tests

**Test: processUpload produces three image variants**

- Given: a raw image upload id
- When: processUpload runs
- Then: three variants are upserted and Media.processed.v1 is emitted

**Test: handleFailure emits Media.failed.v1**

- Given: a transcode that raised DecodeError
- When: handleFailure runs
- Then: Media.failed.v1 is emitted with reason decode_error

#### Integration Tests

**Test: integration with the object store**

- Given: a TestBed with a localstack S3 stub
- When: processUpload runs end-to-end
- Then: three variant objects exist and the upload status is ready

---
