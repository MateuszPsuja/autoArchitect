# Notifications — Application Use Cases

## Fan-out Scheduler

**Type:** `service` · **Layer:** `application` · **File:** `workers/src/notifications/fanout_scheduler.py`

### Purpose

Decides when and how to fan out a notification to push and WS channels.

### Responsibilities

- Coalesce notifications within a 60-second window per user.
- Emit Notification.fanout.v1 to the push and WS workers.
- Back off retries on push delivery failure.

### Public API

- `schedule`
- `cancel`
- `flush`

### Inputs

- Notification.created.v1

### Outputs

- Notification.fanout.v1

### Error Handling

Retry push delivery up to three times with exponential backoff.

### Acceptance Criteria

- [ ] At most one push per user per coalescing window.
- [ ] WebSocket fan-out never blocks the API request path.

### Out of Scope

- Email digests

### Test Specifications

#### Unit Tests

**Test: schedule coalesces within the window**

- Given: three notifications within 60 seconds
- When: schedule is called for each
- Then: a single Notification.fanout.v1 is emitted

**Test: flush emits immediately when window is exceeded**

- Given: a notification scheduled at t0
- When: flush is called at t0 plus 61s
- Then: a Notification.fanout.v1 is emitted regardless

#### Integration Tests

**Test: integration with the push provider stub**

- Given: a TestBed with a stubbed push provider
- When: schedule then flush run
- Then: a single push payload is sent

---
