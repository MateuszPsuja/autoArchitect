# Notifications — Infrastructure

*No infrastructure-layer components defined.*
