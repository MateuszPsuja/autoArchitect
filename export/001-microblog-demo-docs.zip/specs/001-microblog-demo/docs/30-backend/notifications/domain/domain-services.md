# Notifications — Domain Services

## Mention Detector

**Type:** `domain-service` · **Layer:** `domain` · **File:** `workers/src/notifications/mention_detector.py`

### Purpose

Parses post bodies and DMs to find mentioned handles.

### Responsibilities

- Extract mentions from post bodies and DM bodies.
- Resolve handles to user ids at notification time.
- Return at most ten distinct user ids per body.

### Public API

- `detectMentions`
- `resolveHandles`

### Inputs

- Post body or DM body

### Outputs

- Mention list

### Error Handling

Skip unknown handles silently rather than throwing.

### Acceptance Criteria

- [ ] Duplicate mentions are deduplicated.
- [ ] Handles are case-insensitive when resolving.

### Out of Scope

- Mention parsing in non-Latin scripts

### Test Specifications

#### Unit Tests

**Test: detectMentions extracts handles in any case**

- Given: a body with @Microblog and @microblog
- When: detectMentions is called
- Then: a single mention is returned

**Test: resolveHandles returns null for unknown handles**

- Given: a handle that does not exist
- When: resolveHandles is called
- Then: null is returned for that handle

#### Integration Tests

**Test: integration with the user repository**

- Given: a TestBed with seeded users
- When: detectMentions then resolveHandles run
- Then: the list contains only known user ids

---
