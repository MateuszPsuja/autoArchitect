# Notifications — Aggregates & Domain Events

*No aggregates defined.*

## Domain Events Catalog

### notification.created.v1

Raised when a per-user notification is persisted.

**Triggered by:** Notification.create()
**Handled by:** Fan-out Scheduler

**Payload:**
- `userId`
- `kind`
- `actorId`
- `subjectId`
- `createdAt`
