# Notifications

Backend context for in-app notifications with push fan-out.

**Layer:** `backend`
**Directory:** `backend/src/notifications`

## Responsibilities

- Create per-user notifications for likes, reposts, mentions, follows, and DMs.
- Coalesce notifications within a 60-second window per user.
- Dispatch push notifications via the push provider with retries.
