# Posts and Threads — Application Use Cases

*No application-layer use cases defined.*
