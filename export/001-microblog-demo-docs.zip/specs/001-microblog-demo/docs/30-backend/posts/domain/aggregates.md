# Posts and Threads — Aggregates & Domain Events

## Post

Aggregates a single post with a body, a status, and a bounded edit history.

**Root Entity:** `Post`

### Invariants
- Body length is at most 280 characters.
- A post with status deleted cannot transition to published.
- A post published with media references cannot transition until all media are ready.

### Value Objects
- `PostId`
- `PostBody`
- `PostStatus`

### Commands
- `publish`
- `edit`
- `delete`
- `reply`

### Domain Events Emitted
- `post.published.v1`
- `post.edited.v1`
- `post.deleted.v1`

## Domain Events Catalog

### post.published.v1

Raised when a post transitions to published.

**Triggered by:** Post.publish()
**Handled by:** Fan-out Dispatcher, Search Indexer, Notification Worker

**Payload:**
- `postId`
- `authorId`
- `body`
- `replyTo`
- `mediaIds`
- `publishedAt`

### post.deleted.v1

Raised when a post is deleted.

**Triggered by:** Post.delete()
**Handled by:** Fan-out Dispatcher, Search Indexer

**Payload:**
- `postId`
- `deletedAt`
