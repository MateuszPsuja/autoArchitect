# Posts and Threads

Backend context for the post, thread, and media-attachment aggregates.

**Layer:** `backend`
**Directory:** `backend/src/posts`

## Responsibilities

- Enforce the 280-character body limit and the four-media cap.
- Track edits and deletes with a bounded history.
- Emit post.published.v1 to the outbox on every publish.
