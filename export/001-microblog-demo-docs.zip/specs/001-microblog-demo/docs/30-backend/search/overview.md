# Search and Trending

Backend context for indexing published posts and computing trending topics.

**Layer:** `backend`
**Directory:** `backend/src/search`

## Responsibilities

- Bulk-index published posts into OpenSearch with low latency.
- Compute trending hashtags and topics on a rolling 24-hour window.
- Provide typeahead search at sub-50ms latency.
