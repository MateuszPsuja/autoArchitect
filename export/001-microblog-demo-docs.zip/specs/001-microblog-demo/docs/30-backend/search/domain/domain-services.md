# Search and Trending — Domain Services

## Trending Calculator

**Type:** `domain-service` · **Layer:** `domain` · **File:** `workers/src/search_index/trending_calculator.py`

### Purpose

Computes trending hashtags and topics over a rolling 24-hour window.

### Responsibilities

- Aggregate engagement counts per hashtag from the indexer.
- Decay counts using a 24-hour half-life.
- Expose the top-N trending items for the explore page.

### Public API

- `recompute`
- `topN`

### Inputs

- Engagement.recorded.v1

### Outputs

- TrendingItem list

### Error Handling

Default to last-known-good trending snapshot on computation failure.

### Acceptance Criteria

- [ ] Trending recomputation completes within 30 seconds for 1M events.
- [ ] Snapshot is served from cache with a 60-second TTL.

### Out of Scope

- Geo-specific trending

### Test Specifications

#### Unit Tests

**Test: recompute applies half-life decay**

- Given: two engagements at distinct timestamps
- When: recompute is called
- Then: older engagement contributes a smaller weight

**Test: topN returns at most N items**

- Given: twelve distinct trending candidates
- When: topN with limit 10 is called
- Then: ten items are returned in descending weight order

#### Integration Tests

**Test: integration with the trending snapshot store**

- Given: a TestBed with a Postgres trending_snapshots table
- When: recompute then topN run
- Then: a snapshot row is written and topN reads from it

---
