# Search and Trending — Aggregates & Domain Events

*No aggregates defined.*
