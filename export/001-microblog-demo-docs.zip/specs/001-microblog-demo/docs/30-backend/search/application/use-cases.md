# Search and Trending — Application Use Cases

## Indexing Queue

**Type:** `service` · **Layer:** `application` · **File:** `workers/src/search_index/indexer.py`

### Purpose

Buffers index events and flushes them to OpenSearch in batches.

### Responsibilities

- Buffer index events up to 500 items or 2 seconds.
- Flush on either threshold and ack the input stream.
- Backpressure the consumer when OpenSearch is slow.

### Public API

- `enqueue`
- `flush`
- `close`

### Inputs

- IndexEvent list

### Outputs

- OpenSearch bulk response

### Error Handling

Retry the batch with exponential backoff; DLQ after 5 attempts.

### Acceptance Criteria

- [ ] The queue never drops events on graceful shutdown.
- [ ] Flush latency p95 is under 250ms under steady load.

### Out of Scope

- Per-shard routing

### Test Specifications

#### Unit Tests

**Test: flush emits a bulk request at 500 items**

- Given: a queue with 499 items
- When: enqueue adds a 500th item
- Then: a bulk request is fired and the buffer resets

**Test: flush emits a bulk request after 2 seconds**

- Given: a queue with one item
- When: the timer elapses
- Then: a bulk request is fired for the one item

#### Integration Tests

**Test: integration with an in-memory OpenSearch stub**

- Given: a TestBed with a stubbed bulk endpoint
- When: enqueue 1000 items then flush run
- Then: two bulk requests are issued and all items are acked

---
