# Search and Trending — Infrastructure

## Search Index

**Type:** `repository` · **Layer:** `infrastructure` · **File:** `backend/src/search/infrastructure/opensearch_client.py`

### Purpose

Maintains the OpenSearch index of published posts.

### Responsibilities

- Bulk-index published posts from the indexer worker.
- Provide low-latency typeahead lookups.
- Hide posts from blocked or muted authors at query time.

### Public API

- `indexPost`
- `removePost`
- `search`

### Inputs

- Post.published.v1
- Post.deleted.v1

### Outputs

- Indexed posts
- Search results

### Error Handling

Surface OpenSearch errors as SearchUnavailable; never swallow them.

### Acceptance Criteria

- [ ] Search results respect block and mute lists at read time.
- [ ] A deleted post is removed from the index within 5 seconds.

### Out of Scope

- Personalised ranking

### Test Specifications

#### Unit Tests

**Test: indexPost writes a post document**

- Given: a post.published.v1 event payload
- When: indexPost is called
- Then: a document is upserted into the posts index

**Test: search filters blocked authors**

- Given: two posts where the author blocks the requesting user
- When: search is called for that user
- Then: no posts from the blocking author are returned

#### Integration Tests

**Test: integration with OpenSearch**

- Given: a TestBed with an OpenSearch test container
- When: indexPost then search run
- Then: the indexed post is returned by the search query

---
