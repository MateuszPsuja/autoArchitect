# Microblog Platform (Demo) — Agent Implementation Guide

> Start here. This file maps implementation order to files and feature directories.

## Implementation Order

| # | Task | Files |
|---|---|---|
| 01 | Scaffold backend and workers workspaces | backend/src/main.py, workers/src/main.py, infra/docker/compose.yml |
| 02 | Implement Post aggregate and repository | backend/src/posts/domain/aggregates/post.py, backend/src/posts/infrastructure/repositories/postgres_post_repository.py |
| 03 | Implement Post REST API | backend/src/posts/interfaces/routes.py, shared/python/posts.py |
| 04 | Implement Fan-out Dispatcher worker | workers/src/fan_out/dispatcher.py, workers/src/fan_out/materializer.py, workers/src/fan_out/timeline_cache.py |
| 05 | Implement Search Indexer worker | workers/src/search_index/indexer.py, backend/src/search/infrastructure/opensearch_client.py |
| 06 | Implement DM Conversation and Message aggregates | backend/src/direct_messages/domain/aggregates/conversation.py, backend/src/direct_messages/domain/aggregates/message.py, backend/src/direct_messages/domain/dm_encryption.py |
| 07 | Build the Angular Home Feed feature | frontend/src/app/features/home/home-feed.component.ts, frontend/src/app/core/stores/home-feed.store.ts |
| 08 | Build the Angular Post Composer feature | frontend/src/app/features/home/post-composer.component.ts, frontend/src/app/core/stores/composer.store.ts |
| 09 | Wire the Notifications panel to WSS | frontend/src/app/features/notifications/notifications-panel.component.ts, frontend/src/app/core/ws/notifications.ws.ts, frontend/src/app/core/stores/notifications.store.ts |
| 10 | Implement the Moderation Report triage service | backend/src/moderation/domain/report_triage.py, backend/src/moderation/application/assign_report.py |

## Feature Directories

- [`backend/src/posts`](backend/src/posts/AGENTS.md) — Post, thread, and media-attachment aggregates plus REST APIs.
- [`backend/src/engagement`](backend/src/engagement/AGENTS.md) — Like, repost, and bookmark aggregates plus REST APIs.
- [`backend/src/social_graph`](backend/src/social_graph/AGENTS.md) — Follow, block, and mute aggregates plus REST APIs.
- [`backend/src/shared`](backend/src/shared/AGENTS.md) — Cross-cutting concerns: events, exceptions, middleware, and idempotency.
- [`workers/src/fan_out`](workers/src/fan_out/AGENTS.md) — Fan-out dispatcher, materializer, and timeline cache.
- [`workers/src/notifications`](workers/src/notifications/AGENTS.md) — Mention detector and fan-out scheduler.
- [`workers/src/search_index`](workers/src/search_index/AGENTS.md) — OpenSearch indexer and trending calculator.
- [`workers/src/media_jobs`](workers/src/media_jobs/AGENTS.md) — Media transcoder and variant generator.
- [`frontend/src/app/features/home`](frontend/src/app/features/home/AGENTS.md) — Public reader feature: home feed and post composer.
- [`frontend/src/app/features/profile`](frontend/src/app/features/profile/AGENTS.md) — Public reader feature: profile page, header, and tabs.
- [`frontend/src/app/features/dm`](frontend/src/app/features/dm/AGENTS.md) — DM inbox and conversation view.
- [`frontend/src/app/features/notifications`](frontend/src/app/features/notifications/AGENTS.md) — Notifications panel and WSS-driven live updates.
- [`shared/schemas`](shared/schemas/AGENTS.md) — Versioned Zod and Pydantic schemas for API requests, responses, and events.
- [`infra/terraform`](infra/terraform/AGENTS.md) — Terraform modules and per-env configuration for VPC, EKS, RDS, ElastiCache, and OpenSearch.
- [`infra/observability`](infra/observability/AGENTS.md) — OpenTelemetry collector, dashboards, and alert rules.
- [`infra/ci`](infra/ci/AGENTS.md) — GitHub Actions pipelines for backend, workers, frontend, and e2e tests.
- [`infra/docs/runbooks`](infra/docs/runbooks/AGENTS.md) — Operational runbooks referenced by every alert.

## Detailed Task Files

- [Scaffold backend and workers workspaces](docs/60-agent-tasks/01-scaffold-backend-and-workers-workspaces.md)
- [Implement Post aggregate and repository](docs/60-agent-tasks/02-implement-post-aggregate-and-repository.md)
- [Implement Post REST API](docs/60-agent-tasks/03-implement-post-rest-api.md)
- [Implement Fan-out Dispatcher worker](docs/60-agent-tasks/04-implement-fan-out-dispatcher-worker.md)
- [Implement Search Indexer worker](docs/60-agent-tasks/05-implement-search-indexer-worker.md)
- [Implement DM Conversation and Message aggregates](docs/60-agent-tasks/06-implement-dm-conversation-and-message-aggregates.md)
- [Build the Angular Home Feed feature](docs/60-agent-tasks/07-build-the-angular-home-feed-feature.md)
- [Build the Angular Post Composer feature](docs/60-agent-tasks/08-build-the-angular-post-composer-feature.md)
- [Wire the Notifications panel to WSS](docs/60-agent-tasks/09-wire-the-notifications-panel-to-wss.md)
- [Implement the Moderation Report triage service](docs/60-agent-tasks/10-implement-the-moderation-report-triage-service.md)
