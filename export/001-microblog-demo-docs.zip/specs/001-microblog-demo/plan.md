# Implementation Plan: Microblog Platform (Demo)

> A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications.

**Branch**: `001-microblog-demo` · **Date**: 2026-09-15T00:00:00.000Z · **Spec**: [./spec.md](./spec.md)

## Summary

A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications.

## Technical Context

| Field | Value |
|---|---|
| **Language / Version** | TypeScript 5.x (Angular 17+, Node 20+) |
| **Primary Dependencies** | Python 3.11, FastAPI, SQLAlchemy 2 (async), Alembic, Pydantic v2, redis-py async, ARQ (workers), boto3, ARQ, FFmpeg, Pillow, OpenSearch client, Angular 17 (standalone components), PrimeNG (Aura preset), NgRx Signals and signalStore, Zod (runtime schema validation), Vitest plus Angular Testing Library, Zod (TypeScript), Pydantic v2 (Python), OpenAPI 3.1, AsyncAPI 2, Terraform, Kubernetes (EKS), PostgreSQL 16, Redis 7, OpenTelemetry, GitHub Actions, Argo CD |
| **Storage** | PostgreSQL 16 via SQLAlchemy 2 async; outbox table for domain events; Redis Streams for input; PostgreSQL, S3, and OpenSearch for output; Browser memory only; persistence happens via the backend; Source files only (CI-run codegen + repo-committed artefacts); GitHub Actions cache + container registry (tagged by digest) |
| **Testing** | Vitest / Jasmine for frontend, pytest for backend |
| **Target Platform** | Linux server (Python 3.11); containerised via Docker; Linux containers (amd64 plus arm64); Browser (Chrome 110+, Firefox 110+, Safari 16+); CI-run codegen + repo-committed artefacts; Linux containers (amd64 plus arm64) on Kubernetes |
| **Project Type** | Multi-layer (backend + backend-workers + frontend + shared + infra) |
| **Performance Goals** | p95 GET api timelines home under 200ms; p95 POST post under 400ms; Fan-out dispatcher processes 10k events per minute per replica with p95 latency under 1s; TTI under 3s on a cold cache; largest-contentful-paint under 2s on 4G; Codegen completes in under 30 seconds on CI; CI build under 12 minutes; production deploy under 5 minutes; image pull under 30 seconds on a warm cluster |
| **Constraints** | Domain layer MUST have zero framework imports; all status transitions MUST be idempotent and emit exactly one domain event; Workers must be idempotent on event id; transient errors retry with backoff up to 5 times; No BehaviorSubject or ReplaySubject - use signals only. Mutate signalStore state only via patchState inside withMethods. All HTTP responses must be Zod-validated before reaching components.; No hand-written TypeScript request or response types - every type is z.infer. No breaking changes without a .v2 suffix on the event name.; Pin base image digests, not tags. Migrations run as a separate one-shot job, not on app start. Every alert links to a runbook. |
| **Scale / Scope** | 1M MAU readers, 50k posts per minute at peak, 200 RPS on read endpoints; 1k concurrent jobs per replica, 6 worker kinds, 3 replicas each; 1M MAU, 50k posts per minute, 10k signed-in DM sessions per day; ~80 schemas, ~30 events across 12 bounded contexts; 3 environments (dev, staging, prod), ~80 services, ~20TB PostgreSQL |

## Constitution Check

- ✅ Article 1 — Library-First
- ✅ Article 2 — CLI Interface
- ✅ Article 3 — Test-First (TDD)
- ✅ Article 4 — Integration Testing
- ✅ Article 5 — Observability
- ✅ Article 6 — Versioning & Breaking Changes
- ✅ Article 7 — Simplicity
- ✅ Article 8 — Anti-Abstraction
- ✅ Article 9 — Integration-First Delivery

**Per-layer gates:**

- ✅ `backend` — Strict type checking on all Pydantic schemas (extra forbid)
- ✅ `backend` — Unit plus integration tests per use case (at least 2 unit, at least 1 integration)
- ✅ `backend` — Domain layer has zero framework imports (no FastAPI, SQLAlchemy, or Redis)
- ✅ `backend` — Outbox pattern used for every domain event
- ✅ `backend` — All authorization checks live in the application layer, not routes
- ✅ `backend-workers` — Every worker job is idempotent on its event id
- ✅ `backend-workers` — Workers never call the API directly; they consume events from Redis Streams
- ✅ `backend-workers` — Every job emits an OpenTelemetry span with the event id as an attribute
- ✅ `backend-workers` — Failed jobs go to a per-stream DLQ after 5 retries
- ✅ `backend-workers` — Worker processes expose a /healthz endpoint
- ✅ `frontend` — Strict TypeScript with noImplicitAny and strictNullChecks
- ✅ `frontend` — Standalone components only - no NgModule declarations
- ✅ `frontend` — Mutate signalStore state only via patchState inside withMethods
- ✅ `frontend` — All HTTP responses validated with a Zod schema before reaching components
- ✅ `frontend` — Lazy-load every top-level feature via loadComponent or loadChildren
- ✅ `shared` — Zod schema is the source of truth; TypeScript types and Pydantic models are generated
- ✅ `shared` — Every domain event is declared in the AsyncAPI catalogue with a versioned name
- ✅ `shared` — OpenAPI 3.1 spec is regenerated on every CI run and committed
- ✅ `shared` — Breaking payload changes require a new .vN suffix on the event name
- ✅ `shared` — Schemas live in shared/schemas and are imported by both backend and frontend
- ✅ `infra` — All images pinned by digest, not tag
- ✅ `infra` — Migrations run as a separate one-shot job, not on app start
- ✅ `infra` — OpenTelemetry traces and metrics exported on every request and worker job
- ✅ `infra` — Every Prometheus alert links to a runbook in docs/runbooks/
- ✅ `infra` — CI fails on any uncommitted generated artefact (OpenAPI, TS types)

## Project Structure

### Documentation (this plan)

```text
specs/
└── 001-microblog-demo/
    ├── README.md
    ├── spec.md
    ├── plan.md
    ├── data-model.md
    ├── contracts/
    ├── quickstart.md
    ├── tasks.md
    ├── checklist.md
    ├── ARCHITECTURE.md
    ├── AGENTS.md
    └── docs/
        ├── 00-system/
        ├── 10-architecture/
        ├── 20-decisions/
        ├── 30-…/ (per layer)
        ├── 50-workflows/
        └── 60-agent-tasks/
```

### Source Code

```text
backend/src/posts/
backend/src/engagement/
backend/src/social_graph/
backend/src/shared/
workers/src/fan_out/
workers/src/notifications/
workers/src/search_index/
workers/src/media_jobs/
frontend/src/app/features/home/
frontend/src/app/features/profile/
frontend/src/app/features/dm/
frontend/src/app/features/notifications/
shared/schemas/
infra/terraform/
infra/observability/
infra/ci/
infra/docs/runbooks/
```

## Complexity Tracking

| Layer | Violation | Why Needed | Simpler Alternative Rejected |
|---|---|---|---|
| `backend` | Outbox table for domain events | Guarantees at-least-once delivery to workers without dual-write inconsistencies | Direct synchronous call from request handler to worker - would lose events on partial failure and tightly couples the request to the worker runtime |
| `backend` | Repository pattern plus Unit of Work per request | Keeps the use-case layer testable without SQLAlchemy sessions and isolates the aggregate from persistence | Use cases calling SQLAlchemy sessions directly - couples domain logic to a specific ORM and makes unit tests slow or flaky |
| `backend-workers` | Redis Streams consumer groups | Native backpressure, replay, and per-stream DLQ for at-least-once delivery | Polling a Postgres outbox table - doubles DB load and makes replays expensive |
| `frontend` | NgRx signalStore for feature state (vs. plain service plus signals) | Standardises selectors, methods, and patchState boundaries so multiple components can subscribe without cross-feature coupling | Plain service exposing writable signals - would let any consumer mutate state and removes the audit boundary between read and write |
| `frontend` | Zod schema validation for every HTTP response | Catches upstream contract drift at the seam where the SPA meets the backend instead of crashing a component at render time | Trust the typed response - leaves the SPA exposed to silent runtime errors when the backend ships a breaking change |
| `shared` | Maintaining schema parity across Zod and Pydantic | Lets the backend and frontend evolve independently without silent contract drift | Hand-written Pydantic and hand-written TypeScript types - drifts within weeks and causes runtime schema drift errors in the SPA |
| `infra` | OpenTelemetry collector plus Prometheus plus Grafana stack | Single pane of glass across FastAPI, Angular SPA, and ARQ workers | Vendor-specific APM (NewRelic or Datadog) - high cost and lock-in for a single-team project |
| `infra` | Image digests instead of mutable tags | Reproducible rollbacks and zero ambiguity between what is in staging and what is in prod | latest or version tags - caused a known incident on a previous project where a base image was re-tagged mid-deploy |
