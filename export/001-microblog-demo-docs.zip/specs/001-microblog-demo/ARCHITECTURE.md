# Microblog Platform (Demo) — Architecture

> A reference demo plan for the Microblog platform — a multi-tenant microblog with real-time fan-out timelines, threaded conversations, media uploads, full-text search, and notifications.

## Architecture Approach

### Backend (Python)

FastAPI service exposing REST and WebSocket APIs for the public reader and the staff console, backed by PostgreSQL, Redis, S3, and OpenSearch.

**Patterns:** Domain-Driven Design (aggregates, bounded contexts), Clean Architecture (domain, application, infrastructure, interfaces), Outbox pattern for reliable domain events, Repository pattern with async sessions, Hexagonal ports and adapters
**Tech stack:** Python 3.11, FastAPI, SQLAlchemy 2 (async), Alembic, Pydantic v2, redis-py async, ARQ (workers), boto3

### Backend Workers

ARQ-based worker processes for fan-out, notifications, indexing, and media transcoding.

**Patterns:** Idempotent consumers keyed by event id, Stream consumer groups with backoff, Batch processing per chunk, Coalescing for fan-out notifications
**Tech stack:** Python 3.11, ARQ, redis-py async, FFmpeg, Pillow, OpenSearch client

### Frontend (Angular)

Angular 17 standalone-component SPA for timelines, profiles, threads, DMs, and notifications.

**Patterns:** Standalone components, no NgModules, Signal-first state via NgRx signalStore; mutate only through patchState, Lazy-loaded feature shells, Route guards for authenticated and staff areas, Strict runtime schema validation for HTTP responses
**Tech stack:** Angular 17 (standalone components), PrimeNG (Aura preset), NgRx Signals and signalStore, Zod (runtime schema validation), Vitest plus Angular Testing Library

### Shared Contracts

Schemas, types, and event catalogs shared between the backend, workers, and the frontend.

**Patterns:** Single source of truth per contract (Zod on the client, Pydantic on the server), Generated TypeScript types via z.infer, Versioned event names with semantic suffixes (.v1)
**Tech stack:** Zod (TypeScript), Pydantic v2 (Python), OpenAPI 3.1, AsyncAPI 2

### Infrastructure

Containerised runtime, IaC, observability, and CI/CD for the whole stack.

**Patterns:** 12-factor configuration via environment variables, OpenTelemetry traces and metrics on every request and worker job, Migrations run as a separate one-shot job, not on app start, GitOps via Argo CD with image-digest pinning
**Tech stack:** Terraform, Kubernetes (EKS), PostgreSQL 16, Redis 7, OpenTelemetry, GitHub Actions, Argo CD

## Document Index

| Section | File |
|---|---|
| Feature Spec | [spec.md](spec.md) |
| Implementation Plan | [plan.md](plan.md) |
| Data Model | [data-model.md](data-model.md) |
| Contracts | [contracts/](contracts/) |
| Quickstart | [quickstart.md](quickstart.md) |
| Tasks | [tasks.md](tasks.md) |
| System Overview | [docs/00-system/overview.md](docs/00-system/overview.md) |
| Bounded Context Map | [docs/00-system/bounded-context-map.md](docs/00-system/bounded-context-map.md) |
| Architecture Overview | [docs/10-architecture/overview.md](docs/10-architecture/overview.md) |
| Backend (Python) Architecture | [docs/10-architecture/backend-architecture.md](docs/10-architecture/backend-architecture.md) |
| Backend Workers Architecture | [docs/10-architecture/backend-workers-architecture.md](docs/10-architecture/backend-workers-architecture.md) |
| Frontend (Angular) Architecture | [docs/10-architecture/frontend-architecture.md](docs/10-architecture/frontend-architecture.md) |
| Shared Contracts Architecture | [docs/10-architecture/shared-architecture.md](docs/10-architecture/shared-architecture.md) |
| Infrastructure Architecture | [docs/10-architecture/infra-architecture.md](docs/10-architecture/infra-architecture.md) |
| Backend (Python) Contracts | [contracts/backend.md](contracts/backend.md) |
| Backend Workers Contracts | [contracts/backend-workers.md](contracts/backend-workers.md) |
| Frontend (Angular) Contracts | [contracts/frontend.md](contracts/frontend.md) |
| Shared Contracts Contracts | [contracts/shared.md](contracts/shared.md) |
| Infrastructure Contracts | [contracts/infra.md](contracts/infra.md) |
