# `backend/src/social_graph`

> **Layer:** Backend (Python)

Follow, block, and mute aggregates plus REST APIs.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Block edges are checked at the use-case layer before any post write.
- [ ] Mute edges must not break the existing follow relationship.

## Files to Create

| File | Type | Description |
|---|---|---|
| `backend/src/social_graph/domain/follow_edge.py` | `aggregate` | Aggregates a directed follow relationship between two users. |
| `backend/src/social_graph/domain/block_list.py` | `aggregate` | Tracks which users have blocked the current user across all surfaces. |
| `backend/src/social_graph/domain/mute_list.py` | `aggregate` | Maintains a per-user mute list that hides posts without unfollowing. |

## Component Specifications

### Follow Edge

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] A follow is rejected when the target has blocked the actor.
- [ ] Unfollow is idempotent (no event on a no-op).

### Block List

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Blocked authors do not appear in home timelines.
- [ ] Unblock re-enables future interactions immediately.

### Mute List

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Muting hides future posts but preserves the existing follow edge.
- [ ] Unmuting restores posts on the next timeline read.
