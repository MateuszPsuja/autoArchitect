# `backend/src/posts`

> **Layer:** Backend (Python)

Post, thread, and media-attachment aggregates plus REST APIs.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] All post mutations must go through the PublishPostUseCase.
- [ ] Never import FastAPI or SQLAlchemy from the domain layer.

## Files to Create

| File | Type | Description |
|---|---|---|
| `backend/src/posts/domain/aggregates/post.py` | `aggregate` | Aggregate that owns a post, its body, and lifecycle status. |
| `backend/src/posts/domain/aggregates/thread.py` | `aggregate` | Composite aggregate that orders replies into a self-thread. |
| `backend/src/posts/domain/aggregates/media_attachment.py` | `aggregate` | Links a media variant to a post and enforces upload ordering. |

## Component Specifications

### Post

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Edits within 24h preserve original text in the edit history.
- [ ] Deleted posts are tombstoned, not hard-deleted.

### Thread

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Threads are append-only; existing posts cannot be reordered.
- [ ] A closed thread rejects new appends with ThreadClosed.

### Media Attachment

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Posts cannot be published with media variants in pending state.
- [ ] Detach is rejected after the post has been published.
