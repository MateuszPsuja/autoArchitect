# `backend/src/shared`

> **Layer:** Backend (Python)

Cross-cutting concerns: events, exceptions, middleware, and idempotency.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Event names follow the noun.action.vN convention.
- [ ] Middleware must be idempotent under retries.
