# `backend/src/engagement`

> **Layer:** Backend (Python)

Like, repost, and bookmark aggregates plus REST APIs.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Idempotency-Key header is required on every engagement write.
- [ ] Engagement events fan out via the PubSubBus, never synchronously.

## Files to Create

| File | Type | Description |
|---|---|---|
| `backend/src/engagement/domain/aggregates/like.py` | `aggregate` | Records a user liking a post and exposes undo. |
| `backend/src/engagement/domain/aggregates/repost.py` | `aggregate` | Records a user reposting (reposting) a post. |
| `backend/src/engagement/domain/aggregates/bookmark.py` | `aggregate` | Stores a private per-user bookmark for a post. |

## Component Specifications

### Like

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Likes from blocked authors are rejected.
- [ ] Undo decrements the cached count atomically.

### Repost

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Reposts do not appear on the author own home timeline.
- [ ] Quote posts keep the original attribution in the body.

### Bookmark

See full spec in [domain docs](../../docs).

**Acceptance Criteria:**
- [ ] Bookmarks are visible only to the owning user.
- [ ] Unbookmark is idempotent (no event on a no-op).
