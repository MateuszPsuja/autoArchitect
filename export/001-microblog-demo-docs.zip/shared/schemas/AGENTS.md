# `shared/schemas`

> **Layer:** Shared Contracts

Versioned Zod and Pydantic schemas for API requests, responses, and events.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Schemas are the source of truth; types are inferred, not handwritten.
- [ ] Bump the version suffix on the event name when changing payload shape.
