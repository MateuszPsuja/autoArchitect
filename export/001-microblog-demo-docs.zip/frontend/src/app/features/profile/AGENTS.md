# `frontend/src/app/features/profile`

> **Layer:** Frontend (Angular)

Public reader feature: profile page, header, and tabs.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Mutate signalStore state only via patchState inside withMethods.
- [ ] All HTTP responses must be Zod-validated before reaching components.
- [ ] Resolve the handle from ActivatedRoute and surface 404 via a dedicated view.
