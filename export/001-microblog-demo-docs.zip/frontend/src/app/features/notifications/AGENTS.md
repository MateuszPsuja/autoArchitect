# `frontend/src/app/features/notifications`

> **Layer:** Frontend (Angular)

Notifications panel and WSS-driven live updates.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Mutate signalStore state only via patchState inside withMethods.
- [ ] All HTTP responses must be Zod-validated before reaching components.
- [ ] Subscribe to notifications WSS once per session and route through the NotificationsStore.
