# `frontend/src/app/features/home`

> **Layer:** Frontend (Angular)

Public reader feature: home feed and post composer.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Mutate signalStore state only via patchState inside withMethods.
- [ ] All HTTP responses must be Zod-validated before reaching components.
- [ ] All HTTP responses must be validated with a Zod schema before reaching components.
