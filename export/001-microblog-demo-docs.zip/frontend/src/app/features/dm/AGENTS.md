# `frontend/src/app/features/dm`

> **Layer:** Frontend (Angular)

DM inbox and conversation view.

## Agent Instructions

- [ ] Follow the repo root AGENTS.md conventions (signal-first state, Zod-validated IO, no NgModules).
- [ ] Write tests before implementation; keep coverage at or above the domain-level tddSpec.
- [ ] Document every public surface in the per-component README inside the target directory.
- [ ] Mutate signalStore state only via patchState inside withMethods.
- [ ] All HTTP responses must be Zod-validated before reaching components.
- [ ] Guard the route with the AuthGuard; never expose DMs to anonymous users.
